import React, { useEffect, createContext, useContext, useState } from "react";
import { fetchOrganisations, fetchOrganisation } from "Api";
import { instanceSelects } from "./AFunctions";
const AContext = createContext();

const userSchema = {
  id: undefined,
  type: 1,
  organisation: {
    id: "c92045c7-f78b-4d1a-97e3-7e71b910acf8",
    name: "Diageo"
  }
};

function AProvider({ children }) {
  const [user, setUser] = useState(userSchema);
  const [auth, setAuth] = useState(true);
  const [organisation, setOrganisation] = useState(undefined);
  const [organisations, setOrganisations] = useState(undefined);
  const [instances, setInstances] = useState(undefined);

  useEffect(() => {
    fetchOrganisation(user.organisation.id).then(
      org => {
        setOrganisation({
          ...user.organisation,
          instances: org.result,
          roles: org.roles
        });
        setInstances(instanceSelects(org.result));
      },
      rejection => {
        // reason
      }
    );

    if (user.type === 1) {
      fetchOrganisations().then(
        organisations => {
          setOrganisations(organisations);
        },
        rejection => {
          // reason
        }
      );
    }
  }, [user]);

  const AUTHORIZE = {
    LOGIN: () => console.log("LOGIN"),
    LOGOUT: () => console.log("LOGOUT")
  };

  const ASTATE = {
    AUTH: auth,
    AUSER: user,
    ATYPE: user.type,
    GLB_ORGANISATION: organisation,
    GLB_SELECTOR: {
      1: organisations,
      2: instances
    }
  };

  const ADISPATCH = {
    AUTHORIZE
  };

  return (
    <AContext.Provider value={{ ASTATE, ADISPATCH }}>
      {organisation && children}
    </AContext.Provider>
  );
}

const useAState = () => {
  const { ASTATE, ADISPATCH } = useContext(AContext);
  return {
    ASTATE,
    ADISPATCH
  };
};

export { AProvider, useAState };

/*//

IF AUTH === TRUE =>
- SET TYPE
- SET USER
ELSE
-REDIRECT TO LOGIN PAGE

IF USER TYPE === CCI
- FETCH ALL ORGS

IF USER TYPE !== CCI
- FETCH ORG AND CREATE INSTANCE SELECTOR


//*/
