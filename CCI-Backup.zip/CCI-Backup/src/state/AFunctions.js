export const instanceSelects = (items, key) => {
  return items.reduce((accumulator, i) => {
    accumulator.push({
      instanceName: i.instance.instanceName,
      instanceGuid: i.instance.instanceGuid
    });
    return accumulator;
  }, []);
};

export const findInstance = (instances, id) => {
  return instances.find(o => o.instance.instanceGuid === id);
};

const matchInstance = (usrIns, orgIns) =>
  usrIns.find(e => e.instanceGuid === orgIns);
