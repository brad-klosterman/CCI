import React, { useState, createContext, useContext } from "react";
import { ConfirmDialog, CreateDialog, Notification } from "Components";

const DashContext = createContext();

const notificationState = {
  open: false,
  variant: undefined,
  message: undefined
};

const confirmationState = {
  open: false,
  state: undefined,
  title: undefined,
  message: undefined,
  actions: undefined
};

function DashProvider({ children }) {
  const [notification, setNotification] = useState(notificationState);
  const [confirmation, setConfirmation] = useState(confirmationState);
  const [createDialog, setCreateDialog] = useState();

  const save = ({ title, message, actions, error, onExit }) => {
    function resolveSave(response) {
      setConfirmation(prev => ({ ...prev, state: 3 }));
    }

    function rejectSave(error) {
      setConfirmation(prev => ({ ...prev, state: 4, error }));
    }

    setConfirmation({
      open: true,
      state: 2,
      title,
      message,
      actions,
      error,
      onExit
    });

    return {
      resolveSave,
      rejectSave
    };
  };

  const confirm = ({ variant, title, message, actions, error, onExit }) => {
    let state = 1;

    return new Promise((resolve, reject) => {
      setConfirmation({
        open: true,
        state,
        variant,
        title,
        message,
        actions,
        resolve,
        reject,
        error,
        onExit
      });
    });
  };

  const continueConfirm = ({
    variant,
    title,
    message,
    error,
    actions,
    onExit
  }) => {
    let state = 1;
    return new Promise((resolve, reject) => {
      setConfirmation({
        open: true,
        state,
        variant,
        title,
        message,
        actions,
        error,
        resolve,
        reject,
        onExit
      });
    });
  };

  const onConfirm = () => {
    setConfirmation(prev => ({
      ...prev,
      state: 2
    }));
    confirmation.resolve("ACCEPT");
  };

  const onCancel = () => {
    setConfirmation(confirmationState);
    confirmation.resolve("REJECT");
  };

  const onExit = status => {
    setConfirmation(confirmationState);
    confirmation.onExit && confirmation.onExit(status);
  };

  const confirmationResponse = ({ value, message }) => {
    let state, error;
    if (value === "SUCCESS") {
      state = 3;
    } else {
      state = 4;
      error = message;
    }
    setConfirmation(prev => ({
      ...prev,
      state,
      error
    }));
  };

  /////////////////////////////

  const create = ({
    title,
    message,
    icons,
    children,
    actions,
    error,
    onExit
  }) => {
    console.log("create");
    function resolveSave(response) {
      setCreateDialog(prev => ({ ...prev, state: 3 }));
    }

    function rejectSave(error) {
      setCreateDialog(prev => ({ ...prev, state: 4, error }));
    }

    setCreateDialog({
      open: true,
      state: 1,
      title,
      message,
      icons,
      children,
      actions,
      error,
      onExit
    });

    return {
      resolveSave,
      rejectSave
    };
  };

  const DIALOG = {
    confirm,
    create,
    save,
    continueConfirm,
    confirmationResponse
  };

  /// NOTIFICATION

  function openNotification({ variant, message }) {
    setNotification({ open: true, variant, message });
  }

  function closeNotification() {
    setNotification(notificationState);
  }

  const DACTIONS = {
    openNotification
  };

  return (
    <DashContext.Provider value={{ DACTIONS, DIALOG }}>
      {children}
      {confirmation.open && (
        <ConfirmDialog
          open={confirmation.open}
          {...{ ...confirmation, onConfirm, onCancel, onExit }}
        />
      )}
      {createDialog && <CreateDialog {...createDialog} />}
      {notification.open && (
        <Notification
          open={notification.open}
          message={notification.message}
          variant={notification.variant}
          onClose={closeNotification}
        />
      )}
    </DashContext.Provider>
  );
}

const useDash = () => {
  const { DACTIONS, DIALOG } = useContext(DashContext);
  return {
    DACTIONS,
    DIALOG
  };
};

function useDialog() {
  const { dialog } = useContext(DashContext);
  return dialog;
}

export { DashContext, DashProvider, useDash, useDialog };
