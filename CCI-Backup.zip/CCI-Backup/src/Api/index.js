import React, { useState, useEffect } from "react";
import axios from "axios";

// export const API =
//   "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/";

/// USERS
export const API_BFF =
  "https://cci-ing-dev.eastus.cloudapp.azure.com/admin-console-bff/";
export const API_BFFT =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/";

export const API_USERS =
  "https://cci-ing-dev.eastus.cloudapp.azure.com/admin-console-bff/users/";
export const API_USER =
  "https://cci-ing-dev.eastus.cloudapp.azure.com/admin-console-bff/user/";

const fetchOrganisationsAPI =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/organisations";

export const fetchOrganisationAPI =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/organisation/";

export function useAPI({ SUCCESS, ERROR }) {
  const [loadingAPI, setLoadingAPI] = useState(false);
  const [errorAPI, setErrorAPI] = useState(false);

  const sendAPI = async ({ method, url, payload, callback, rejected }) => {
    setLoadingAPI(true);
    try {
      let response = await axios({
        method: method,
        url: url,
        data: payload,
        headers: {
          "Ocp-Apim-Subscription-Key": "44f39305524b43c8a8814ae56f5e2ab9"
        }
      });
      callback && callback({ response: response.data });
      SUCCESS && SUCCESS(response.data);
    } catch (error) {
      rejected && rejected({ error });

      ERROR && ERROR(error);
    }
    setLoadingAPI(false);
  };

  return {
    sendAPI,
    loadingAPI,
    errorAPI
  };
}

export async function API({ method, url, data, callback, reject }) {
  try {
    let response = await axios({
      method,
      url,
      data,
      headers: {
        "Ocp-Apim-Subscription-Key": "44f39305524b43c8a8814ae56f5e2ab9"
      }
    });
    callback && callback({ response: response.data });
    return { response: response.data };
  } catch (error) {
    reject && reject(error);
    return { error: true };
  }
}

// API({
//   method: 'POST',
//   url:`${AREAS_MAIN_API}organisations`,
//   data:{},
//   callback: ({response}) => console.log(),
//   reject: ({response}) => console.log()
// })

// export async function getAPI({ API, ID }) {
//   try {
//     let response = await axios.get(API + ID);
//     return response.data.result;
//   } catch (error) {
//     console.error(error);
//   }
// }
export async function getAPI({ API, ID }) {
  try {
    let response = await axios({
      method: "GET",
      url: API + ID,
      headers: {
        "Ocp-Apim-Subscription-Key": "44f39305524b43c8a8814ae56f5e2ab9"
      }
    });

    return response.data.result;
  } catch (error) {
    console.error(error);
  }
}

export async function POST_API({ API, ID, PAYLOAD }) {
  try {
    let response = await axios({
      method: "POST",
      url: API + ID,
      data: PAYLOAD,
      headers: {
        "Ocp-Apim-Subscription-Key": "44f39305524b43c8a8814ae56f5e2ab9"
      }
    });

    return response.data;
  } catch (error) {
    console.error(error);
  }
}

export function useApi({ method, url, payload }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasError, setErrors] = useState(false);

  useEffect(() => {
    if (payload) {
      (async function() {
        try {
          let response = await axios({
            method: method,
            url: url + payload,
            data: payload,
            headers: {
              "Ocp-Apim-Subscription-Key": "44f39305524b43c8a8814ae56f5e2ab9"
            }
          });
          setData(response.data);
        } catch (error) {
          setErrors(error);
        }
      })(url);
    }
  }, [url, method, payload]);

  return {
    apiData: data,
    apiErrors: hasError
  };
}

/// USERS

export const FETCH_USERS = async organisation => {
  const payload = {
    firstname: null,
    surname: null,
    pagenumber: 0,
    organisationGuid: organisation
  };
  try {
    let response = await axios.post(API_USERS, payload);
    return response.data;
  } catch (error) {
    return { error: true };
  }
};

export const FETCH_USER = async id => {
  try {
    let response = await axios.get(API_USER + id);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export const API_DELETE_USERS = async id => {
  try {
    let response = await axios.delete(API_USER + id);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export const fetchOrganisations = async id => {
  try {
    let response = await axios.get(fetchOrganisationsAPI);
    return response.data;
  } catch (error) {
    return null;
  }
};

export const fetchOrganisation = async id => {
  try {
    let response = await axios.get(fetchOrganisationAPI + id);
    return response.data;
  } catch (error) {
    return null;
  }
};

export const saveUser = async ({ type, payload }) => {
  // console.log("SAVEUSER", payload);
  try {
    let response = await axios[type](API_USER, payload);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

//// AREAS

const ENV = "STAGE";

// Ocp-Apim-Subscription-Key: 44f39305524b43c8a8814ae56f5e2ab9

export const AREAS_MAIN_API =
  "https://dev-cci.azure-api.net/areas-gateway-stg/v0.1/";

export const AREAS_API =
  "https://dev-cci.azure-api.net/areas-gateway-stg/v0.1/areas/";

// https://dev-cci.azure-api.net/areas-gateway-stg/v0.1/areas/
// https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/areas/

export const AREAS_ORGS =
  "https://dev-cci.azure-api.net/areas-gateway-stg/v0.1/organisations";

export const GET_INDUSTRIES =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/lookups/organizations/industries";

export const API_CLONE_AREA = ({ orgGuid, rootID, rowGuid, sourceGuid }) => {};

export const API_DELETE_AREA = async location => {
  try {
    const response = await axios.delete(AREAS_API + location);
    return response.data;
  } catch (error) {
    return { error: true };
  }
};

export const AREAS_POST = async payload => {
  try {
    const response = await axios.post(AREAS_ORGS, payload);
    return response.data;
  } catch (error) {
    return { error };
  }
};
