import axios from "axios";
import { useState, useEffect, useCallback } from "react";
import { fetchUsersAPI } from "Api";

export const useFetchUsers = organisation => {
  const [state, setState] = useState({ users: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const payload = {
    firstname: null,
    surname: null,
    pagenumber: 0,
    organisationGuid: organisation
  };

  const fetchUsers = useCallback(async () => {
    setError(false);
    setLoading(true);

    try {
      const response = await axios.post(fetchUsersAPI, payload);
      setState(prev => ({
        ...prev,
        users: response.data
      }));
    } catch (error) {
      setError(true);
      console.log(error);
    }
    setLoading(false);
  }, []);

  // Fetch popular movies initially on mount
  useEffect(() => {
    fetchUsers(organisation);
  }, []);

  return [{ state, loading, error }, fetchUsers];
};
