import React, { useState } from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import { MAIN_ROUTES } from "Base/Routing/Routes";
import SideBar from "Components/Nav/SideBar";
import withRoot from "style/withRoot";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { DashProvider } from "state";

function Dashboard(props) {
  const cx = useStyles();
  const [open, setOpen] = useState(false);

  function onSideHover() {
    setOpen(true);
  }

  function onSideExit() {
    setOpen(false);
  }

  return (
    <BrowserRouter>
      <DashProvider>
        <div className={cx.root}>
          <SideBar
            open={open}
            onSideHover={onSideHover}
            onSideExit={onSideExit}
          />
          <main
            className={clsx(cx.content, {
              [cx.contentShift]: open
            })}
          >
            <Switch>
              {MAIN_ROUTES.map((route, index) => (
                <Route
                  key={index}
                  path={route.path}
                  exact={route.exact}
                  component={route.component}
                />
              ))}
            </Switch>
          </main>
        </div>
      </DashProvider>
    </BrowserRouter>
  );
}

const DashboardModule = withRoot(Dashboard);
export default DashboardModule;

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex"
  },
  content: {
    flexGrow: 1,
    padding: "0px 48px",
    marginTop: 0,
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
    // marginLeft: -drawerWidth
  },
  contentShift: {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen
    }),
    marginLeft: 0
  }
}));
