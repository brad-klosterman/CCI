import React, { useMemo, useState, useEffect, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { useAState } from "state";
import { useUSRState } from "./UsersState";
import {
  TableBody,
  TablePagination,
  Typography,
  Grid
} from "@material-ui/core";
import { useFilters, usersFilters, exportCSVFile } from "Utl";
import { Usearch, Utable, TableHead, Row } from "People";

const Users = memo(() => {
  const cx = useStyles();
  const {
    ASTATE: { ATYPE, GLB_SELECTOR }
  } = useAState();
  const {
    USRSTATE: { users, organisation, filters, checked, loadingAPI },
    USRACTIONS: {
      SELECT_ORG,
      SELECT_USER,
      NEW_USER,
      deleteUsers,
      onCheck,
      onCheckAll
    }
  } = useUSRState();

  const { filteredData, filterActions } = useFilters({
    data: users,
    filters: usersFilters
  });
  const { transformed, params, order } = filteredData;
  const { updateParam, updateOrder, clearSelects } = filterActions;

  const [page, setPage] = useState({
    page: 0,
    rows: 5
  });

  useEffect(() => {
    if (!users.length) {
      clearSelects();
    }
  }, [clearSelects, users]);

  const USRDATA = useMemo(() => {
    if (transformed) {
      return transformed.slice(
        page.page * page.rows,
        page.page * page.rows + page.rows
      );
    }
  }, [page, transformed]);

  const onChangePage = (event, newPage) => {
    setPage({ ...page, page: newPage });
  };

  const onChangeRows = event => {
    setPage({ ...page, rows: event.target.value });
  };

  const exportUsers = async () => {
    const headers = {
      firstname: "First Name",
      lastname: "Last Name",
      email: "Email",
      organisation: "Organisation"
    };
    var usersFormatted = [];

    const exportedUsers = await users.filter(user =>
      checked.selected.some(x => x === user.id)
    );

    exportedUsers.forEach(item => {
      usersFormatted.push({
        firstname: item.firstname,
        lastname: item.lastname,
        email: item.email,
        organisation: item.organisation.organisationName
      });
    });

    exportCSVFile(headers, usersFormatted, "Exported Users");
  };

  const PROPS = {
    search: {
      organisation,
      filters,
      params,
      updateParam,
      SELECT_ORG,
      ATYPE,
      GLB_SELECTOR
    },
    head: {
      checked,
      onCheckAll,
      order,
      updateOrder,
      NEW_USER,
      exportUsers,
      deleteUsers
    }
  };

  const RENDER_STATE = msg => (
    <Grid item xs={12}>
      <Typography varaint="h3">{msg}</Typography>
    </Grid>
  );

  const RENDER_USERS = () => (
    <Utable>
      <TableHead {...PROPS.head} />
      <TableBody component="div">
        {(USRDATA || []).map(user => (
          <Row
            {...{
              user,
              onCheck,
              SELECT_USER,
              checked: checked.selected.indexOf(user.id) !== -1,
              key: user.id
            }}
          />
        ))}
      </TableBody>

      <Grid item xs={12}>
        <TablePagination
          className={cx.pagination}
          classes={{
            selectIcon: cx.paginationSelect,
            toolbar: cx.paginationToolbar,
            actions: cx.paginationActions
          }}
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={transformed.length}
          rowsPerPage={page.rows}
          page={page.page}
          onChangePage={onChangePage}
          onChangeRowsPerPage={onChangeRows}
        />
      </Grid>
    </Utable>
  );

  const DISPLAY = loadingAPI
    ? RENDER_STATE("FETCHING USERS...")
    : RENDER_USERS();

  return (
    <Grid container spacing={4}>
      <Usearch {...PROPS.search} />
      {DISPLAY}
    </Grid>
  );
});

const useStyles = makeStyles(theme => ({
  root: {
    marginTop: "24px"
  },
  rootMobile: {
    maxWidth: "100%",
    maxHeight: 300,
    overflowX: "hidden",
    overflowY: "scroll"
  },
  actions: {
    padding: "0px 0px 0px 0px",
    display: "flex",
    justifyContent: "flex-end"
  },
  selected: {
    display: "flex"
  },
  count: {
    color: theme.grey,
    fontSize: 12,
    padding: "0px 0px 8px 0px",
    cursor: "pointer"
  },
  pagination: {
    width: "100%",
    fontSize: "14px"
  },
  paginationSelect: {
    top: "-2px",
    right: "-8px"
  },
  paginationToolbar: {
    height: 32,
    minHeight: 32,
    marginTop: 16,
    paddingRight: 16
  }
}));

export default Users;
