import React, {
  useState,
  useEffect,
  useCallback,
  createContext,
  useContext
} from "react";
import {
  API,
  API_BFF,
  API_BFFT,
  API_DELETE_USERS,
  useAPI,
  API_USERS
} from "Api";
import Users from "./Users";
import { UProvider } from "People";
import { useAState, useDash, instanceSelects } from "state";
import { findInstanceBFF } from "Utl";
const USRContext = createContext();

const INIT_STATE = {
  state: {
    view: 1
  },
  checked: {
    selected: [],
    all: false,
    only: false,
    indeterminate: false
  },
  filters: {
    instances: [],
    roles: [],
    active: true
  }
};

function USRProvider({ children }) {
  const {
    ASTATE: { ATYPE, GLB_ORGANISATION }
  } = useAState();
  const {
    DIALOG,
    DACTIONS: { openNotification }
  } = useDash();
  const [state, setState] = useState(INIT_STATE.state);

  const [user, setUser] = useState();
  const [users, setUsers] = useState([]);
  const [organisation, setOrganisation] = useState(undefined);
  const [filters, setFilters] = useState(INIT_STATE.filters);
  const [checked, setChecked] = useState(INIT_STATE.checked);

  const { sendAPI, loadingAPI } = useAPI({});

  const FETCH_USERS = useCallback(organisationGuid => {
    sendAPI({
      method: "POST",
      url: API_USERS,
      payload: {
        firstname: null,
        surname: null,
        pagenumber: 0,
        organisationGuid
      },
      callback: ({ response }) => setUsers(response),
      rejected: () =>
        openNotification({ variant: "error", message: "ERROR LOADING USERS" })
    });
  }, []);

  useEffect(() => {
    FETCH_USERS(ATYPE === 1 ? undefined : GLB_ORGANISATION.ID);
  }, [ATYPE, GLB_ORGANISATION, FETCH_USERS]);

  console.log();

  const SELECT_ORG = selected => {
    const guid = !selected || selected.organisationGuid;

    setOrganisation({
      ...selected
    });

    API({
      method: "GET",
      url: `${API_BFFT}organisation/${guid}`,
      callback: ({ response }) => {
        setFilters({
          instances: instanceSelects(response.result),
          roles: response.roles
        });
      },
      reject: () => {
        setOrganisation(undefined);
        openNotification({
          variant: "error",
          message: "ERROR FINDING ORGANISATION"
        });
        FETCH_USERS(undefined);
      }
    });

    FETCH_USERS(guid);
  };

  const SELECT_USER = async id => {
    const FETCH_ORG = async id => {
      const returned = await API({
        method: "GET",
        url: `${API_BFFT}organisation/${id}`,
        reject: () => {
          openNotification({
            variant: "error",
            message: "ERROR FINDING USERS ORGANISATION"
          });
        }
      });

      return returned.response;
    };

    API({
      method: "GET",
      url: `${API_BFF}user/${id}`,
      callback: ({ response }) => {
        (async () => {
          const organisation =
            ATYPE === 1
              ? await FETCH_ORG(response.organisation.organisationGuid)
              : GLB_ORGANISATION;

          if (organisation) {
            const instances =
              ATYPE === 1 ? organisation.result : GLB_ORGANISATION.instances;

            const instance = findInstanceBFF({
              nodeID: response.instanceGuid,
              instances
            });

            setUser({
              ...response,
              instance,
              organisation: {
                ...organisation,
                ...response.organisation
              }
            });
            setState({ view: 2 });
          }
        })();
      },
      reject: () => {
        openNotification({
          variant: "error",
          message: "ERROR FINDING USERS"
        });
      }
    });
  };

  const NEW_USER = useCallback(id => {
    setUser("NEW");
    setState(prev => ({
      ...prev,
      view: 2
    }));
  }, []);

  const deleteUsers = async () => {
    DIALOG.continueConfirm({
      variant: "continue",
      title: {
        1: "ARE YOU SURE YOU WANT TO DELETE THIS USER?",
        2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
        3: "SUCCESS DELETING USER",
        4: "ERROR DELETING USER"
      },
      actions: { ok: "YES", cancel: "NO", exit: "CONTINUE" }
    }).then(response => {
      if (response === "ACCEPT") {
        (async () => {
          let value, error, message;
          const userID = checked.selected[0];
          const response = await API_DELETE_USERS(userID);
          if (!error) {
            value = "SUCCESS";
            const userIDX = userFIND(users, userID);
            const updatedUsers = removeUserUI(users, userIDX.idx);
            setChecked(INIT_STATE.checked);
            setUsers(updatedUsers);
          }
          if (error) {
            value = "ERROR";
            message = error;
          }
          DIALOG.confirmationResponse({
            value,
            error,
            message
          });
        })();
      } else if (response === "REJECT") {
        console.log("rejected confirmation");
      }
    });
  };

  const userFIND = (USERS, ID) => {
    for (let i = 0; i < USERS.length; i++) {
      if (USERS[i].id === ID) {
        return {
          idx: i,
          user: USERS[i]
        };
      }
    }
  };

  const removeUserUI = (USERS, IDX) => {
    const updated = [...USERS];
    updated.splice(IDX, 1);
    return updated;
  };

  function backToUsers() {
    setState(prev => ({
      ...prev,
      view: 1
    }));
    setUser(undefined);
    setOrganisation(undefined);
  }

  const onCheck = id => {
    let newChecked = [];
    const checkedIndex = checked.selected.indexOf(id);
    if (checkedIndex === -1) {
      newChecked = newChecked.concat(checked.selected, id);
    } else if (checkedIndex === 0) {
      newChecked = newChecked.concat(checked.selected.slice(1));
    } else if (checkedIndex === checked.selected.length - 1) {
      newChecked = newChecked.concat(checked.selected.slice(0, -1));
    } else if (checkedIndex > 0) {
      newChecked = newChecked.concat(
        checked.selected.slice(0, checkedIndex),
        checked.selected.slice(checkedIndex + 1)
      );
    }
    setChecked({ ...checked, selected: newChecked });
  };

  const onCheckAll = () => {
    let all;
    let selected;
    if (checked.all === false) {
      all = true;
      selected = users.map(n => n.id);
    } else {
      all = false;
      selected = [];
    }
    setChecked(prev => ({ ...prev, all, selected }));
  };

  const USRSTATE = {
    state,
    user,
    users,
    organisation,
    filters,
    checked,
    loadingAPI
  };

  const USRACTIONS = {
    SELECT_ORG,
    SELECT_USER,
    NEW_USER,
    deleteUsers,
    backToUsers,
    onCheck,
    onCheckAll
  };

  return (
    <USRContext.Provider value={{ USRSTATE, USRACTIONS }}>
      {state.view === 1 && <Users />}
      {state.view === 2 && <UProvider />}
    </USRContext.Provider>
  );
}

const useUSRState = () => {
  const { USRSTATE, USRACTIONS } = useContext(USRContext);
  return {
    USRSTATE,
    USRACTIONS
  };
};

export { USRContext, USRProvider, useUSRState };
