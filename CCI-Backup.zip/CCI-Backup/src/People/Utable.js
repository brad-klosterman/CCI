import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { Table, Grid } from "@material-ui/core";

/// USERS TABLE
////////////////////////////////////////////////////////////////////////////////
const UsersTable = props => {
  const { classes, children } = props;

  return (
    <Grid item xs={12}>
      <Table
        className={classes.table}
        aria-labelledby="users-table"
        component="div"
      >
        {children}
      </Table>
    </Grid>
  );
};

const styles = theme => ({
  root: {
    boxShadow: "none",
    width: "100%",
    borderRadius: "0px",
    zIndex: "1111"
    // marginTop: theme.spacing.unit * 3,
  },
  main: {
    display: "flex",
    flexDirection: "row"
  },
  rootCondense: {
    boxShadow: "none",
    flexBasis: "25%"
  },
  table: {
    fontSize: "33px",
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    paddingBottom: 0,
    paddingTop: 0
  },
  tableWrapper: {
    overflowX: "auto"
  }
});

export default withStyles(styles)(UsersTable);
