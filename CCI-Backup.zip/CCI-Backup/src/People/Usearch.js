import React, { useState, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import cls from "classnames";
import {
  Collapse,
  FormGroup,
  FormControlLabel,
  Grid,
  TextField,
  Checkbox,
  Button
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Selector } from "Components";

const Usearch = memo(
  ({
    organisation,
    filters,
    updateParam,
    params,
    SELECT_ORG,
    ATYPE,
    GLB_SELECTOR
  }) => {
    const cx = useStyles();
    const [expanded, setExpanded] = useState(false);
    const [active, setActive] = useState(true);
    const { firstname, lastname, email, instance, role } = params;

    const onCheckbox = name => ev => {
      setActive(ev.target.checked ? name : undefined);
      updateParam({
        value: ev.target.checked ? name : undefined,
        name: "active"
      });
    };

    console.log(organisation);

    return (
      <Grid item xs={12}>
        <Grid container spacing={4} className={cx.root}>
          <Grid item xs={3}>
            <TextField
              label="First Name"
              name="firstname"
              value={firstname || ""}
              onChange={e => updateParam(e.target)}
              placeholder="Seach First Name"
              variant="outlined"
              fullWidth
            />
          </Grid>
          <Grid item xs={3}>
            <TextField
              label="Last Name"
              name="lastname"
              value={lastname || ""}
              onChange={e => updateParam(e.target)}
              placeholder="Seach Last Name"
              variant="outlined"
              fullWidth
            />
          </Grid>
          <Grid item xs={3}>
            <TextField
              label="Email"
              name="email"
              value={email || ""}
              onChange={e => updateParam(e.target)}
              placeholder="Seach Last Email"
              variant="outlined"
              fullWidth
            />
          </Grid>
          <Grid
            item
            xs={3}
            className={cx.moreSearch}
            onClick={() => setExpanded(prevExpanded => !prevExpanded)}
          >
            <Button
              variant="outlined"
              color="secondary"
              fullWidth
              aria-expanded={expanded}
            >
              SEARCH OPTIONS
              <ExpandMoreIcon
                className={cls(cx.expand, {
                  [cx.expandOpen]: expanded
                })}
              />
            </Button>
          </Grid>
        </Grid>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <Grid container spacing={4} className={cx.gridContainer}>
            <Selector
              id="Organisation"
              items={GLB_SELECTOR[1] || []}
              itemID="organisationName"
              value={""}
              onSelect={e => SELECT_ORG(e.target.value)}
              width={3}
              deselect
              disabaled={ATYPE === 2}
            />
            <Selector
              id="Instance"
              items={filters.instances || []}
              itemID="instanceName"
              value={instance || ""}
              onSelect={e => updateParam(e.target)}
              width={3}
              disabled={!organisation}
              deselect
            />
            <Selector
              id="Role"
              items={filters.roles || []}
              itemID="roleName"
              value={role || ""}
              onSelect={e => updateParam(e.target)}
              width={3}
              disabled={!organisation}
              outlined
              deselect
            />
            <Grid item xs={3}>
              <FormGroup row>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={active === "true"}
                      onChange={onCheckbox("true")}
                      value="active"
                    />
                  }
                  label="Active"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={active === "false"}
                      onChange={onCheckbox("false")}
                      value="inactive"
                    />
                  }
                  label="Inactive"
                />
              </FormGroup>
            </Grid>
          </Grid>
        </Collapse>
      </Grid>
    );
  }
);

const useStyles = makeStyles(theme => ({
  root: {
    margin: "-16px",
    paddingTop: "48px"
  },
  gridContainer: {
    marginTop: "16px",
    marginBottom: "-16px"
  },
  expand: {
    transform: "rotate(0deg)",
    padding: "0px",
    transition: theme.transitions.create("transform", {
      duration: theme.transitions.duration.shortest
    })
  },
  expandOpen: {
    transform: "rotate(180deg)"
  },
  moreSearch: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    cursor: "pointer"
  },
  moreTitle: {
    width: "100%"
  },
  viewMore: {
    display: "flex",
    alignItems: "center"
  },
  formControl: {
    // padding: theme.spacing.unit,
    minWidth: 120
  }
}));

export default Usearch;
