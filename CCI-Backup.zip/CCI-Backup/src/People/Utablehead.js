import React, { useState, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel,
  Checkbox,
  Menu,
  MenuItem,
  IconButton
} from "@material-ui/core";
import Tooltip from "@material-ui/core/Tooltip";
import MenuIcon from "@material-ui/icons/Menu";

const UsersTableHead = memo(
  ({
    order,
    checked,
    onCheckAll,
    updateOrder,
    NEW_USER,
    exportUsers,
    deleteUsers
  }) => {
    const cx = useStyles();
    const [anchorEl, setAnchorEl] = useState(null);

    function menuSelect(value) {
      const action = {
        NEW_USER,
        exportUsers,
        deleteUsers
      };
      action[value]();
      setAnchorEl(null);
    }

    function handleMenu(event) {
      setAnchorEl(event.currentTarget);
    }
    function closeMenu() {
      setAnchorEl(null);
    }

    const rows = [
      {
        id: "firstname",
        numeric: false,
        label: "First Name",
        align: "left",
        classes: cx.first
      },
      {
        id: "lastname",
        numeric: false,
        label: "Last Name",
        align: "left",
        classes: cx.last
      },
      {
        id: "organisation.organisationName",
        numeric: false,
        label: "Organisation",
        align: "left",
        classes: cx.organisation
      },
      {
        id: "dateCreated",
        numeric: true,
        label: "Date Created",
        align: "left",
        classes: cx.date
      }
    ];

    return (
      <TableHead className={cx.root} component="div">
        <TableRow className={cx.row} component="div">
          <TableCell component="div" className={cx.checkbox}>
            <Checkbox
              indeterminate={checked.indeterminate}
              checked={checked.all}
              onChange={onCheckAll}
              color="default"
            />
          </TableCell>
          {rows.map(row => (
            <TableCell
              key={row.id}
              sortDirection={order.field === row.id ? order.direction : false}
              className={row.classes}
              component="div"
              align={row.align}
            >
              <Tooltip
                title="Sort"
                placement={row.numeric ? "bottom-end" : "bottom-start"}
                enterDelay={300}
              >
                <TableSortLabel
                  classes={{
                    root: cx.title,
                    active: cx.activeTitle,
                    icon: cx.sortIcon
                  }}
                  active={order.field === row.id}
                  direction={order.direction}
                  onClick={() => updateOrder(row.id)}
                >
                  {row.label}
                </TableSortLabel>
              </Tooltip>
            </TableCell>
          ))}
          <TableCell component="div" className={cx.menu} align="right">
            <IconButton aria-haspopup="true" onClick={handleMenu}>
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-users"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: "top",
                horizontal: "right"
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "right"
              }}
              open={Boolean(anchorEl)}
              onClose={closeMenu}
            >
              <MenuItem onClick={() => menuSelect("NEW_USER")}>
                CREATE NEW USER
              </MenuItem>
              {checked.length && (
                <>
                  <MenuItem onClick={() => menuSelect("exportUsers")}>
                    EXPORT USERS
                  </MenuItem>
                  <MenuItem onClick={() => menuSelect("deleteUsers")}>
                    DELETE USER
                  </MenuItem>
                  <MenuItem>SEND ACTIVATION EMAIL</MenuItem>
                </>
              )}
            </Menu>
          </TableCell>
        </TableRow>
      </TableHead>
    );
  }
);

const useStyles = makeStyles(theme => ({
  root: {
    // marginBottom: 4
  },
  row: {
    display: "flex",
    alignItems: "center",
    height: 64,
    backgroundColor: "white",
    boxShadow: theme.boxShadow
    // borderTop: `1px solid ${theme.grey[2]}`,
    // borderBottom: `1px solid ${theme.grey[2]}`
  },
  checkbox: {
    paddingRight: 8,
    color: theme.grey[2]
  },
  title: {
    fontWeight: 600
  },
  activeTitle: {
    fontWeight: 800
    // textDecoration: "underline"
  },
  first: {
    width: "22%"
  },
  last: {
    width: "22%"
  },
  organisation: {
    width: "32%"
  },
  date: {
    width: "14%",
    paddingRight: 4
  },
  menu: {
    color: theme.grey[2]
  }
}));

export default UsersTableHead;
