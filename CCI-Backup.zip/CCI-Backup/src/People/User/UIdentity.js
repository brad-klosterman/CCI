import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Tooltip, Typography } from "@material-ui/core";
import { useUState } from "./UState";
import { useAState, useDash } from "state";
import {
  ExpansionPanel,
  TreeSelect,
  TreeModal,
  MultiSelect,
  useTreeSelect,
  useModalSelect,
  ModalSelect,
  CSwitch
} from "Components";
import Clear from "@material-ui/icons/DeleteForever";
import AddIcon from "@material-ui/icons/LibraryAdd";

function UIdentity() {
  const cx = useStyles();
  const {
    ASTATE: { GLB_SELECTOR }
  } = useAState();
  const {
    DACTIONS: { openNotification },
    DIALOG
  } = useDash();
  const {
    USTATE: { ID, selector, userType },
    UACTIONS: { updateID }
  } = useUState();

  const { treeActions, treeOpen } = useTreeSelect();
  const modalSelect = useModalSelect(selector);
  const { closeSelect } = treeActions;
  const [expanded, setExpanded] = useState([]);

  function changePanel(panel) {
    setExpanded(prevExpanded => {
      if (panel.length === 1) {
        if (panel[0] === prevExpanded[0]) {
          return [];
        } else {
          return panel;
        }
      } else {
        if (panel[1] === prevExpanded[1]) {
          return [panel[0]];
        } else {
          return panel;
        }
      }
    });
  }

  const modalTreeProps = {
    open: Boolean(treeOpen),
    onSelect: updateID,
    closeSelect,
    data:
      treeOpen && ID[treeOpen[0]]["data"]["instances"][treeOpen[1]]["areas"],
    location: treeOpen,
    selected: treeOpen && treeOpen[3]
  };

  function newOrganisation() {
    modalSelect.openModal({
      selector: GLB_SELECTOR[1],
      id: "organisation"
    });
  }

  function newInstance(orgID) {
    setExpanded([orgID]);
    modalSelect.openModal({
      selector: selector[orgID],
      id: "instance",
      location: orgID
    });
  }

  function deleteInstance({ location }) {
    DIALOG.confirm({
      variant: "warning",
      title: {
        1: "ARE YOU SURE YOU WANT TO DELETE?",
        2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
        3: "SUCCESS SAVING INSTANCE"
      },
      message: {
        1: undefined,
        2: undefined,
        3: undefined
      },
      actions: { ok: "CONFIRM", cancel: "CANCEL", exit: "CONTINUE" }
    }).then(res => {
      /// API call
      console.log("then", res);

      setTimeout(() => {
        updateID({ action: "REMOVE_INSTANCE", location });
        return DIALOG.confirmationResponse({ value: "SUCCESS" });
      }, 4000);
    });
    // updateID({ action: "REMOVE_INSTANCE", location });
    // setExpanded(location);
  }

  function addArea({ location }) {
    updateID({ action: "NEW_AREA", location });
    setExpanded(location);
    treeActions["openSelect"](location);
  }

  function deletePanel() {}

  function modalCB({ id, location, payload }) {
    const SELECT = {
      organisation: () => {
        updateID({ action: "NEW_ORGANISATION", payload });
      },
      instance: () => {
        updateID({ action: "NEW_INSTANCE", location, payload });
        setExpanded([...location, payload[0]]);
        treeActions["openSelect"]([...location, payload[0], 0]);
      }
    };

    SELECT[id]();
  }

  return (
    <>
      {userType === "CCI" && (
        <Grid item xs={12} className={cx.addRow}>
          <div className={cx.addBTN} onClick={newOrganisation}>
            <AddIcon fontSize="small" color="inherit" className={cx.addIcon} />
            <Typography color="inherit" className={cx.title} variant="h5">
              ADD ORGANISATION
            </Typography>
          </div>
        </Grid>
      )}
      <Grid item xs={12}>
        {Object.values(ID).map(({ id: orgID, name, instances, data }) => (
          <ExpansionPanel
            panel={[orgID]}
            key={orgID}
            changePanel={changePanel}
            expanded={expanded[0] === orgID}
            title={name}
            onAdd={() => newInstance(orgID)}
            onDelete={() => deletePanel(orgID)}
            tooltip={{ add: "Add Instance", delete: "Delete Organisation" }}
          >
            <Grid item xs={12}>
              {Object.values(instances).map(
                ({ id, name, areas, defaultArea }) => {
                  const instProps = { defaultArea, selects: data.roles };
                  const location = [orgID, id];
                  return (
                    <ExpansionPanel
                      panel={location}
                      key={id}
                      changePanel={changePanel}
                      expanded={expanded[1] === id}
                      title={name}
                      onAdd={() =>
                        addArea({ location: [...location, areas.length] })
                      }
                      onDelete={() => deleteInstance({ location })}
                      tooltip={{ add: "Add Area", delete: "Delete Instance" }}
                    >
                      {(areas || []).map((area, idx) => (
                        <Roles
                          {...area}
                          {...instProps}
                          updateID={updateID}
                          key={area.rowGuid + idx}
                          actions={treeActions}
                          ark={[orgID, id, idx, area.rowGuid]}
                          idx={idx}
                          classes={cx}
                        />
                      ))}
                    </ExpansionPanel>
                  );
                }
              )}
            </Grid>
          </ExpansionPanel>
        ))}
      </Grid>

      <TreeModal {...modalTreeProps} />
      <ModalSelect {...modalSelect} onSelect={modalCB} />
    </>
  );
}

const useStyles = makeStyles(theme => ({
  addRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingBottom: "0px!important"
  },
  addBTN: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    cursor: "pointer",
    "&:hover": {
      color: theme.systemColors[1]
    }
  },
  addIcon: {
    marginRight: 8,
    fontSize: 18,
    "&:hover": {
      color: theme.systemColors[1]
    }
  },
  deleteBtn: {
    paddingRight: 0,
    marginLeft: 8,
    color: theme.grey[2],
    fontSize: 20,
    cursor: "pointer",
    "&:hover": {
      color: theme.palette.error.main
    }
  },
  actions: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  }
}));

function Roles({
  classes,
  ark,
  id,
  name,
  defaultArea,
  rowGuid,
  roles,
  actions,
  selects,
  deleteArea,
  updateID
}) {
  return (
    <>
      <TreeSelect label="Area" id={ark} area={{ rowGuid, name }} {...actions}>
        <Tooltip title="Make Default Area">
          <div className={classes.switchbox}>
            <CSwitch
              value={ark}
              checked={defaultArea === rowGuid}
              onChange={() =>
                updateID({ action: "UPDATE_DEFAULT", location: ark })
              }
            />
          </div>
        </Tooltip>
      </TreeSelect>
      <MultiSelect
        label="Roles"
        items={selects}
        value={roles}
        nameID="roleName"
        onSelect={roles =>
          updateID({ action: "UPDATE_ROLES", location: ark, payload: roles })
        }
        width={6}
      >
        <Tooltip title="Delete Area">
          <Clear
            fontSize="small"
            onClick={() => updateID({ action: "REMOVE_AREA", location: ark })}
            className={classes.deleteBtn}
          />
        </Tooltip>
      </MultiSelect>
    </>
  );
}

export default UIdentity;
