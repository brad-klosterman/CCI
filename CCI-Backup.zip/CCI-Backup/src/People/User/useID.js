import { useEffect, useState, useCallback, useRef } from "react";
import { fetchOrganisation, getAPI, AREAS_API } from "Api";
import { useAState } from "state";
import { findNode } from "Utl";

const useID = ({ identities, organisation, triggerSaveState }) => {
  const {
    ASTATE: { ATYPE, GLB_ORGANISATION }
  } = useAState();
  const ID = useRef([]);
  const [data, setData] = useState({});
  const triggerUpdate = useRef(false);

  const [selector, setSelector] = useState({});

  const matchInstance = (usrIns, orgIns) =>
    usrIns.find(e => e.instanceGuid === orgIns);

  const matchAreas = async (mappings, insAreas) => {
    return mappings.reduce(async (acc, i) => {
      const accumulator = await acc;
      const foundArea = await findNode({
        nodeID: i.areaGuid,
        nodes: insAreas
      });

      if (foundArea) {
        return accumulator.concat({
          id: foundArea.area.id,
          rowGuid: i.areaGuid,
          name: foundArea.area.name,
          roles: i.roles
        });
      }
      return accumulator;
    }, []);
  };

  useEffect(() => {
    const newID = {};
    const selects = {};

    async function getAreaTree(organisationGuid, rootRowGuid) {
      const { areaNode: instanceNode } = await getAPI({
        ID: organisationGuid + "/" + rootRowGuid,
        API: AREAS_API
      });

      return instanceNode;
    }

    async function makeInstances({
      organisation,
      instances,
      identityInstances
    }) {
      let identityObject = {};
      let dataObject = {};
      let selects = {};

      for (const {
        instance: { instanceGuid, rootRowGuid, instanceName }
      } of instances) {
        const areaTree = await getAreaTree(organisation, rootRowGuid);
        let selected = false;

        dataObject[instanceGuid] = {
          id: instanceGuid,
          name: instanceName,
          areas: areaTree && areaTree.children
        };

        if (identityInstances) {
          const matched = await matchInstance(identityInstances, instanceGuid);

          if (matched) {
            identityObject[instanceGuid] = {
              id: instanceGuid,
              name: instanceName,
              areas: await matchAreas(matched.areas, areaTree.children),
              defaultArea: matched.defaultAreaGuid
            };

            selected = true;
          }
        }

        selects[instanceGuid] = {
          instanceGuid,
          instanceName,
          selected
        };
      }

      return {
        identityObject,
        dataObject,
        selects
      };
    }

    if (ATYPE === 1 && organisation && identities !== "NEW") {
      (async () => {
        const homeInstances = await makeInstances({
          organisation: organisation.organisationGuid,
          instances: organisation.result
        });

        newID[organisation.organisationGuid] = {
          id: organisation.organisationGuid,
          name: organisation.organisationName,
          instances: homeInstances.identityObject,
          data: {
            instances: homeInstances.dataObject,
            roles: organisation.roles
          }
        };

        selects[organisation.organisationGuid] = { ...homeInstances.selects };

        for (const {
          organisationGuid,
          organisationName,
          instances
        } of identities) {
          if (!(organisationGuid in newID)) {
            const organisation = await fetchOrganisation(organisationGuid);

            const identityInstances = await makeInstances({
              organisation: organisationGuid,
              instances: organisation.result,
              identityInstances: instances
            });

            newID[organisationGuid] = {
              id: organisationGuid,
              name: organisationName,
              instances: identityInstances.identityObject,
              data: {
                instances: identityInstances.dataObject,
                roles: organisation.roles
              }
            };

            selects[organisationGuid] = { ...identityInstances.selects };
          } else {
            const instancesObject = {};

            for (const { instanceGuid } of instances) {
              const matched = await matchInstance(instances, instanceGuid);

              if (matched) {
                const instanceRef =
                  newID[organisationGuid]["data"]["instances"][instanceGuid];

                instancesObject[instanceGuid] = {
                  id: instanceGuid,
                  name: instanceRef.name,
                  areas: await matchAreas(matched.areas, instanceRef.areas),
                  defaultArea: matched.defaultAreaGuid
                };

                selects[organisationGuid][instanceGuid] = {
                  ...selects[organisationGuid][instanceGuid],
                  selected: true
                };
              }
            }

            newID[organisationGuid] = {
              ...newID[organisationGuid],
              instances: instancesObject
            };
          }
        }
      })();
    }

    setData(newID);
    setSelector(selects);
  }, [ATYPE, identities, organisation]);

  useEffect(() => {
    if (ATYPE === 2 && identities) {
      (async () => {
        const newID = {};
        const instanceObject = {};
        const instanceID = {};
        const selects = {};

        for (const {
          instance: { instanceGuid, rootRowGuid, instanceName }
        } of identities[GLB_ORGANISATION.id]) {
          const matched = await matchInstance(
            GLB_ORGANISATION.instances,
            instanceGuid
          );

          const { areaNode: instanceNode } = await getAPI({
            ID: GLB_ORGANISATION.id + "/" + rootRowGuid,
            API: AREAS_API
          });

          instanceObject[instanceGuid] = {
            id: instanceGuid,
            name: instanceName,
            areas: instanceNode.children
          };

          selects[GLB_ORGANISATION.id][instanceGuid] = {
            instanceGuid,
            instanceName,
            selected: Boolean(matched)
          };

          if (matched) {
            instanceID[instanceGuid] = {
              id: instanceGuid,
              name: instanceName,
              areas: await matchAreas(matched.areas, instanceNode.children),
              defaultArea: matched.defaultAreaGuid
            };
          }
        }
        newID[GLB_ORGANISATION.id] = {
          id: GLB_ORGANISATION.id,
          name: GLB_ORGANISATION.name,
          instances: instanceID,
          data: {
            roles: GLB_ORGANISATION.roles,
            instances: instanceObject
          }
        };
        setData(newID);
        setSelector(selects);
        triggerUpdate.current = true;
      })();
    }
  }, [ATYPE, GLB_ORGANISATION, identities]);

  const updateID = useCallback(
    ({ action, location, payload }) => {
      let key1, key2, key3;
      let organisation, instances, instance, areas, area;
      if (location) {
        key1 = location[0];
        key2 = location[1];
        key3 = location[2];
      }

      if (key1) {
        organisation = data[key1];
        if (organisation) {
          instances = organisation["instances"];
        }
      }
      if (key2) {
        instance = instances[key2];
        areas = [...instance["areas"]];
      }
      if (key3 !== undefined) {
        area = areas[key3];
      }

      const initArea = { id: "", name: "", rowGuid: "", roles: [] };

      const state1 = value => ({
        ...data,
        [key1]: {
          ...organisation,
          instances: {
            ...value
          }
        }
      });

      const state2 = value =>
        state1({
          ...instances,
          [key2]: {
            ...instance,
            ...value
          }
        });

      const actions = {
        NEW_ORGANISATION: () => {
          (async () => {
            const orgRTN = await fetchOrganisation(payload[0]);
            let newOrg;
            if (orgRTN) {
              newOrg = {
                id: payload[0],
                name: payload[1],
                instances: [],
                data: {
                  roles: orgRTN.roles,
                  instances: orgRTN.result
                }
              };
              setData({ ...data, newOrg });
            }
            triggerUpdate.current = true;
          })();
        },
        NEW_AREA: () => {
          setData(state2({ areas: [...areas, initArea] }));
          triggerSaveState({ type: "NEW_AREA" });
          triggerUpdate.current = true;
        },
        REMOVE_AREA: () => {
          let defaultArea;
          if (area.rowGuid === instance.defaultArea) {
            defaultArea = "";
          } else {
            defaultArea = instance.defaultArea;
          }

          areas.splice(key3, 1);
          setData(state2({ areas, defaultArea }));

          triggerSaveState({ type: "DELETE_AREA" });

          triggerUpdate.current = true;
        },
        UPDATE_AREA: () => {
          // console.log("UPDATE-AREA", payload);
          /// check if area already in use
          areas.splice(key3, 1, {
            ...area,
            ...payload
          });

          setData(state2({ areas }));
          triggerSaveState({ type: "UPDATE_AREA" });
          triggerUpdate.current = true;
        },
        NEW_INSTANCE: () => {
          let updatedInstances = { ...instances };
          const id = payload[0];
          const name = payload[1];

          updatedInstances[id] = {
            id,
            name,
            areas: [initArea],
            defaultArea: ""
          };
          setData(state1(updatedInstances));
          setSelector(prev => ({
            ...prev,
            [key1]: {
              ...prev[key1],
              [id]: { ...prev[key1][id], selected: true }
            }
          }));
          triggerSaveState({ type: "NEW_INSTANCE" });
          triggerUpdate.current = true;
        },
        REMOVE_INSTANCE: () => {
          let updatedInstances = { ...instances };
          delete updatedInstances[key2];
          setData(state1(updatedInstances));
          setSelector(prev => ({
            ...prev,
            [key1]: {
              ...prev[key1],
              [key2]: { ...prev[key1][key2], selected: false }
            }
          }));
          triggerUpdate.current = true;
        },
        UPDATE_ROLES: () => {
          areas.splice(key3, 1, {
            ...area,
            roles: payload
          });
          setData(state2({ areas }));
          triggerSaveState({ type: "UPDATE_ROLES" });
          triggerUpdate.current = true;
        },
        UPDATE_DEFAULT: () => {
          setData(state2({ defaultArea: location[3] }));
          triggerSaveState({ type: "UPDATE_DEFAULT" });
          triggerUpdate.current = true;
        }
      };

      actions[action](payload);
    },
    [data, triggerSaveState]
  );

  if (triggerUpdate.current) {
    ID.current = data;
  }

  return {
    ID: data,
    selector,
    updateID
  };
};

export default useID;
