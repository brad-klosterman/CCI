import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Tabs, Tab, Button, Grid } from "@material-ui/core";
import { useUState } from "./UState";
import { UBasic, UIdentity } from "People";
import { SaveButton } from "Components";
import { useDash } from "state";
import { useUSRState } from "../UsersState";
import ArrowBack from "@material-ui/icons/ArrowBackIos";

export default function UInfo({ user }) {
  const cx = useStyles();
  const { DIALOG } = useDash();
  const {
    USRSTATE: { state },
    USRACTIONS: { backToUsers }
  } = useUSRState();
  const {
    USTATE: { saveState, actions, loadingAPI },
    UACTIONS: { saveAPI, onSaveUser }
  } = useUState();

  const [tab, setTab] = useState(0);

  function onTab(event, newIndex) {
    setTab(newIndex);
  }

  function onBack() {
    const onExit = status => {
      if (status === "CONTINUE") {
        backToUsers();
      }
    };

    if (saveState.updated === false) {
      backToUsers();
    } else {
      DIALOG.continueConfirm({
        variant: "continue",
        title: {
          1: "WOULD YOU LIKE TO SAVE FIRST?",
          2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
          3: "SUCCESS SAVING USER",
          4: "ERROR SAVING USER"
        },
        message: {
          1: undefined,
          2: undefined,
          3: undefined,
          4: undefined
        },
        actions: { ok: "SAVE", cancel: "NO", exit: "CONTINUE" },
        onExit
      }).then(res => {
        if (res === "ACCEPT") {
          (async () => {
            const saved = await saveAPI();
            if (saved.value === "SUCCESS") {
              return DIALOG.confirmationResponse({
                value: "SUCCESS"
              });
            } else {
              return DIALOG.confirmationResponse({
                value: "ERROR",
                message: saved.error
              });
            }
          })();
        } else if (res === "REJECT") {
          backToUsers();
        }
      });
    }
  }

  /// ACTIONS

  let buttons;

  if (actions === 1) {
    buttons = (
      <SaveButton
        label="SAVE USER AND ADD IDENTITY ROLES"
        onClick={() => onSaveUser({ type: "NEW" })}
        classes={cx.btn}
        {...{ loadingAPI }}
      />
    );
  } else {
    buttons = (
      <>
        <SaveButton
          onClick={() => onSaveUser({ type: "EXISTING" })}
          classes={cx.btn}
          {...{ loadingAPI }}
        />
        <Button
          className={cx.btn}
          variant="outlined"
          color="primary"
          onClick={saveAPI}
          disabled
        >
          RESEND ACTIVATION EMAIL
        </Button>
      </>
    );
  }

  if (state.view !== 2) {
    return null;
  }

  return (
    <div className={cx.root}>
      <div className={cx.tabWrapper}>
        <div className={cx.backBTN} onClick={onBack}>
          <ArrowBack className={cx.backArrow} /> BACK TO USERS
        </div>
        <Tabs value={tab} onChange={onTab} className={cx.tabs}>
          <Tab
            label="BASIC INFORMATION"
            autoFocus
            classes={{ root: cx.tab, selected: cx.selected }}
          />
          <Tab
            label="IDENTITY AND ROLES"
            classes={{ root: cx.tab, selected: cx.selected }}
            disabled={Boolean(actions === 1)}
          />
        </Tabs>
      </div>
      <div className={cx.contentWrapper}>
        <Grid container spacing={4} className={cx.root}>
          {tab === 0 && <UBasic />}
          {tab === 1 && <UIdentity />}
          <Grid item className={cx.actions}>
            {buttons}
          </Grid>
        </Grid>
      </div>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    // backgroundColor: "white",
    // padding: theme.spacing(4),
    // boxShadow: theme.boxShadow
  },
  tabWrapper: {
    width: "100%",
    marginBottom: 24,
    padding: 0
  },
  contentWrapper: {
    width: "100%",
    flexGrow: 1,
    backgroundColor: "white",
    padding: "36px 48px",
    boxShadow: theme.boxShadow
    // border: "1px solid",
    // borderRadius: 3,
    // borderColor: theme.grey[0]
  },

  backBTN: {
    width: 150,
    marginTop: 22,
    marginBottom: 22,
    fontWeight: 600,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    "&:hover": {
      color: theme.palette.primary.main
    }
  },
  backArrow: {
    fontSize: 14
  },

  actions: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    paddingTop: 32
  },
  btn: {
    margin: "0px 8px"
  },
  tabs: {
    marginBottom: 0,
    borderRadius: 0,
    minHeight: 44,

    backgroundColor: "transparent",
    "& button:last-child": {
      borderRight: 0
    }
  },
  tab: {
    fontSize: 14,
    minWidth: "50%",
    backgroundColor: "rgba(93, 93, 94, 0.1)",
    borderRight: "1px solid rgba(93, 93, 94, 0.1)",
    minHeight: 44
    // boxShadow: theme.boxShadowIn
  },
  selected: {
    color: "white",
    backgroundColor: theme.palette.primary.main,
    borderColor: theme.palette.primary.main
    // boxShadow: theme.boxShadow
  }
}));

// "<UBasic ref={basicRef} {...props.basic} />"

// <UIdentity ref={rolesRef} {...data2} />
//
// const data2 = {
//   userOrganisations: AppState.userOrganisations,
//   identity: user.identities,
//   userType: { cci: true, org: undefined }
// };
