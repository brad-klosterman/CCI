import React, {
  useState,
  useCallback,
  createContext,
  useContext,
  useMemo,
  useEffect
} from "react";
import { useAPI, API_BFF, fetchOrganisation } from "Api";
import { useAState, useDash, instanceSelects, findInstance } from "state";
import { useUSRState, useID, UInfo } from "People";
import { useForm, parseEmail } from "Utl";
import { validate, validateBasic } from "./UFunctions";
const UContext = createContext();

function UProvider() {
  const {
    ASTATE: { ATYPE, GLB_SELECTOR }
  } = useAState();
  const {
    DIALOG,
    DACTIONS: { openNotification }
  } = useDash();
  const {
    USRSTATE: { user },
    USRACTIONS: { SELECT_USER }
  } = useUSRState();

  const { sendAPI, loadingAPI } = useAPI({});

  const [organisation, setOrganisation] = useState();
  const [identities] = useState(() => {
    if (user === "NEW") {
      return "NEW";
    }
    return user.identities;
  });
  const [actions, setActions] = useState(user === "NEW" ? 1 : 2);
  const [saveState, setSaveState] = useState({ updated: false, email: false });

  useEffect(() => {
    setOrganisation(
      user !== "NEW" && {
        ...user.organisation,
        instanceGuid: user.instanceGuid
      }
    );
    setActions(2);
  }, [user]);

  const triggerSaveState = useCallback(val => {
    setSaveState(val);
  }, []);

  const { ID, selector, updateID } = useID({
    identities,
    organisation,
    triggerSaveState
  });

  const memoUser = useMemo(() => {
    let organisation;
    let instance;
    let email;
    const selects = {
      organisations: [],
      instances: [],
      domains: []
    };

    if (ATYPE === 1) {
      if (user === "NEW") {
        organisation = "";
        instance = "";
        selects.organisations = GLB_SELECTOR[1];
      } else {
        /// run checks to see if the requeried data is available although it should be
        organisation = user.organisation;
        instance = user.instance;
        email = parseEmail(user.email);
        // selects.instances = instanceSelects(user.organisation.result);
        selects.domains = user.instance.instance.emailDomainWhiteList;
      }
    } else if (ATYPE === 2) {
      if (user === "NEW") {
        /// GLB ORGANISATION
        selects.instances = GLB_SELECTOR[2];
      } else {
        organisation = user.organisation;
        instance = user.instance;
        email = parseEmail(user.email);
        selects.domains = user.instance.instance.emailDomainWhiteList;
      }
    }

    return {
      firstname: {
        type: 1,
        label: "First Name",
        value: user.firstname || ""
      },
      lastname: {
        type: 1,
        label: "Last Name",
        value: user.lastname || ""
      },
      organisation: {
        type: 2,
        label: "Organisation",
        value: organisation.organisationName || "",
        itemID: "organisationName",
        items: selects.organisations,
        ready: user === "NEW" ? 0 : 1
      },
      instance: {
        type: 2,
        label: "Instance",
        itemID: "instanceName",
        value: instance.instance || "",
        items: selects.instances,
        ready: user === "NEW" ? 2 : 1
      },
      email: {
        type: 1,
        label: "Email",
        value: email ? email.address : ""
      },
      domain: {
        type: 2,
        label: "Domain",
        value: email ? email.domain : "",
        items: selects.domains,
        ready: 3
      },
      usertype: {
        type: 2,
        label: "User Type",
        value: user.userType || "NON-CCI",
        items: ["CCI", "NON-CCI"],
        ready: user === "NEW" ? 0 : 1
      },
      defaultlanguage: {
        type: 2,
        label: "Default Language",
        value: user.defaultLanguage || "",
        items: ["en-gb"]
      }
    };
  }, [ATYPE, user, GLB_SELECTOR]);

  const userDates = useMemo(() => {
    if (user === "NEW") {
      return "NEW";
    }
    return {
      dateCreated: {
        label: "Date Created",
        value: user.dateCreated
      },
      dateLastActive: {
        label: "Last Login Date",
        value: user.dateLastActive
      },
      dateActivated: {
        label: "Date Activated",
        value: undefined
      },
      dateUpdated: {
        label: "Date Updated",
        value: undefined
      }
    };
  }, [user]);

  const { formData, updateForm, updateSelects, updateError } = useForm({
    schema: memoUser
  });

  const updateBasic = event => {
    const name = event.target.name;

    if ((name === "email") | "domain") {
      setSaveState({ updated: true, email: "updatedEmail" });
    }

    updateForm(event);
  };

  async function selectOrg(id) {
    try {
      let orgRTN = await fetchOrganisation(id);
      if (orgRTN) {
        const selects = await instanceSelects(orgRTN.result);
        updateSelects([{ id: "instance", items: selects }]);
        setOrganisation({ organisationGuid: id, ...orgRTN });
      } else {
        console.log("ERROR - can't get Org");
      }
    } catch {
      console.log("ERROR");
    }
  }

  async function selectInstance(id) {
    const matched = findInstance(organisation.result, id);
    const domains = matched.instance.emailDomainWhiteList;
    updateSelects([{ id: "domain", items: domains }]);
    setOrganisation(prev => ({
      ...prev,
      instanceGuid: id
    }));
  }

  async function onSaveUser({ type }) {
    const method = user === "NEW" ? "POST" : "PUT";
    const valid = await validateUser();

    if (!valid.error) {
      const {
        firstname,
        lastname,
        email,
        domain,
        usertype,
        defaultlanguage
      } = formData;

      const data = {
        user: {
          userId: user.id,
          email: email.value + "@" + domain.value,
          organisationGuid: organisation.organisationGuid,
          instanceGuid: organisation.instanceGuid,
          firstname: firstname.value,
          lastname: lastname.value,
          defaultLanguage: defaultlanguage.value,
          userType: usertype.value
        },
        instances: valid.data
      };

      if (saveState.updated && user !== "NEW") {
        DIALOG.continueConfirm({
          variant: "continue",
          title: {
            1: "ARE YOU SURE YOU WANT TO CHANGE YOUR EMAIL?",
            2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
            3: "SUCCESS SAVING USER",
            4: "ERROR SAVING USER"
          },
          actions: { ok: "SAVE", cancel: "NO", exit: "CONTINUE" }
        }).then(res => {
          if (res === "ACCEPT") {
            (async () => {
              let value, message;

              await sendAPI({
                method,
                url: `${API_BFF}/user`,
                payload: data,
                callback: ({ response }) => {
                  value = "SUCCESS";
                },
                reject: ({ error }) => {
                  value = "ERROR";
                  message = error;
                }
              });

              DIALOG.confirmationResponse({
                value,
                message
              });
            })();
          } else if (res === "REJECT") {
            console.log("rejected confirmation");
          }
          setSaveState({ updated: false });
        });
      } else {
        sendAPI({
          method,
          url: `${API_BFF}user`,
          payload: data,
          callback: ({ response }) => {
            openNotification({
              variant: "success",
              message: "SUCCESS SAVING USERS"
            });
            if (user === "NEW") {
              SELECT_USER(response.createdUserGuid);
            }
          },
          rejected: ({ error }) => {
            openNotification({
              variant: "error",
              message: "ERROR SAVING USERS " + error.response.data.errors
            });
          }
        });
      }
    }
  }

  async function validateUser() {
    const { validIdentity, errorIdentity, formattedIdentity } = await validate(
      ID
    );
    const { validBasic, errorBasic } = await validateBasic(formData);

    if (validBasic && validIdentity) {
      return { error: false, data: formattedIdentity };
    } else if (!validBasic) {
      updateError(errorBasic);
      openNotification({
        variant: "error",
        message: "PLEASE COMPLETE ALL FIELDS FOR THE USERS BASIC INFORMATION"
      });
      return { error: true };
    } else if (!validIdentity) {
      openNotification({ variant: "error", message: errorIdentity });
      return { error: true };
    }
  }

  const USTATE = {
    ID,
    formData,
    selector,
    userDates,
    actions,
    userType: user.userType,
    saveState,
    loadingAPI
  };

  const UACTIONS = {
    updateBasic,
    selectOrg,
    selectInstance,
    updateID,
    onSaveUser
  };

  return (
    <UContext.Provider value={{ USTATE, UACTIONS }}>
      <UInfo {...{ user }} />
    </UContext.Provider>
  );
}

const useUState = () => {
  const { USTATE, UACTIONS } = useContext(UContext);
  return {
    USTATE,
    UACTIONS
  };
};

export { UContext, UProvider, useUState };
