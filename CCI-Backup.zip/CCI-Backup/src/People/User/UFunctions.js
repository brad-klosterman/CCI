export const validate = async identity => {
  let validIdentity = false;
  let errorIdentity = undefined;
  let formattedIdentity = [];

  const msg = {
    1: "Please select an Instance for ",
    2: "Please select an Area for ",
    3: "Please select an All Areas for ",
    4: "Please select a Role for ",
    5: "Please select a Default Area for "
  };

  Object.values(identity).forEach(({ id: orgID, name: orgName, instances }) => {
    if (Object.entries(instances).length === 0) {
      /// No Instances
    } else {
      Object.values(instances).forEach(
        ({ id: insID, name: insName, defaultArea, areas }, idx) => {
          let formattedRoles = [];

          if (!areas.length) {
            errorIdentity = msg[2] + orgName + " / " + insName;
          } else if (defaultArea === "" || defaultArea === undefined) {
            errorIdentity = msg[5] + orgName + " / " + insName;
          } else {
            areas.forEach(({ rowGuid: areaID, name: areaName, roles }) => {
              if (areaName === "") {
                errorIdentity = msg[3] + orgName + " / " + insName;
              } else if (!roles.length) {
                errorIdentity =
                  msg[4] + orgName + " / " + insName + " / " + areaName;
              } else {
                if (Object.entries(instances).length !== 0) {
                  formattedRoles.push({
                    areaId: areaID,
                    roles: roles.reduce(
                      (acc, role) => [...acc, role.roleGuid],
                      []
                    )
                  });
                }
              }
            });
          }
          formattedIdentity[idx] = {
            instanceGuid: insID,
            organisationGuid: orgID,
            defaultAreaGuid: defaultArea,
            roles: formattedRoles
          };
        }
      );
    }
  });

  if (!errorIdentity) {
    validIdentity = true;
  }

  return {
    validIdentity,
    errorIdentity,
    formattedIdentity
  };
};

export const validateBasic = async data => {
  let errorBasic = [];
  let validBasic = true;

  const msg = {
    1: "Please complete all fields"
  };

  Object.keys(data).forEach(key => {
    if (data[key]["value"] === "") {
      errorBasic.push(key);
      validBasic = false;
    }
  });

  return {
    errorBasic,
    validBasic
  };
};
