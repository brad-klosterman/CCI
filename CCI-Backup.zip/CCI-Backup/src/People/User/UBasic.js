import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, TextField, Divider, Typography } from "@material-ui/core";
import { useUState } from "./UState";
import { Selector } from "Components";
import { formatDate } from "Utl";

function UBasic() {
  const cx = useStyles();
  const {
    USTATE: { formData, userDates },
    UACTIONS: { updateBasic, selectOrg, selectInstance }
  } = useUState();

  if (!formData) {
    return null;
  }

  const disabled = {
    0: false,
    1: true,
    2: Boolean(!formData.organisation.value),
    3: Boolean(!formData.instance.value)
  };

  function handleUpdate(event) {
    console.log("handleupdate", event.target.name);
    if (event.target.name === "organisation") {
      selectOrg(event.target.value.organisationGuid);
    } else if (event.target.name === "instance") {
      selectInstance(event.target.value.instanceGuid);
    }
    updateBasic(event);
  }

  return (
    <>
      {Object.keys(formData || {}).map(function(i) {
        const item = formData[i];
        if (item.type === 1) {
          return (
            <Grid item xs={6} key={item.label}>
              <TextField
                label={item.label}
                value={item.value}
                name={i}
                variant="outlined"
                fullWidth
                onChange={updateBasic}
                error={item.error}
              />
            </Grid>
          );
        } else {
          return (
            <Selector
              key={item.label}
              id={item.label}
              items={item.items || []}
              itemID={item.itemID}
              value={item.value}
              onSelect={handleUpdate}
              disabled={disabled[item.ready]}
              error={item.error}
              width={6}
              outlined
            />
          );
        }
      })}
      <Grid item xs={12}>
        <Divider />
      </Grid>
      {userDates !== "NEW" && (
        <Grid item xs={12} className={cx.dateRow}>
          {Object.values(userDates).map(({ label, value }) => (
            <Typography variant="subtitle1" key={label} className={cx.date}>
              <b>{label}:</b> {formatDate(value)}
            </Typography>
          ))}
        </Grid>
      )}
    </>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    // padding: 32
  },
  selected: {
    color: "white",
    backgroundColor: theme.dark[1]
  },
  divider: {
    height: 4,
    backgroundColor: theme.dark[1]
  },
  dateRow: {
    display: "flex",
    alignItems: "center"
  },
  date: {
    width: "25%"
  }
}));

export default UBasic;
