import React, { memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { TableRow, TableCell, Checkbox, IconButton } from "@material-ui/core";
import ArrowRT from "@material-ui/icons/KeyboardArrowRight";
import { formatDate } from "Utl";

const UsersRow = memo(
  ({ user, SELECT_USER, checked, showChecked, onCheck }) => {
    const cx = useStyles();

    const { id, firstname, lastname, organisation, dateCreated } = user;

    // if (showChecked && !checked) {
    //   return null;
    // }

    function handleCheck(event) {
      event.stopPropagation();
      onCheck(id);
    }

    const RowView = () => (
      <>
        <TableCell className={cx.checkbox} component="div">
          <Checkbox
            checked={checked}
            color="secondary"
            onChange={handleCheck}
          />
        </TableCell>
        <TableCell className={cx.first} component="div">
          {firstname}
        </TableCell>
        <TableCell className={cx.last} component="div">
          {lastname}
        </TableCell>
        <TableCell className={cx.organisation} component="div">
          {organisation.organisationName}
        </TableCell>
        <TableCell className={cx.date} component="div">
          {formatDate(dateCreated)}
        </TableCell>
        <TableCell
          align="right"
          classes={{ root: cx.arrowRT }}
          component="div"
          onClick={() => SELECT_USER(id)}
        >
          <IconButton>
            <ArrowRT />
          </IconButton>
        </TableCell>
      </>
    );

    return (
      <TableRow
        tabIndex={-1}
        key={id}
        selected={checked}
        component="div"
        classes={{ root: cx.tableRow, selected: cx.rowSelected }}
      >
        <RowView />
      </TableRow>
    );
  }
);

const useStyles = makeStyles(theme => ({
  tableRow: {
    width: "100%",
    height: "64px",
    marginTop: "8px",
    display: "flex",
    alignItems: "center",
    backgroundColor: "white",
    boxShadow: theme.boxShadow,
    borderRadius: 0,
    cursor: "pointer"
  },
  rowSelected: {
    backgroundColor: "#FFF!important",
    boxShadow: "0 4px 8px 0 rgba(0,0,0,0.2)",
    borderLeft: "2px solid #118ACB"
  },
  checkbox: {
    paddingRight: 8
  },
  first: {
    width: "22%"
  },
  last: {
    width: "22%"
  },
  organisation: {
    width: "32%"
  },
  date: {
    width: "14%",
    paddingRight: 4
  },
  arrow: {
    cursor: "pointer"
  },
  arrowRT: {
    textAlign: "right",
    cursor: "pointer",
    paddingTop: "5px"
  }
}));

export default UsersRow;
