import React from "react";
import { createMuiTheme } from "@material-ui/core/styles";
import { ThemeProvider } from "@material-ui/styles";
import CssBaseline from "@material-ui/core/CssBaseline";

const primary = "#118ACB";
const secondary = "#41444B";
const dark = ["#41444B", "#4B4B4B"];
const grey = ["#CCCFD2", "#979797", "#5D5D5E"];
const light = ["rgba(228,228,228,1)", "rgba(245,245,246,1)"];

const theme = createMuiTheme({
  "@global": {
    "*::-webkit-scrollbar": {
      width: "0.4em"
    },
    "*::-webkit-scrollbar-track": {
      "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)"
    },
    "*::-webkit-scrollbar-thumb": {
      backgroundColor: "rgba(0,0,0,.1)",
      outline: "1px solid slategrey"
    }
  },

  palette: {
    primary: {
      light: "#30A8E8",
      main: "#118ACB",
      dark: "#0980BC"
    },
    secondary: {
      main: secondary
    },
    error: { main: "#DB4065" }
  },
  primary: primary,
  dark: ["#41444B", "#4B4B4B"],
  secondary: ["#CF8A29", "#282828", "#41545D"],
  grey: grey,
  light: light,
  systemColors: ["#DD3D63", "#0AA782", "#EED660"],
  spacing: 8,
  boxShadow: "0 1px 4px 0 rgba(0,0,0,0.14)",
  boxShadowIn: "inset 0 1px 4px 0 rgba(0,0,0,0.14)",

  typography: {
    useNextVariants: true,
    fontFamily: ["Montserrat", "OpenSans"].join(","),
    fontSize: 16,
    htmlFontSize: 16,
    colorSecondary: {
      color: "white"
    },
    h1: {
      fontSize: "25px",
      lineHeight: "32px",
      color: "#2C2D31"
    },
    h2: {
      fontSize: "21px",
      lineHeight: "29px",
      fontWeight: "bold",
      color: "#41444B"
    },
    h3: {
      fontSize: "14px",
      lineHeight: "20px",
      color: "#41444B",
      fontWeight: "bold"
    },
    h4: {
      fontSize: "12px",
      lineHeight: "16px",
      fontFamily: "Open Sans",
      fontWeight: "bold",
      color: "#4B4B4B"
    },
    h5: {
      fontSize: "14px",
      lineHeight: "20px",
      fontFamily: "Open Sans",
      fontWeight: 600,
      textTransform: "uppercase",
      color: "#42516E"
    },
    h6: {
      fontSize: "12px",
      lineHeight: "16px",
      fontWeight: "bold",
      fontFamily: "Open Sans"
    },
    subtitle1: {
      fontSize: "12px",
      lineHeight: "15px",
      fontFamily: "Open Sans",
      fontWeight: 600,
      color: "#475672"
    },
    caption: {
      fontSize: "14px",
      lineHeight: "20px",
      fontFamily: "Open Sans",
      fontWeight: 600,
      color: "#475672"
    },
    body1: {
      fontSize: "16px",
      lineHeight: "24px",
      fontFamily: "Open Sans",
      color: "#777777"
    },
    body2: {
      fontSize: "14px",
      lineHeight: "20px",
      fontFamily: "Open Sans",
      color: "#5D5D5E"
    }
  },

  warningBTN: {
    color: "#DD3D63",
    borderColor: "#DD3D63",
    backgroundColor: "#fff",
    minWidth: "140px",
    "&:hover": {
      backgroundColor: "#DD3D63",
      color: "#fff"
    }
  },
  continueBTN: {
    color: "#fff",
    borderColor: "#DD3D63",
    backgroundColor: "#DD3D63",
    minWidth: "140px",
    "&:hover": {
      backgroundColor: "rgba(221, 61, 99, 0.80)",
      borderColor: "rgba(221, 61, 99, 0.80)"
    }
  },
  successBTN: {
    color: "#fff",
    borderColor: "#0AA782",
    backgroundColor: "#0AA782",
    minWidth: "140px",
    "&:hover": {
      backgroundColor: "rgba(10, 167, 130, 0.80)",
      borderColor: "rgba(10, 167, 130, 0.80)"
    }
  },

  overrides: {
    MuiTypography: {
      colorSecondary: {
        color: "white"
      }
    },

    MuiGrid: {
      container: {
        margin: "0px -16px"
      },
      "spacing-xs-4": {
        margin: "0px -16px"
      }
    },

    MuiButton: {
      root: {
        padding: "11px 16px"
      },
      label: {
        fontFamily: "Open Sans",
        fontSize: "14px",
        lineHeight: "20px",
        fontWeight: "600",
        textTransform: "none",
        height: 20
      },
      containedPrimary: {
        minWidth: "140px",
        boxShadow: "none",
        backgroundColor: "#118ACB",
        border: "1px solid #118ACB",
        "&:hover": {
          backgroundColor: "#30A8E8",
          borderColor: "#30A8E8"
        }
      },
      containedSecondary: {
        boxShadow: "none",
        color: "rgba(137,147,164,1)",
        backgroundColor: "rgba(228,228,228,1)",
        "&:hover": {
          backgroundColor: "rgba(209,208,208,1)"
        }
      },
      outlined: {
        padding: "10px 16px"
      },
      outlinedPrimary: {
        minWidth: "140px",
        "&:hover": {
          color: "white",
          backgroundColor: "rgba(59,137,198,1)"
        }
      },
      outlinedSecondary: {
        border: `1px solid ${grey[1]}`,
        color: grey[1],
        "&:hover": {
          borderColor: "rgba(59,137,198,1)",
          backgroundColor: "rgba(59,137,198,0)"
        }
      },
      textPrimary: {
        padding: "10px 0px",
        "&:hover": {
          backgroundColor: "transparent",
          textDecoration: "underline"
        }
      }
    },
    MuiIconButton: {
      root: {
        color: grey[2],
        padding: "8px 16px",
        "&:hover": {
          backgroundColor: "transparent"
        }
      },
      colorSecondary: {
        color: grey[2],
        "&:hover": {
          backgroundColor: "transparent"
        }
      },
      edgeEnd: {
        marginRight: -16
      }
    },
    MuiSvgIcon: {
      colorSecondary: {
        color: grey[0]
      }
    },

    MuiCheckbox: {
      root: {
        color: "inherit"
      },
      colorSecondary: {
        color: grey[1]
      }
    },

    MuiSelect: {
      select: {
        "&:focus": {
          backgroundColor: "transparent"
        }
      },
      icon: {
        color: grey[1]
      }
    },

    MuiControll: {
      marginDense: {
        fontSize: "13px"
      }
    },
    MuiFormLabel: {
      root: {
        color: grey[1],
        fontFamily: "Open Sans"
      }
    },
    MuiFormHelperText: {
      root: {
        fontSize: "0.75rem"
      }
    },

    MuiInputBase: {
      root: {
        fontFamily: "Open Sans",
        fontSize: "14px",
        lineHeight: "28px",
        color: grey[1]
      },
      input: {
        height: "auto",
        padding: "2px 0px 10px 0px"
      }
    },
    MuiInput: {
      underline: {
        "&:before": {
          borderBottom: `1px solid ${grey[1]}`
        },
        "&:hover:not(.Mui-disabled):before": {
          borderBottom: `1px solid ${grey[2]}`
        }
      }
    },
    MuiOutlinedInput: {
      root: {
        borderRadius: "0px",
        color: grey[1],
        fontFamily: "Open Sans",
        "&$error $notchedOutline": {
          borderColor: "#DD3D63!important"
        }
      },
      input: {
        borderRadius: "0px",
        padding: "8px 48px 8px 16px"
      },
      notchedOutline: {
        // borderColor: grey[0],
        borderRadius: "0px"
      }

      // inputMarginDense: {
      //   padding: "5px 48px 5px 16px"
      // }
    },
    MuiInputLabel: {
      root: {
        fontSize: "14px"
      },
      marginDense: {
        fontSize: "13px"
      },
      outlined: {
        fontSize: "14px",
        transform: "translate(18px, 14px) scale(1)",
        color: grey[1],
        "&$shrink": {
          transform: "translate(14px, -6px) scale(0.75)"
        }
      }
    },

    MuiTableCell: {
      root: {
        borderBottom: "0px",
        padding: "4px 16px 4px 16px",
        fontFamily: "Montserrat"
      },
      body: {
        color: grey[2]
      },
      paddingCheckbox: {
        padding: "0px 16px"
      }
    },
    MuiTableSortLabel: {
      root: {
        color: grey[2]
      },
      active: {
        color: `${grey[2]}!important`,
        fontWeight: "bold"
      },
      icon: {
        color: `${grey[2]}!important`
      }
    },
    MuiTablePagination: {
      select: {
        fontSize: "14px",
        lineHeight: "20px",
        fontFamily: "Open Sans",
        fontWeight: 600,
        textAlignLast: "left",
        paddingLeft: 8,
        paddingRight: 16,
        paddingBottom: 0
      },
      selectRoot: {
        marginRight: 24
      }
    },
    MuiDialog: {
      paper: {
        borderRadius: "0px"
      }
    },

    MuiTabs: {
      root: {
        backgroundColor: "rgba(65,68,75,0.05)"
        // borderBottom: "4px solid rgba(9,128,188,0.5)"
      },

      indicator: {
        backgroundColor: "transparent"
      }
    },
    MuiTab: {
      root: {
        selected: {
          display: "none"
        }
      }
    },
    MuiTabsIndicator: {
      display: "none"
    },
    MuiCardHeader: {
      action: {
        alignSelf: "center",
        marginTop: "0px"
      }
    }
  }
});

function withRoot(Component) {
  function WithRoot(props) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Component {...props} />
      </ThemeProvider>
    );
  }

  return WithRoot;
}

export default withRoot;
