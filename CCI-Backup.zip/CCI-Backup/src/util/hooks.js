import { useContext, useState, useEffect, useRef, useCallback } from "react";
import axios from "axios";

export const useToggle = initial => {
  const [open, setOpen] = useState(initial);

  return [open, useCallback(() => setOpen(status => !status))];
};

export const useAPI = endpoint => {
  const [data, setData] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const response = await axios.get(endpoint);
    console.log(response.data);
    setData(response.data);
  };

  return data;
};

const useInput = initialValue => {
  console.log("useInput");
  const [fieldValues, setFieldValues] = useState(initialValue);

  return {
    fieldValues,
    setFieldValues,
    reset: () => setFieldValues(""),
    bind: {
      fieldValues,
      onChange: e => {
        setFieldValues({ ...fieldValues, [e.target.name]: e.target.value });
      }
    }
  };
};

export function useDidChange(value) {
  let ref = useRef();
  let hasChanged = ref.current !== value;
  useEffect(() => {
    ref.current = value;
  });
  return hasChanged;
}
