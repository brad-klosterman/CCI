import React, { useState, useCallback, useEffect } from "react";
import produce from "immer";
import { makeStyles } from "@material-ui/core/styles";
import { withStyles } from "@material-ui/core/styles";
import {
  Grid,
  Button,
  Typography,
  IconButton,
  Tooltip
} from "@material-ui/core";
import { CSwitch } from "Components/Switch";
import { MultiSelect } from "Components/Selects/MultiSelect";
import { AlertDialog } from "Components/Alert";
import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import Selector from "./Selector";
import Clear from "@material-ui/icons/DeleteForever";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useInput, validations } from "util/forms";

/// PERHAPS MAP THE RESULTS AFTER ALL IDENTITIES ARE ADDED TO THE STATE

const AddRoles = ({
  organisation,
  organisations,
  identity,
  userType,
  sending,
  onSend
}) => {
  const classes = useStyles();

  useEffect(() => {
    sending && validate();
  });

  //////////////////////////////////////////
  /* STATE */
  const [expanded, setExpanded] = useState(0);
  const [expanded2, setExpanded2] = useState(0);
  const [addOrg, setAddOrg] = useState(false);
  const [addInst, setAddInst] = useState(false);
  const [identities, setIdentities] = useState([]);
  const [alert, setAlert] = useState({ open: false, msg: "" });

  useEffect(
    () => {
      organisation && addOrganisation(organisation);
    },
    [organisation]
  );

  useEffect(
    () => {
      identity && identity.map(organisation => addOrganisation(organisation));
    },
    [identity]
  );

  //////////////////////////////////////////
  /* CALLBACKS */

  const changePanel = panel => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };
  const changePanel2 = panel => (event, newExpanded) => {
    setExpanded2(newExpanded ? panel : false);
  };

  const addBtn = () => {
    setAddOrg(true);
  };
  const addInstBtn = () => {
    setAddInst(true);
  };

  const closeAlert = () => {
    setAlert({ open: false, msg: "" });
  };

  const addOrganisation = useCallback(
    organisation => {
      // setAddOrg(false);
      // setExpanded(identities.length);
      async function fetchOrg() {
        const response = await fetch(
          "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/organisation/" +
            organisation.organisationGuid
        );
        const orgJson = await response.json();
        !orgJson.result && alert("No Instances");

        const nextState = produce(identities, draftState => {
          draftState.push({
            organisationName: organisation.organisationName,
            organisationGuid: organisation.organisationGuid,
            data: orgJson.result,
            organisationRoles: orgJson.roles,
            instances: organisation.instances ? organisation.instances : []
          });
        });
        setIdentities(nextState);
      }
      fetchOrg();
    },
    [identities]
  );

  console.log("identities", identities);

  const addInstance = useCallback(
    ({ ev, orgIndex }) => {
      setAddInst(false);
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances.push({
          instanceName: ev.instance.instanceName,
          instanceGuid: ev.instance.instanceGuid,
          areas: ev.areas,
          defaultArea: "",
          roles: [{ areaId: "", roles: [] }]
        });
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const addArea = useCallback(
    ({ ev, orgIndex, instIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].roles.push({
          areaId: "",
          roles: []
        });
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onArea = useCallback(
    ({ area, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].roles[areaIndex] = {
          ...draftState[orgIndex].instances[instIndex].roles[areaIndex],
          areaId: area.rowGuid,
          areaName: area.name
        };
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onRole = useCallback(
    ({ role, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].roles[areaIndex] = role;
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onSwitch = useCallback(
    ({ orgIndex, instIndex, area }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].defaultArea = area;
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onDeleteOrganisation = useCallback(
    ({ orgIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex];
      });

      setIdentities(nextState);
    },
    [identities]
  );

  const onDeleteInstance = useCallback(
    ({ orgIndex, instIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex].instances[instIndex];
      });

      setIdentities(nextState);
    },
    [identities]
  );

  const onDelete = useCallback(
    ({ execute, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex].instances[instIndex].roles[areaIndex];
      });

      execute ? setIdentities(nextState) : setAlert(true);
    },
    [identities]
  );

  const validate = () => {
    let allRoles = [];
    let validate = true;

    identities.map(organisation =>
      organisation.instances.length === 0
        ? (setAlert({
            open: true,
            msg:
              "Please Select an Instance for " + organisation.organisationName
          }),
          (validate = false))
        : organisation.instances.map(instance =>
            instance.areas.length === 0
              ? (setAlert({
                  open: true,
                  msg:
                    "Please Select an Area for " +
                    organisation.organisationName +
                    " > " +
                    instance.instanceName
                }),
                (validate = false))
              : (instance.areas.map(area =>
                  area.areaGuid === ""
                    ? (setAlert({
                        open: true,
                        msg:
                          "Please Select an Area for " +
                          organisation.organisationName +
                          " > " +
                          instance.instanceName
                      }),
                      (validate = false))
                    : area.roles.length === 0
                    ? (setAlert({
                        open: true,
                        msg:
                          "Select a Role for " +
                          organisation.organisationName +
                          " > " +
                          instance.instanceName +
                          " > " +
                          area.areaName
                      }),
                      (validate = false))
                    : true
                ),
                allRoles.push({
                  instanceGuid: instance.instanceGuid,
                  organisationGuid: organisation.organisationGuid,
                  defaultAreaGuid: instance.defaultArea,
                  roles: instance.roles
                }))
          )
    );

    if (!validate) {
      allRoles = [];
    }

    validate && allRoles.length !== 0 && onSend
      ? onSend(allRoles)
      : onSend(false);
  };

  let addOrgBtn;
  if (addOrg) {
    addOrgBtn = (
      <Selector
        id="Add Organisation"
        items={organisations}
        onSelect={ev => addOrganisation(ev)}
        width={5}
      />
    );
  } else {
    addOrgBtn = (
      <Grid item xs={12}>
        <Button color="primary" variant="outlined" onClick={addBtn}>
          Add An Organisation
        </Button>
      </Grid>
    );
  }

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        {identities.map((organisation, orgIndex) => (
          <ExpansionPanel
            panel={orgIndex}
            changePanel={changePanel}
            expanded={expanded}
            title={organisation.organisationName}
            key={orgIndex}
            onDelete={() => onDeleteOrganisation({ orgIndex })}
          >
            <Grid
              item
              xs={12}
              className={!organisation.instances.length ? classes.hidden : ""}
            >
              {organisation.instances.map((instance, instIndex) => (
                <ExpansionPanel
                  panel={instIndex}
                  changePanel={changePanel2}
                  expanded={expanded2}
                  title={instance.instanceName}
                  key={instIndex}
                  onDelete={() => onDeleteInstance({ orgIndex, instIndex })}
                >
                  {instance.roles.length !== 0 &&
                    instance.roles.map((roles, areaIndex) => (
                      <RoleSelector
                        key={areaIndex}
                        areas={instance.areas}
                        roles={organisation.roles}
                        selected={instance.roles}
                        onArea={area =>
                          onArea({ area, orgIndex, instIndex, areaIndex })
                        }
                        onRole={role =>
                          onRole({ role, orgIndex, instIndex, areaIndex })
                        }
                        onSwitch={area =>
                          onSwitch({ orgIndex, instIndex, area })
                        }
                        defArea={instance.defaultArea}
                        onDelete={execute =>
                          onDelete({
                            execute,
                            orgIndex,
                            instIndex,
                            areaIndex
                          })
                        }
                      />
                    ))}
                  <Grid item xs={12}>
                    <Button
                      color="primary"
                      variant="outlined"
                      onClick={ev => addArea({ ev, orgIndex, instIndex })}
                    >
                      Add Area
                    </Button>
                  </Grid>
                </ExpansionPanel>
              ))}
            </Grid>

            {addInst ? (
              <Selector
                id="Add Instance"
                items={organisation.data}
                onSelect={ev => addInstance({ ev, orgIndex })}
                width={5}
                selected={identities[orgIndex].instances}
              />
            ) : (
              <Grid item xs={12}>
                <Button color="primary" variant="outlined" onClick={addInstBtn}>
                  Add An Instance
                </Button>
              </Grid>
            )}
          </ExpansionPanel>
        ))}
      </Grid>

      {userType.cci && addOrgBtn}

      <AlertDialog open={alert.open} msg={alert.msg} onClose={closeAlert} />
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {},
  instance: {
    display: "flex",
    alignItems: "center",
    backgroundColor: theme.grey,
    borderRadius: 4,
    padding: `${theme.spacing(1)}px ${theme.spacing(1)}px`
  },
  instanceTitle: {
    flexGrow: 1
  },
  addArea: {
    paddingRight: 4,
    width: 16
  },
  hidden: {
    display: "none"
  }
}));

const RoleSelector = ({
  areas,
  roles,
  selected,
  index,
  onArea,
  onRole,
  defArea,
  onSwitch,
  onDelete
}) => {
  const classes = roleStyles();
  const [area, setArea] = useState(undefined);

  const onSelectArea = ev => {
    onArea && onArea(ev);
    setArea(ev.rowGuid);
  };

  const onSelectRoles = ev => {
    onRole && onRole({ areaId: area, roles: ev });
  };

  const deleteArea = () => {
    onDelete(defArea !== area ? true : false);
  };

  useEffect(() => {
    area !== undefined && defArea === "" && onSwitch(area);
  });

  return (
    <>
      <Selector
        id="Area"
        items={areas}
        width={4}
        onSelect={onSelectArea}
        selected={selected}
      >
        <Tooltip title="Make Default Area">
          <div className={classes.switchbox}>
            <CSwitch
              disabled={area ? false : true}
              checked={
                defArea === area || (area !== undefined && defArea === "")
              }
              onChange={() => onSwitch(area)}
              value="checkedC"
            />
          </div>
        </Tooltip>
      </Selector>

      <MultiSelect id="Roles" items={roles} width={8} onSelect={onSelectRoles}>
        <Tooltip title="Delete Area">
          <IconButton
            aria-label="Close"
            className={classes.deleteBtn}
            onClick={deleteArea}
          >
            <Clear />
          </IconButton>
        </Tooltip>
      </MultiSelect>
    </>
  );
};
const roleStyles = makeStyles(theme => ({
  deleteBtn: {
    paddingRight: 0,
    color: theme.grey[2],
    marginBottom: theme.spacing(-2)
  },
  switchbox: {
    display: "flex",
    alignItems: "center",
    paddingLeft: 32,
    marginBottom: theme.spacing(-2)
  }
}));

const ExpansionPanel = withStyles(theme => ({
  root: {
    border: "2px solid rgba(228,228,228,1)",
    boxShadow: "none",
    "&:not(:last-child)": {
      borderBottom: 0
    },
    "&:before": {
      display: "none"
    },
    "&$expanded": {
      margin: "auto"
    }
  },
  expanded: { margin: "0px!important" },
  summary: {
    alignItems: "center",
    color: theme.grey[2],
    margin: `${theme.spacing(1)}px 0px`,
    "&$expanded": {
      display: "none"
    }
  },
  title: {
    flexGrow: 1
  },
  delete: {
    paddingRight: 0
  },
  details: {
    padding: `${theme.spacing(2)}px ${theme.spacing(4)}px`
  }
}))(props => {
  const {
    classes,
    panel,
    expanded,
    title,
    onDelete,
    changePanel,
    children
  } = props;
  return (
    <MuiExpansionPanel
      expanded={expanded === panel}
      onChange={changePanel(panel)}
      classes={{ root: classes.root, expanded: classes.expanded }}
    >
      <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
        <Typography className={classes.title} variant="h3">
          {title}
        </Typography>
        <IconButton className={classes.delete} onClick={onDelete}>
          <Clear fontSize="small" />
        </IconButton>
      </ExpansionPanelSummary>

      <Grid container spacing={4} className={classes.details}>
        {children}
      </Grid>
    </MuiExpansionPanel>
  );
});

const ExpansionPanelSummary = withStyles(theme => ({
  root: {
    backgroundColor: "rgba(228,228,228,1)",
    borderBottom: "0px",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56
    }
  },
  content: {
    alignItems: "center",
    color: theme.grey[1],
    margin: "8px 0px",
    "&$expanded": {
      margin: "8px 0"
    }
  },
  expanded: {}
}))(MuiExpansionPanelSummary);

export default AddRoles;
