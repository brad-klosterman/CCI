export const formatDate = value => {
  const date = new Date();
  return date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear();
};
