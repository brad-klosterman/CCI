import React, { useState, useMemo, useEffect, useCallback } from "react";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import { useDash } from "state";
import { createDraft, finishDraft } from "immer";
import { useDialog } from "state";
import { useTR } from "./State";
import { AREAS_API, API_DELETE_AREA, API_CLONE_AREA } from "Api";
import { findNode } from "./DeepFind";
import { formatDate } from "util/index.js";

import { TreeBar, Node, GhostNode } from ".";

function Tree() {
  const cx = useStyles();
  const {
    DACTIONS: { openNotification },
    DIALOG
  } = useDash();
  const dialog = useDialog();
  const { TRSTATE, TRD } = useTR();
  const { SELECTED } = TRSTATE;
  /// STATE
  const [selectedCB, setSelectedCB] = useState(null);
  const [state, setState] = useState(null);
  const [apiResponse, setApiResponse] = useState({
    error: false,
    response: null,
    state: 0
  });
  const [dragNode, setDragNode] = useState(null);
  const [dragPoints, setDragPoints] = useState(null);
  const [dropNode, setDropNode] = useState(null);
  const [addNode, setAddNode] = useState(null);
  const gridSize = TRSTATE.SELECTED.NODE ? 6 : 12;

  // console.log("ORG", TRSTATE.ORGANISATION);
  // console.log("TREE", TRSTATE);
  console.log("SELECTED", TRSTATE.SELECTED);
  // console.log("ORG", TRSTATE.ORGANISATION);

  const findInstance = ({ nodeID, instances }) =>
    instances.find(x => x.rootRowGuid === nodeID);

  const onSelect = useCallback(
    payload => {
      if (payload) {
        const { nodeID, rootID, instanceID, type } = payload;

        setSelectedCB(prevSelectedCB => {
          prevSelectedCB && prevSelectedCB.onDeselect();
          return payload;
        });

        if (type === 1) {
          TRD({
            type: "SELECT_NODE",
            payload: {
              type,
              node: TRSTATE.ORGANISATION
            }
          });
        } else if (type === 2) {
          TRD({
            type: "SELECT_NODE",
            payload: {
              type,
              node: findInstance({
                nodeID,
                instances: TRSTATE.TREE.children
              })
            }
          });
        } else if (type === 3) {
          const selectNode = async id => {
            let foundNode = await findNode({
              nodeID: id,
              nodes: [TRSTATE.TREE]
            });
            return {
              type,
              node: { ...foundNode, rootID, instanceID }
            };
          };
          selectNode(nodeID).then(data => {
            TRD({ type: "SELECT_NODE", payload: data });
          });
        }
      } else {
        setSelectedCB(payload);
        TRD({ type: "SELECT_NODE", payload: { TYPE: 0, NODE: undefined } });
      }
    },
    [TRSTATE.ORGANISATION, TRSTATE.TREE]
  );

  const onExpand = useCallback(({ areaID, idx, type }) => {
    ///Expand
  }, []);

  const onAddNode = useCallback((type, id) => {
    setAddNode(type);
  }, []);

  /// UPDATE TREE IN LOCAL STATE
  const updateLocal = async ({ source, destination }) => {
    const draft = createDraft(TRSTATE.TREE);
    let destinationNode;
    let parentNode = await findNode({
      nodeID: source.parentID,
      nodes: [draft]
    });
    if (destination) {
      destinationNode = await findNode({
        nodeID: destination.nodeID,
        nodes: [draft]
      });
      const sourceNode = await parentNode.children.filter(
        i => i["rowGuid"] === source.nodeID
      );

      sourceNode[0].area.parentGuid = destinationNode.rowGuid;
      destinationNode.children.unshift(...sourceNode);
      draft.source = sourceNode;
    }

    const filtered = parentNode.children.filter(
      i => i["rowGuid"] !== source.nodeID
    );
    parentNode.children = filtered;

    draft.des = destinationNode;
    draft.par = parentNode;

    return finishDraft(draft);
  };

  /// DELETE IN DATABASE
  const DELETE_AREA = async (type, location, nodeID, parentID) => {
    DIALOG.continueConfirm({
      variant: "continue",
      title: {
        1: "ARE YOU SURE YOU WANT TO DELETE THIS AREA?",
        2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
        3: "SUCCESS DELETEING AREA",
        4: "ERROR DELETING AREA"
      },
      actions: { ok: "SAVE", cancel: "NO", exit: "CONTINUE" },
      onExit: () => console.log("onexit")
    }).then(res => {
      if (res === "ACCEPT") {
        (async () => {
          let value, message;
          const { error } = await API_DELETE_AREA(location);
          if (!error) {
            value = "SUCCESS";
            const updatedNode = await updateLocal({
              source: { nodeID, parentID },
              destination: null
            });
            TRD({ type: "UPDATE_TREE", payload: updatedNode });
          }
          if (error) {
            value = "ERROR";
            message = error;
          }
          DIALOG.confirmationResponse({
            value,
            message
          });
        })();
      } else if (res === "REJECT") {
        console.log("rejected confirmation");
      }
    });
  };

  const createArea = useCallback(
    payload => {
      let url;
      let data;
      async function updateTree(type, data, rowGuid) {
        if (type === 1) {
          const newNode = {
            areaID: rowGuid.rootAreaId,
            children: [],
            id: rowGuid.instanceId,
            installationTypeGuid: data.InstallationTypeId,
            instanceGuid: rowGuid.instanceId,
            instanceSettings: {
              country: data.CountryId,
              emailDomainWhiteList: [],
              enableUserCreation: false,
              expirationDate: null,
              note: null,
              quotaLE: 0,
              quotaSE: 0,
              userLimit: 0,
              visibility: false
            },
            lastUpdated: null,
            name: data.InstanceName,
            recommendations: null,
            recommendedTraccs: [],
            rootRowGuid: rowGuid.rootAreaId,
            status: 0,
            type: 2
          };

          const newTree = async mappings => {
            const draft = createDraft(mappings);
            draft.children.push(newNode);

            return finishDraft(draft);
          };

          newTree(TRSTATE.TREE).then(payload => {
            TRD({ type: "UPDATE_TREE", payload: payload });

            TRD({
              type: "SELECT_NODE",
              payload: {
                type: 2,
                node: findInstance({
                  nodeID: rowGuid.rootAreaId,
                  instances: payload.children
                })
              }
            });
          });
        }
        if (type === 2) {
          const newNode = {
            id: rowGuid,
            rowGuid: rowGuid,
            area: {
              areaCategories: [],
              businessCategories: [],
              countryId: null,
              dateCreated: formatDate(),
              dateUpdated: null,
              deleted: false,
              id: rowGuid,
              isApplicationSpecific: false,
              licensedEntity: false,
              name: data.areaName,
              parentGuid: data.parentGuid,
              rootID: null,
              rowGuid: rowGuid,
              structuralEntity: false
            },
            children: []
          };

          const newTree = async mappings => {
            const draft = createDraft(mappings);
            let foundNode = await findNode({
              nodeID: data.parentGuid,
              nodes: [draft]
            });
            foundNode.children.push(newNode);

            return finishDraft(draft);
          };

          newTree(TRSTATE.TREE).then(payload => {
            TRD({ type: "UPDATE_TREE", payload: payload });
          });
        }
      }

      if (addNode === 1) {
        url = "instance";
        data = { OrganisationId: TRSTATE.TREE.id, ...payload };
      } else {
        url = "root/child";
        let nodeGuid;
        if (SELECTED.TYPE === 2) {
          nodeGuid = {
            rootAreaGuid: SELECTED.NODE.rootRowGuid,
            parentGuid: SELECTED.NODE.rootRowGuid
          };
        }
        if (SELECTED.TYPE === 3) {
          nodeGuid = {
            rootAreaGuid: SELECTED.NODE.rootID,
            parentGuid: SELECTED.NODE.rowGuid
          };
        }
        data = {
          orgRowGuid: TRSTATE.TREE.id,
          ...nodeGuid,
          ...payload
        };
      }

      (async (url, data) => {
        console.log("Debugg", TRSTATE.TREE);
        console.log("data", data);
        axios({
          method: "post",
          url: AREAS_API + url,
          data: data
        })
          .then(function(response) {
            setApiResponse({ error: false, response: "SUCCESS", state: 1 });
            updateTree(addNode, data, response.data.result);
          })
          .catch(function(error) {
            setApiResponse({
              error: true,
              response: error.response.data.error,
              state: 2
            });
          });
      })(url, data);
    },
    [SELECTED, TRSTATE.TREE, addNode]
  );

  const closeAddArea = useCallback(() => {
    setAddNode(null);
    setApiResponse({
      error: false,
      response: null,
      state: 0
    });
  }, []);

  const onCloneArea = () => {
    console.log("CLONE AREA", SELECTED);
  };

  /// DND EVENTS
  useEffect(() => {
    function clearDND() {
      setDragNode(null);
      setDragPoints(null);
      setDropNode(null);
      setState(null);
    }

    if (state === "dropping") {
      const moveNode = async () => {
        try {
          const updatedTree = await updateLocal({
            source: { nodeID: dragNode.nodeID, parentID: dragNode.parentID },
            destination: dropNode
          });
          TRD({ type: "UPDATE_TREE", payload: updatedTree });
        } catch (error) {
          console.log(error);
          // setApiResponse({
          //   error: true,
          //   response: error.response.data.error,
          //   state: 2
          // });
        }
      };

      if (dropNode) {
        dialog
          .confirm({ title: "Move Node", message: "Are you sure?" })
          .then(() => moveNode())
          .catch(() => console.log("clicked cancel"));
      }
      clearDND();
    }
  }, [dialog, dragNode, dropNode, state, updateLocal]);

  const onMouseMove = useCallback(event => {
    setDragPoints(prevDragPoints => ({
      ...prevDragPoints,
      xcursor: event.clientX,
      ycursor: event.clientY
    }));
  }, []);

  const onDragOver = useCallback(props => {
    setDropNode({ ...props });
  }, []);

  const onDragExit = useCallback(() => {
    setDropNode(null);
  }, []);

  const onDragEnd = useCallback(() => {
    setState("dropping");
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onDragEnd);
  }, [onMouseMove]);

  const onDrag = useCallback(
    ({ nodeID, parentID, name, xstart, ystart, xcursor, ycursor, depth }) => {
      setState("dragging");
      setDragNode({ nodeID, parentID, name });
      setDragPoints({
        xstart,
        ystart,
        xcursor,
        ycursor
      });
      setDropNode({ depth });
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onDragEnd);
    },
    [onDragEnd, onMouseMove]
  );

  const ACTIONS = {
    onSelect,
    onExpand,
    onDrag,
    dragNode,
    onDragOver,
    onDragExit,
    onDragEnd
  };

  const TreeRender = ({ DATA, ACTIONS, rootArea, depth, idx }) => {
    if (!DATA) {
      return null;
    }
    let key,
      name,
      nodeID,
      areaID,
      rootID,
      instanceID,
      parentID,
      type,
      color = "red";

    function returnColor(color) {
      if (color === "darkblue" || color === "lightblue") {
        return "lightblue";
      }
      if (DATA.area.licensedEntity) {
        return "darkblue";
      }
      if (DATA.area.structuralEntity) {
        return "green";
      }
      return "red";
    }

    if (DATA.type === 1 || DATA.type === 2) {
      key = DATA.id;
      name = DATA.name;
      nodeID = DATA.areaID;
      areaID = DATA.areaID;
      type = DATA.type;
    } else {
      key = DATA.rowGuid;
      name = DATA.area.name;
      nodeID = DATA.rowGuid;
      areaID = DATA.rowGuid;
      parentID = DATA.area.parentGuid;
      type = 3;
      color = returnColor(DATA.color);
      instanceID = DATA.instanceID;
    }

    if (DATA.type === 2) {
      rootID = areaID;
      color = "green";
      instanceID = DATA.instanceGuid;
    } else {
      rootID = rootArea;
    }

    const props = {
      key,
      name,
      nodeID,
      areaID,
      instanceID,
      parentID,
      type,
      depth,
      idx,
      state,
      searchNode: TRSTATE.SEARCH_TREE,
      color
    };

    if (DATA.type === 1) {
      const actions = {
        onSelect,
        onAddNode,
        DELETE_AREA,
        onCloneArea
      };
      return (
        <TreeBar name={DATA.name} nodeID={DATA.id} {...actions}>
          {DATA.children.map((node, idx) =>
            TreeRender({ DATA: node, ACTIONS, depth: depth + 1, idx })
          )}
        </TreeBar>
      );
    }

    if (DATA.children) {
      return (
        <Node {...props} rootID={rootID} {...ACTIONS}>
          {DATA.children.map((node, idx) =>
            TreeRender({
              DATA: { ...node, instanceID, color },
              ACTIONS,
              rootArea: rootID,
              depth: depth + 1,
              idx
            })
          )}
        </Node>
      );
    }
    return <Node {...props} rootID={rootID} {...ACTIONS} />;
  };

  const renderNodes = useMemo(() => {
    return TreeRender({ DATA: TRSTATE.TREE, ACTIONS, depth: 0 });
  }, [TRSTATE, state, dragNode]);

  /// RENDER

  if (!TRSTATE.TREE) {
    return null;
  }

  return (
    <>
      <Grid item xs={gridSize}>
        <ul role="tree" className={cx.root}>
          {renderNodes}
        </ul>
        <GhostNode
          selected={SELECTED}
          depth={dropNode ? dropNode.depth : 1}
          {...dragNode}
          {...dragPoints}
          {...dropNode}
        />
      </Grid>
    </>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    padding: 0,
    margin: 0,
    listStyle: "none",
    "& li:first-child": {
      marginTop: 0
    }
  }
}));

export default Tree;
