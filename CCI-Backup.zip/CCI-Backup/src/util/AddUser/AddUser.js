import React, { useState, useContext, useCallback } from "react";
import { withStyles, makeStyles, useTheme } from "@material-ui/core/styles";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import axios from "axios";
import SwipeableViews from "react-swipeable-views";
import {
  Button,
  Typography,
  IconButton,
  Dialog,
  DialogActions,
  DialogContent,
  Divider,
  Slide
} from "@material-ui/core";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import Clear from "@material-ui/icons/Clear";
import AddBasic from "./AddBasic";
import AddRoles from "./AddRoles";
import Confirmation from "./Confirmation";

import { AppContext } from "state/appState";

function AddUser({ popupOpen, togglePopup }) {
  const classes = useStyles();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  ///STATE
  const { AppState } = useContext(AppContext);
  const { userOrganisations } = AppState;
  const [checkedA, setCheckedA] = useState(false);
  const [indexValue, setIndexValue] = useState(0);
  const [sending, setSending] = useState(false);
  const [sendPayload, setSendPayload] = useState(false);
  const [payload, setPayload] = useState(undefined);
  const [userType, setUserType] = useState({
    admin: true,
    cci: true,
    org: undefined
  });

  const onSend = useCallback(payload => {
    const valid = () => {
      setPayload({ user: payload });
      setUserType({
        ...userType,
        cci: payload.userType === "CCI" ? true : false,
        org: payload.organisation
      });
      setIndexValue(1);
      setSending(false);
    };

    payload ? valid() : setSending(false);
  }, []);

  const onSendApi = useCallback(
    roles => {
      roles && createUser({ ...payload, instances: roles });
      setSendPayload(false);
    },
    [payload]
  );

  const data = {
    userOrganisations: userOrganisations,
    onSend: onSend,
    sending: sending,
    onCheckA: onCheckA,
    user: null
  };
  const data2 = {
    userOrganisations: userOrganisations,
    organisation: userType.org,
    onSend: onSendApi,
    sending: sendPayload,
    userType: userType,
    user: null
  };

  //////////////////////////////////////////
  /* CALLBACKS */
  function changeIndex() {
    indexValue === 0 && setSending(true);
    indexValue === 1 && setSendPayload(true);
    indexValue === 2 && confirm();
  }

  function onCheckA() {
    setCheckedA(prevCheckedA => !prevCheckedA);
  }

  const createUser = useCallback(apiPayload => {
    console.log("Create User", apiPayload);
    axios
      .post(
        "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/user",
        apiPayload
      )
      .then(function(response) {
        console.log(response);
        setPayload(undefined);
        setIndexValue(2);
      })
      .catch(function(error) {
        console.log(error);
      });
  }, []);

  const confirm = () => {
    togglePopup();
    setIndexValue(0);
  };

  return (
    <Dialog
      fullScreen={fullScreen}
      fullWidth
      open={popupOpen}
      onClose={togglePopup}
      TransitionComponent={Transition}
      maxWidth="md"
      aria-labelledby="add user"
      BackdropProps={{ classes: { root: classes.backdrop } }}
    >
      <DialogTitle
        onClose={togglePopup}
        title="Add New User"
        subTitle={
          indexValue === 0
            ? "Basic Information"
            : indexValue === 1
            ? "Allocate Roles"
            : "Confirm"
        }
      />
      <DialogContent className={classes.content}>
        <SwipeableViews
          index={indexValue}
          slideStyle={{
            overflow: "hidden",
            padding: `${theme.spacing(2)}px 0px`
          }}
        >
          <AddBasic {...data} />
          <AddRoles {...data2} />
          <Confirmation confirm={confirm} />
        </SwipeableViews>
      </DialogContent>
      <DialogActions classes={{ root: classes.actions }}>
        <Divider classes={{ root: classes.divider }} />
        <Button
          onClick={changeIndex}
          variant="contained"
          color="primary"
          classes={{ root: classes.actionBtn }}
        >
          {indexValue === 0
            ? checkedA
              ? "Allocate Area Roles to User"
              : "Add User and Send Activation Email"
            : indexValue === 1
            ? "Create User"
            : "Back to Dashboard"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  backdrop: {
    opacity: "0.95!important",
    backgroundColor: theme.secondary[1]
  },
  content: {
    padding: `0px ${theme.spacing(6)}px ${theme.spacing(2)}px`,
    overflowX: "hidden"
  },
  actions: {
    justifyContent: "center",
    flexDirection: "column",
    padding: `0px ${theme.spacing(4)}px ${theme.spacing(4)}px`
  },
  actionBtn: {
    marginTop: `${theme.spacing(4)}px`
  },
  divider: {
    width: "100%",
    height: 4,
    backgroundColor: theme.grey[2],
    marginBottom: 0
  }
}));

const DialogTitle = withStyles(theme => ({
  title: {
    background: theme.primary,
    color: "white",
    margin: 0,
    padding: `${theme.spacing(6)}px 0px 4px`
  },
  h2: {
    marginBottom: `${theme.spacing(2)}px`
  },
  subTitle: {
    marginLeft: `${theme.spacing(6)}px`
  },
  divider: {
    height: 4,
    backgroundColor: "rgba(255,255,255, .67)",
    marginTop: `${theme.spacing(1)}px`
  },
  closeButton: {
    color: "white",
    position: "absolute",
    right: theme.spacing(2),
    top: theme.spacing(2),
    padding: 0
  }
}))(props => {
  const { title, subTitle, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.title}>
      <Typography
        variant="h2"
        color="secondary"
        align="center"
        className={classes.h2}
      >
        {title}
      </Typography>
      <Typography variant="h3" color="secondary" className={classes.subTitle}>
        {subTitle}
      </Typography>
      <IconButton
        aria-label="Close"
        className={classes.closeButton}
        onClick={onClose}
      >
        <Clear />
      </IconButton>
      <Divider classes={{ root: classes.divider }} />
    </MuiDialogTitle>
  );
});

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default AddUser;
