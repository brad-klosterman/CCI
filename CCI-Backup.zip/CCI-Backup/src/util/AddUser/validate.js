const validate = () => {
  let allRoles = [];
  let validate = true;

  identities.map(organisation =>
    organisation.instances.length === 0
      ? (setAlert({
          open: true,
          msg: "Please Select an Instance for " + organisation.organisationName
        }),
        (validate = false))
      : organisation.instances.map(instance =>
          instance.areas.length === 0
            ? (setAlert({
                open: true,
                msg:
                  "Please Select an Area for " +
                  organisation.organisationName +
                  " > " +
                  instance.instanceName
              }),
              (validate = false))
            : (instance.areas.map(area =>
                area.areaGuid === ""
                  ? (setAlert({
                      open: true,
                      msg:
                        "Please Select an Area for " +
                        organisation.organisationName +
                        " > " +
                        instance.instanceName
                    }),
                    (validate = false))
                  : area.roles.length === 0
                  ? (setAlert({
                      open: true,
                      msg:
                        "Select a Role for " +
                        organisation.organisationName +
                        " > " +
                        instance.instanceName +
                        " > " +
                        area.areaName
                    }),
                    (validate = false))
                  : true
              ),
              allRoles.push({
                instanceGuid: instance.instanceGuid,
                organisationGuid: organisation.organisationGuid,
                defaultAreaGuid: instance.defaultArea,
                roles: instance.roles
              }))
        )
  );

  if (!validate) {
    allRoles = [];
  }

  validate && allRoles.length !== 0 && onSend
    ? onSend(allRoles)
    : onSend(false);
};
