import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Typography, Button } from "@material-ui/core";
import Check from "@material-ui/icons/CheckCircle";

const Confirmation = ({ confirm }) => {
  const classes = useStyles();

  return (
    <Grid container spacing={4}>
      <Grid item xs={12} className={classes.success}>
        <Check className={classes.icon} />
        <Typography variant="h1" className={classes.text} align="center">
          SUCCESS
        </Typography>
      </Grid>
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {},
  selected: {
    color: "white",
    backgroundColor: theme.dark[1]
  },
  divider: {
    height: 4,
    backgroundColor: theme.dark[1]
  },
  icon: {
    fontSize: "54px",
    color: theme.systemColors[1]
  },
  success: {
    textAlign: "center"
  },
  text: {
    color: theme.systemColors[1]
  }
}));

export default Confirmation;
