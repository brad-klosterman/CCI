import React, { useState, useCallback, useEffect } from "react";
import produce from "immer";
import { makeStyles } from "@material-ui/core/styles";
import { withStyles } from "@material-ui/core/styles";
import {
  Grid,
  Button,
  Typography,
  IconButton,
  Tooltip
} from "@material-ui/core";
import { CSwitch } from "Components/Switch";
import { MultiSelect } from "Components/Selects/MultiSelect";
import { CreateDialog } from "Components/Selects/Alert";
import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import Selector from "Components/Selects/Selector";
import Clear from "@material-ui/icons/DeleteForever";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useInput, validations } from "util/forms";

/// PERHAPS MAP THE RESULTS AFTER ALL IDENTITIES ARE ADDED TO THE STATE

const AddRoles = ({
  organisation,
  userOrganisations,
  identity,
  userType,
  sending,
  onSend
}) => {
  const classes = useStyles();

  useEffect(() => {
    sending && validate();
  });

  //////////////////////////////////////////
  /* STATE */
  const [expanded, setExpanded] = useState(0);
  const [expanded2, setExpanded2] = useState(0);
  const [addOrg, setAddOrg] = useState(false);
  const [addInst, setAddInst] = useState(false);
  const [identities, setIdentities] = useState([]);
  const [alert, setAlert] = useState({ open: false, msg: "" });

  const api =
    "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/organisation/";

  useEffect(() => {
    organisation && addOrganisation(organisation);
  }, [userType]);

  useEffect(() => {
    identity && createIdentity(identity);
  }, [identity]);

  /// API

  class HttpError extends Error {
    constructor(response) {
      super(`${response.status} for ${response.url}`);
      this.name = "HttpError";
      this.response = response;
    }
  }

  async function orgJson(guid) {
    let response = await fetch(api + guid);
    if (response.status === 200) {
      return response.json();
    } else {
      throw new HttpError(response);
    }
  }

  const createInstance = ({ userInstances, orgInstances }) => {
    const matchInstance = guid =>
      orgInstances.find(e => e.instance.instanceGuid === guid);

    const matchArea = ({ guid, instanceAreas }) =>
      instanceAreas.find(e => e.areaGuid === guid);

    const createAreas = ({ userAreas, instanceAreas }) =>
      userAreas.reduce((acc, oj) => {
        const match = matchArea({ guid: oj.areaGuid, instanceAreas });
        return [
          ...acc,
          {
            areaGuid: oj.areaGuid,
            areaName: match && match.areaName,
            roles: oj.roles
          }
        ];
      }, []);

    return userInstances.reduce((acc, oj) => {
      const match = matchInstance(oj.instanceGuid);
      return [
        ...acc,
        {
          instanceGuid: oj.instanceGuid,
          instanceName: match && match.instance.instanceName,
          defaultAreaGuid: oj.defaultAreaGuid,
          instanceAreas: match && match.areas,
          areas: createAreas({
            userAreas: oj.areas,
            instanceAreas: match && match.areas
          })
        }
      ];
    }, []);
  };

  async function createIdentity(identity) {
    console.log("createIDentity");
    let newState = [];
    for (const organisation of identity) {
      const data = await orgJson(organisation.organisationGuid);
      newState.push({
        organisationName: organisation.organisationName,
        organisationGuid: organisation.organisationGuid,
        data: data.result,
        organisationRoles: data.roles,
        instances: organisation.instances
          ? createInstance({
              userInstances: organisation.instances,
              orgInstances: data.result
            })
          : []
      });
    }

    setIdentities(newState);
  }

  //////////////////////////////////////////
  /* CALLBACKS */

  const changePanel = panel => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
    setExpanded2(false);
  };
  const changePanel2 = panel => (event, newExpanded) => {
    setExpanded2(newExpanded ? panel : false);
  };

  const addBtn = () => {
    setAddOrg(true);
  };
  const addInstBtn = () => {
    setAddInst(true);
  };

  const closeAlert = () => {
    setAlert({ open: false, msg: "" });
  };

  const addOrganisation = useCallback(
    organisation => {
      console.log("createOrg", organisation);
      setAddOrg(false);
      setExpanded(identities.length);
      async function fetchOrg() {
        const response = await fetch(api + organisation.organisationGuid);
        const orgJson = await response.json();
        !orgJson.result &&
          setAlert({ open: true, msg: "No Instances for this Organisation." });

        const nextState = produce(identities, draftState => {
          draftState.push({
            organisationName: organisation.organisationName,
            organisationGuid: organisation.organisationGuid,
            data: orgJson.result,
            organisationRoles: orgJson.roles,
            instances: []
          });
        });
        setIdentities(nextState);
      }
      fetchOrg();
    },
    [identities]
  );

  const addInstance = useCallback(
    ({ ev, orgIndex }) => {
      setAddInst(false);
      setExpanded2(identities[orgIndex].instances.length);
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances.push({
          instanceName: ev.instance.instanceName,
          instanceGuid: ev.instance.instanceGuid,
          areas: [],
          instanceAreas: ev.areas,
          defaultAreaGuid: ""
        });
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const addArea = useCallback(
    ({ ev, orgIndex, instIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].areas.push({
          areaGuid: "",
          areaName: "",
          roles: []
        });
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onArea = useCallback(
    ({ area, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].areas[areaIndex] = {
          ...draftState[orgIndex].instances[instIndex].areas[areaIndex],
          areaGuid: area.areaGuid,
          areaName: area.areaName,
          roles: []
        };
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onRole = useCallback(
    ({ role, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].areas[areaIndex].roles = role;
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onSwitch = useCallback(
    ({ orgIndex, instIndex, area }) => {
      const nextState = produce(identities, draftState => {
        draftState[orgIndex].instances[instIndex].defaultAreaGuid = area;
      });
      setIdentities(nextState);
    },
    [identities]
  );

  const onDeleteOrganisation = useCallback(
    ({ orgIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex];
      });

      setIdentities(nextState);
    },
    [identities]
  );

  const onDeleteInstance = useCallback(
    ({ orgIndex, instIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex].instances[instIndex];
      });

      setIdentities(nextState);
    },
    [identities]
  );

  const onDeleteArea = useCallback(
    ({ execute, orgIndex, instIndex, areaIndex }) => {
      const nextState = produce(identities, draftState => {
        delete draftState[orgIndex].instances[instIndex].areas[areaIndex];
      });
      execute ? setIdentities(nextState) : setAlert(true);
    },
    [identities]
  );

  let addOrgBtn;
  if (addOrg) {
    addOrgBtn = (
      <Selector
        id="Organisation"
        items={userOrganisations}
        onSelect={ev => addOrganisation(ev)}
        width={5}
      />
    );
  } else {
    addOrgBtn = (
      <Grid item xs={12}>
        <Button color="primary" variant="outlined" onClick={addBtn}>
          Add An Organisation
        </Button>
      </Grid>
    );
  }

  const validate = () => {
    let allRoles = [];
    let validate = true;

    const createRoles = areas =>
      areas.reduce((acc, area) => {
        let ar = [];
        area.roles.forEach(role => ar.push(role.roleGuid));
        return [
          ...acc,
          {
            areaId: area.areaGuid,
            roles: ar
          }
        ];
      }, []);

    identities.map(organisation =>
      organisation.instances.length === 0
        ? (setAlert({
            open: true,
            msg:
              "Please Select an Instance for " + organisation.organisationName
          }),
          (validate = false))
        : organisation.instances.map(instance =>
            instance.areas.length === 0
              ? (setAlert({
                  open: true,
                  msg:
                    "Please Select an Area for " +
                    organisation.organisationName +
                    " > " +
                    instance.instanceName
                }),
                (validate = false))
              : (instance.areas.map(area =>
                  area.areaGuid === ""
                    ? (setAlert({
                        open: true,
                        msg:
                          "Please Select an Area for " +
                          organisation.organisationName +
                          " > " +
                          instance.instanceName
                      }),
                      (validate = false))
                    : area.roles.length === 0
                    ? (setAlert({
                        open: true,
                        msg:
                          "Select a Role for " +
                          organisation.organisationName +
                          " > " +
                          instance.instanceName +
                          " > " +
                          area.areaName
                      }),
                      (validate = false))
                    : true
                ),
                allRoles.push({
                  instanceGuid: instance.instanceGuid,
                  organisationGuid: organisation.organisationGuid,
                  defaultAreaGuid: instance.defaultAreaGuid,
                  roles: createRoles(instance.areas)
                }))
          )
    );

    if (!validate) {
      allRoles = [];
    }

    validate && allRoles.length !== 0 && onSend
      ? onSend(allRoles)
      : onSend(false);
  };

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        {identities.map((organisation, orgIndex) => (
          <ExpansionPanel
            panel={orgIndex}
            changePanel={changePanel}
            expanded={expanded}
            title={organisation.organisationName}
            key={orgIndex}
            onDelete={() => onDeleteOrganisation({ orgIndex })}
          >
            <Grid
              item
              xs={12}
              className={organisation.instances.length ? "" : classes.hidden}
            >
              {organisation.instances.map((instance, instIndex) => (
                <ExpansionPanel
                  panel={instIndex}
                  changePanel={changePanel2}
                  expanded={expanded2}
                  title={instance.instanceName}
                  key={instIndex}
                  onDelete={() => onDeleteInstance({ orgIndex, instIndex })}
                >
                  {instance.areas.length !== 0 &&
                    instance.areas.map((area, areaIndex) => (
                      <RoleSelector
                        key={areaIndex}
                        areas={instance.instanceAreas}
                        roles={organisation.organisationRoles}
                        selectedAreas={instance.areas}
                        selectedRoles={area.roles}
                        area={area}
                        onArea={area =>
                          onArea({ area, orgIndex, instIndex, areaIndex })
                        }
                        onRole={role =>
                          onRole({ role, orgIndex, instIndex, areaIndex })
                        }
                        onSwitch={area =>
                          onSwitch({ orgIndex, instIndex, area })
                        }
                        defaultArea={instance.defaultAreaGuid}
                        onDeleteArea={execute =>
                          onDeleteArea({
                            execute,
                            orgIndex,
                            instIndex,
                            areaIndex
                          })
                        }
                      />
                    ))}
                  <Grid item xs={12}>
                    <Button
                      color="primary"
                      variant="outlined"
                      onClick={ev => addArea({ ev, orgIndex, instIndex })}
                    >
                      Add Area
                    </Button>
                  </Grid>
                </ExpansionPanel>
              ))}
            </Grid>

            {addInst ? (
              <Selector
                id="Instance"
                items={organisation.data}
                onSelect={ev => addInstance({ ev, orgIndex })}
                width={5}
                selected={identities[orgIndex].instances}
              />
            ) : (
              <Grid item xs={12}>
                <Button color="primary" variant="outlined" onClick={addInstBtn}>
                  Add An Instance
                </Button>
              </Grid>
            )}
          </ExpansionPanel>
        ))}
      </Grid>

      {userType.cci && addOrgBtn}

      <CreateDialog
        open={alert.open}
        onClose={closeAlert}
        title="title"
        state={0}
      />
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {},
  instance: {
    display: "flex",
    alignItems: "center",
    backgroundColor: theme.grey,
    borderRadius: 4,
    padding: `${theme.spacing(1)}px ${theme.spacing(1)}px`
  },
  instanceTitle: {
    flexGrow: 1
  },
  addArea: {
    paddingRight: 4,
    width: 16
  },
  hidden: {
    display: "none"
  }
}));

const RoleSelector = ({
  index,
  area,
  areas,
  roles,
  selectedAreas,
  selectedRoles,
  onDeleteArea,
  onArea,
  onRole,
  defaultArea,
  onSwitch
}) => {
  const classes = roleStyles();
  const guid = area.areaGuid;

  const onSelectArea = ev => {
    onArea && onArea(ev);
  };

  const deleteArea = () => {
    onDeleteArea(defaultArea !== area ? true : false);
  };

  useEffect(() => {
    guid !== "" && defaultArea === "" && onSwitch(guid);
  });

  // console.log("area", area.areaGuid, defaultArea);

  return (
    <>
      <Selector
        id="Area"
        value={area.areaName !== "" ? area : ""}
        items={areas}
        onSelect={onSelectArea}
        selected={selectedAreas}
        width={4}
      >
        <Tooltip title="Make Default Area">
          <div className={classes.switchbox}>
            <CSwitch
              disabled={guid === ""}
              checked={defaultArea === guid && guid !== ""}
              onChange={() => onSwitch(guid)}
              value="checkedC"
            />
          </div>
        </Tooltip>
      </Selector>

      <MultiSelect
        id="Roles"
        value={selectedRoles}
        items={roles}
        width={8}
        onSelect={onRole}
      >
        <Tooltip title="Delete Area">
          <IconButton
            aria-label="Close"
            className={classes.deleteBtn}
            onClick={deleteArea}
          >
            <Clear fontSize="small" />
          </IconButton>
        </Tooltip>
      </MultiSelect>
    </>
  );
};
const roleStyles = makeStyles(theme => ({
  deleteBtn: {
    paddingRight: 0,
    color: theme.grey[2],
    marginBottom: theme.spacing(-2)
  },
  switchbox: {
    display: "flex",
    alignItems: "center",
    paddingLeft: 32,
    marginBottom: theme.spacing(-2)
  }
}));

const ExpansionPanel = withStyles(theme => ({
  root: {
    border: "2px solid rgba(228,228,228,1)",
    boxShadow: "none",
    "&:not(:last-child)": {
      borderBottom: 0
    },
    "&:before": {
      display: "none"
    },
    "&$expanded": {
      margin: "auto"
    }
  },
  expanded: { margin: "0px!important" },
  summary: {
    alignItems: "center",
    color: theme.grey[2],
    margin: `${theme.spacing(1)}px 0px`,
    "&$expanded": {
      display: "none"
    }
  },
  title: {
    flexGrow: 1
  },
  delete: {
    paddingRight: 0
  },
  details: {
    padding: `${theme.spacing(2)}px ${theme.spacing(4)}px`
  }
}))(props => {
  const {
    classes,
    panel,
    expanded,
    title,
    onDelete,
    changePanel,
    children
  } = props;
  return (
    <MuiExpansionPanel
      expanded={expanded === panel}
      onChange={changePanel(panel)}
      classes={{ root: classes.root, expanded: classes.expanded }}
    >
      <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
        <Typography className={classes.title} variant="h3">
          {title}
        </Typography>
        <IconButton className={classes.delete} onClick={onDelete}>
          <Clear fontSize="small" />
        </IconButton>
      </ExpansionPanelSummary>

      <Grid container spacing={4} className={classes.details}>
        {children}
      </Grid>
    </MuiExpansionPanel>
  );
});

const ExpansionPanelSummary = withStyles(theme => ({
  root: {
    backgroundColor: "rgba(65,68,75,0.05)",
    borderBottom: "0px",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56
    }
  },
  content: {
    alignItems: "center",
    color: theme.grey[1],
    margin: "8px 0px",
    "&$expanded": {
      margin: "8px 0"
    }
  },
  expanded: {}
}))(MuiExpansionPanelSummary);

export default AddRoles;
