import React, { useState, useCallback, useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  TextField,
  FormControlLabel,
  Checkbox,
  InputAdornment
} from "@material-ui/core";
import Selector from "Components/Selects/Selector";
import { URContext } from "../UState/UState";
import { useInput, useSelector, useSubmit, validations } from "util/forms";
import { languages, userTypes } from "./data";

const AddBasic = ({
  userOrganisations,
  user,
  userType,
  onCheckA,
  sending,
  onSend
}) => {
  const classes = useStyles();
  const api =
    "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AdminConsole.BFF/Cci.Tracc.AdminConsole.BFF.API/organisation/";

  /// STATE
  const { URState, URDispatch } = useContext(URContext);

  useEffect(() => {
    sending && validate();
  });

  useEffect(
    () => {
      user && onOrganisation(user.organisation);
    },
    [user]
  );

  useEffect(
    () => {
      userType && onOrganisation(userType.org);
    },
    [userType]
  );

  const parseEmail = email => {
    let parsed = email.split("@");
    return {
      email: parsed[0],
      domain: parsed[1]
    };
  };

  //////////////////////////////////////////
  /* STATE */
  const [organisation, setOrganisation] = useState({ result: [], roles: [] });
  const [areas, setAreas] = useState([]);
  const [identity, setIdentity] = useState({
    organisation: user ? user.organisation : undefined,
    instance: undefined,
    area: undefined
  });
  const [fields, setFields] = useState({
    domain: user && parseEmail(user.email).domain,
    language: undefined,
    userType: user && user.userType
  });
  const firstName = useInput({
    name: "First Name",
    value: user && user.firstname,
    updated: () => URDispatch({ type: "UPDATED", payload: true }),
    validate: handleValidation,
    regex: validations.COUNT,
    erMsg: "Invalid Name"
  });
  const lastName = useInput({
    name: "Last Name",
    value: user && user.lastname,
    validate: handleValidation,
    regex: validations.COUNT,
    erMsg: "Invalid Name"
  });
  const email = useInput({
    name: "Email",
    value: user && parseEmail(user.email).email,
    validate: handleValidation,
    regex: validations.COUNT,
    erMsg: "Invalid Email Address"
  });
  const homeDomain = useSelector({
    value: fields.domain,
    erMsg: "Please Select an Email Domain"
  });
  const homeOrg = useSelector({
    value: identity.organisation,
    erMsg: "Please Select an Organisation"
  });
  const homeInst = useSelector({
    value: identity.instance && identity.instance,
    erMsg: "Please Select an Instance"
  });
  const homeArea = useSelector({
    value: identity.area || "",
    erMsg: "Please Select an Area"
  });
  const homeLanguage = useSelector({
    value: fields.language,
    erMsg: "Please Select a Language"
  });
  const homeType = useSelector({
    value: fields.userType,
    erMsg: "Please Select a Type"
  });

  function handleValidation(value, regex) {
    if (value && regex && value.match(regex)) return true;
    return false;
  }

  const submit = useSubmit([
    firstName,
    lastName,
    email,
    homeDomain,
    homeOrg,
    homeInst,
    homeArea,
    homeLanguage,
    homeType
  ]);

  const validate = () => {
    submit.onSubmit()
      ? onSend({
          email: email.props.value + "@" + fields.domain,
          firstname: firstName.props.value,
          lastname: lastName.props.value,
          organisationGuid: identity.organisation.organisationGuid,
          instanceGuid: identity.instance.instanceGuid,
          defaultAreaGuid: identity.area.areaGuid,
          defaultLanguage: "en-us",
          userType: fields.userType
        })
      : onSend(false);
    URDispatch({ type: "UPDATED", payload: false });
  };

  //////////////////////////////////////////
  /* CALLBACKS */

  const onOrganisation = useCallback(
    ev => {
      const createIdentity = instances => {
        const match = instances => {
          const instance = instances.find(
            e => e.instance.instanceGuid === user.instanceGuid
          );
          return {
            instance: instance && instance.instance,
            instanceAreas: instance && instance.areas,
            area:
              instance && instance.areas.find(e => e.areaGuid === user.areaGuid)
          };
        };
        const { instance, instanceAreas, area } = match(instances);
        setIdentity({
          organisation: ev,
          instance: instance,
          area: area
        });
        setAreas(instanceAreas || []);
      };

      async function fetchOrg() {
        const response = await fetch(api + ev.organisationGuid);
        const orgJson = await response.json();
        setOrganisation(orgJson.result ? orgJson : { result: [], roles: [] });
        !orgJson.result && alert("No Instances");

        user
          ? createIdentity(orgJson.result)
          : setIdentity({
              organisation: ev,
              instance: undefined,
              area: undefined
            });
      }
      fetchOrg();
    },
    [user]
  );

  const onInstance = useCallback(
    ev => {
      ev.areas && setAreas(ev.areas);
      setIdentity({
        ...identity,
        instance: ev.instance,
        area: undefined
      });
    },
    [identity]
  );

  const onArea = useCallback(
    ev => {
      ev.areaGuid && setIdentity({ ...identity, area: ev });
    },
    [identity]
  );

  const onField = useCallback(
    ({ ev, name }) => {
      setFields({
        ...fields,
        [name]: ev
      });
    },
    [fields]
  );

  return (
    <Grid container spacing={4} className={classes.root}>
      <Grid item xs={6}>
        <TextField label="First Name" {...firstName.props} />
      </Grid>
      <Grid item xs={6}>
        <TextField label="Last Name" {...lastName.props} />
      </Grid>
      <Selector
        id="Organisation"
        items={userOrganisations}
        onSelect={onOrganisation}
        width={6}
        disabled={user ? true : false}
        {...homeOrg.props}
      />
      <Selector
        id="Instance"
        items={organisation.result}
        onSelect={onInstance}
        width={6}
        disabled={organisation.result.length === 0 || user !== null}
        {...homeInst.props}
      />
      <Selector
        id="Area"
        items={areas}
        width={6}
        onSelect={onArea}
        disabled={identity.instance === undefined}
        {...homeArea.props}
      />
      <Selector
        id="Language"
        items={languages}
        onSelect={ev => onField({ ev, name: "language" })}
        disabled={organisation.result.length === 0}
        width={6}
        {...homeLanguage.props}
      />
      <Grid item xs={6}>
        <TextField
          label="Email"
          disabled={organisation.result.length === 0}
          InputProps={{
            endAdornment: <InputAdornment position="end">@</InputAdornment>
          }}
          {...email.props}
        />
      </Grid>
      <Selector
        id="Domain"
        items={identity.instance ? identity.instance.emailDomainWhiteList : []}
        onSelect={ev => onField({ ev, name: "domain" })}
        disabled={organisation.result.length === 0}
        width={6}
        {...homeDomain.props}
      />
      <Selector
        id="User Type"
        items={userTypes}
        onSelect={ev => onField({ ev, name: "userType" })}
        disabled={organisation.result.length === 0}
        width={6}
        {...homeType.props}
      />
      {!user && (
        <Grid item xs={6}>
          <FormControlLabel
            control={<Checkbox onChange={onCheckA} value="checkedA" />}
            label="Allocate User to Area Roles"
          />
        </Grid>
      )}
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {
    // padding: 32
  },
  selected: {
    color: "white",
    backgroundColor: theme.dark[1]
  },
  divider: {
    height: 4,
    backgroundColor: theme.dark[1]
  }
}));

export default AddBasic;
