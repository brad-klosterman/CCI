export const languages = ["English", "Spanish"];
export const userTypes = ["CCI", "Client"];
