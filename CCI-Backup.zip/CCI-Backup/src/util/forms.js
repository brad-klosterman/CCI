import { useState, useEffect } from "react";

export function useSelector({ value, field, erMsg }) {
  const [error, setError] = useState(null);
  useEffect(
    () => {
      value && setError(false);
    },
    [value]
  );

  function handleValidate() {
    const valid = value ? true : false;
    setError(!valid);
    return valid;
  }

  return {
    props: {
      value,
      field,
      error,
      erMsg: error && erMsg
    },
    validate: handleValidate
  };
}

export function useInput({
  name,
  field,
  value,
  updated,
  validate,
  regex,
  erMsg
}) {
  const [val, setVal] = useState(value ? value : "");
  const [error, setError] = useState(null);

  function handleChange(ev) {
    setVal(ev.target.value);
    setError(null);
  }

  function handleKeyDown(ev) {
    updated && updated();
  }

  function handleValidate() {
    const valid = validate && validate(val, regex);
    setError(!valid);
    return valid;
  }

  return {
    props: {
      value: val,
      field,
      onChange: handleChange,
      onKeyDown: handleKeyDown,
      error,
      helperText: error && erMsg,
      fullWidth: true
    },
    validate: handleValidate
  };
}

export function useSubmit(inputs) {
  const [errorItems, setErrorItems] = useState(null);

  function handleSubmit() {
    const errorItems = inputs.filter(input => !input.validate());
    setErrorItems(errorItems);

    if (errorItems && errorItems.length === 0) {
      const success = inputs.reduce((acc, { props: { field, value } }) => {
        let fieldValue = value;

        if (field === "organisationGuid") {
          fieldValue = value.organisationGuid;
        } else if (field === "instanceGuid") {
          fieldValue = value.instanceGuid;
        } else if (field === "defaultAreaGuid") {
          fieldValue = value.areaGuid;
        } else if (field === "domain") {
          fieldValue = acc.email + "@" + value;
          field = "email";
        }
        return {
          ...acc,
          [field]: fieldValue
        };
      }, {});

      return success;
    } else {
      return false;
    }
  }

  return {
    onSubmit: handleSubmit,
    errorItems
  };
}

// regular expression constants for validation
export const validations = {
  // eslint-disable-next-line
  EMAIL: /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  NUMBER: /^\d*$/,
  COUNT: /^[a-zA-Z]{2,}$/
};
