import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
  forwardRef
} from "react";
import { makeStyles, fade } from "@material-ui/core/styles";
import {
  Grid,
  FormControl,
  InputLabel,
  Select,
  OutlinedInput,
  Collapse,
  Typography,
  MenuItem
} from "@material-ui/core";

import ExpandIcon from "@material-ui/icons/ExpandMore";
import CollapseIcon from "@material-ui/icons/ChevronRight";
import NoneIcon from "@material-ui/icons/FiberManualRecord";

export function useTreeSelect() {
  const [state, setState] = useState(undefined);
  const transformedData = useRef(undefined);
  const triggerUpdate = useRef(false);

  const updateState = useCallback(() => {
    setState(prevState => !prevState);
  }, []);

  if (triggerUpdate.current) {
    transformedData.current = state;
    triggerUpdate.current = true;
  }

  if (triggerUpdate.current) {
    triggerUpdate.current = false;
  }

  return {
    transformedData,
    filterActions: {
      updateState
    }
  };
}

export function TreeSelect({ id, data, disabled, error }) {
  const cx = useStyles();
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const inputLabel = useRef(null);
  const [labelWidth, setLabelWidth] = useState(0);

  useEffect(() => {
    setLabelWidth(inputLabel.current.offsetWidth);
  }, []);

  function onSelect(id, name) {
    setOpen(prevOpen => !prevOpen);
    setValue({ id, name });
    console.log("onselect", id);
  }

  const TreeRender = ({ area: { id, name }, children }) => {
    // console.log("TREERENDER", name);
    const props = {
      key: id,
      id,
      name,
      onSelect
    };
    if (!Array.isArray(children) || !children.length) {
      return <TreeItem {...props} />;
    }
    return (
      <TreeItem {...props}>{children.map(node => TreeRender(node))}</TreeItem>
    );
  };

  return (
    <Grid item xs={6}>
      <FormControl
        fullWidth
        disabled={disabled}
        variant="outlined"
        error={error}
      >
        <InputLabel htmlFor={id} ref={inputLabel}>
          {id}
        </InputLabel>
        <Select
          value={value || ""}
          renderValue={value => (value ? value.name : null)}
          autoWidth={false}
          open={open}
          onOpen={() => setOpen(true)}
          input={
            <OutlinedInput
              labelWidth={labelWidth}
              name={id.toLowerCase()}
              id={id}
              fullWidth
            />
          }
          MenuProps={{ classes: { paper: cx.paper } }}
        >
          {data.map(i => TreeRender(i))}
        </Select>
      </FormControl>
    </Grid>
  );
}

/// TREEITEM

const TreeItem = forwardRef(function TreeItem(
  { id, name, children, onSelect },
  ref
) {
  const cx = useItems();
  const expandable = Boolean(
    Array.isArray(children) ? children.length : children
  );
  const [expanded, setExpanded] = useState(false);

  let icon;
  if (!icon) {
    if (expandable) {
      if (expanded) {
        icon = <ExpandIcon className={cx.icon} fontSize="small" />;
      } else {
        icon = <CollapseIcon className={cx.icon} fontSize="small" />;
      }
    } else {
      icon = <NoneIcon className={cx.noneIcon} fontSize="small" />;
    }
  }

  function onClick(event) {
    event.stopPropagation();
    onSelect(id, name);
  }

  function onExpand(event) {
    event.stopPropagation();
    setExpanded(prevExpanded => !prevExpanded);
  }

  return (
    <li className={cx.item} role="treeitem">
      <MenuItem component="div" onClick={onClick}>
        <div className={cx.iconContainer} onClick={onExpand}>
          {icon}
        </div>
        <Typography
          component="div"
          variant="h3"
          color="inherit"
          className={cx.label}
        >
          {name}
        </Typography>
      </MenuItem>
      {children && (
        <Collapse
          unmountOnExit
          className={cx.group}
          classes={{ wrapperInner: cx.groupWrapper }}
          in={expanded}
          component="ul"
          role="group"
        >
          {children}
        </Collapse>
      )}
    </li>
  );
});

const useItems = makeStyles(theme => ({
  item: {
    listStyle: "none",
    margin: 0,
    padding: 0,
    outline: 0
    // marginBottom: 8,
    // marginTop: 8
  },

  group: {
    // marginTop: 8,
    // marginLeft: 16,
    paddingLeft: 20
    // borderLeft: `1px dashed ${fade(theme.palette.text.primary, 0.4)}`,
    // "&:last-child": {
    //   marginBottom: 0
    // },
    // "&:first-child": {
    //   marginTop: 0
    // }
  },
  // groupWrapper: {
  //   "& li:last-child": {
  //     marginBottom: 0
  //   },
  //   "& li:first-child": {
  //     marginTop: 0
  //   }
  // },
  content: {
    width: "100%",
    // height: 40,
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    paddingTop: 8,
    paddingBottom: 8,
    "&:hover": {
      color: theme.palette.primary.main
    },
    "&:focus": {
      outline: "0!important"
    }
  },
  label: {
    width: "100%",
    fontSize: 14,
    lineHeight: 1
  },
  iconContainer: {
    marginRight: 4,
    width: 24,
    display: "flex",
    justifyContent: "center"
  },
  icon: {
    fontSize: 20
  },
  noneIcon: {
    fontSize: 8
  }
}));

const useStyles = makeStyles(theme => ({
  root: {},
  paper: {
    padding: "16px 32px",
    width: 500
  }
}));

// const treeData = [{
//   id: 1,
//   name: "Info",
//   children: [
//   {
//     id: 2,
//     name: "Company",
//     children: [
//     {
//       id: 3,
//       name: "Test1",
//       children: []
//     },
//     {
//       id: 4,
//       name: "Test2",
//       children: [
//        {
//         id: 21,
//         name: "Test1",
//         children: []
//        },
//        {
//         id: 22,
//         name: "Test2",
//         children: []
//        }]
//      }
//    ]
// }]

// const data = [
//   {
//     id: 1,
//     name: "Area 1",
//     children: [
//       { id: 21, name: "Area 2-1", children: [] },
//       {
//         id: 22,
//         name: "Area 2-2",
//         children: [
//           { id: 221, name: "Area 2-2-1", children: [] },
//           { id: 222, name: "Area 2-2-2", children: [] }
//         ]
//       }
//     ]
//   },
//   {
//     id: 2,
//     name: "Area 2",
//     children: [
//       { id: 31, name: "Area 3-1", children: [] },
//       { id: 32, name: "Area 3-2", children: [] },
//       { id: 33, name: "Area 3-3", children: [] }
//     ]
//   },
//   { id: 3, name: "Area 3", children: [] }
// ];
