export const id = [
  {
    organisationGuid: "60c80057-4e25-42dc-a89e-612e2fc457d8",
    organisationName: "1 - CCI Corporate",
    instances: [
      {
        instanceGuid: "1ee55bfa-f4eb-4bf6-99c1-a96c9ace7a51",
        instanceName: "TRACC Platform",
        defaultAreaGuid: "95b026e0-15c3-4dfd-b043-0be2d4be9fc6",
        areas: [
          {
            areaGuid: "95b026e0-15c3-4dfd-b043-0be2d4be9fc6",
            areaName: "Tracc Area",
            roles: [
              {
                roleGuid: "7461aee8-9e70-422f-a4da-a0651deb1b30",
                roleName: "ITF Lead"
              }
            ]
          }
        ]
      }
    ]
  }
];

export const identity = {
  id: "0f1c07c8-0d99-4044-8910-435d58382d6b",
  email: "gggggg@omnia.co.za",
  firstname: "Brad",
  lastname: "Klosterman",
  defaultLanguage: "en-us",
  organisation: {
    organisationGuid: "60c80057-4e25-42dc-a89e-612e2fc457d8",
    organisationName: "1 - CCI Corporate"
  },
  instanceGuid: "1ee55bfa-f4eb-4bf6-99c1-a96c9ace7a51",
  areaGuid: "adc007f1-0e50-4990-9313-aa8b3f07291c",
  userType: "CCI",
  dateCreated: null,
  dateLastActive: null,
  identities: [
    {
      organisationGuid: "60c80057-4e25-42dc-a89e-612e2fc457d8",
      organisationName: "1 - CCI Corporate",
      instances: [
        {
          instanceGuid: "1ee55bfa-f4eb-4bf6-99c1-a96c9ace7a51",
          defaultAreaGuid: "95b026e0-15c3-4dfd-b043-0be2d4be9fc6",
          identityGuid: "00000000-0000-0000-0000-000000000000",
          areas: [
            {
              roles: [
                {
                  roleGuid: "7461aee8-9e70-422f-a4da-a0651deb1b30",
                  roleName: "ITF LEAD",
                  instanceGuid: "00000000-0000-0000-0000-000000000000"
                }
              ],
              areaGuid: "95b026e0-15c3-4dfd-b043-0be2d4be9fc6"
            }
          ]
        }
      ]
    }
  ]
};
