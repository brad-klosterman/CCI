import React, { useEffect, useState, useCallback, useRef } from "react";

const desc = (a, b, orderBy) => {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
};

export const stableSort = (array, cmp) => {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
};

export const getSorting = order => {
  return order.direction === "desc"
    ? (a, b) => desc(a, b, order.field)
    : (a, b) => -desc(a, b, order.field);
};

export const isKeyValue = key => value => object => {
  return object[key].toLowerCase().indexOf(value.toLowerCase()) === 0;
};

export const isKeyActive = key => value => object => {
  return object[key].toString() === value;
  // return object[key].indexOf(value.toLowerCase()) === 0;
};

export const isKeyValueArray = key => value => object => {
  return object[key.root].some(e => e[key.field] === value[key.value]);
};

export const isKeyValueRole = key => ({ instance, role }) => object => {
  return object[key].some(
    e => e.roleGuid === role && (instance ? e.instanceGuid === instance : true)
  );
};

export const filterEvery = predicates => value => {
  return predicates.every(predicate => predicate(value));
};

const isFirst = isKeyValue("firstname");
const isLast = isKeyValue("lastname");
const isEmail = isKeyValue("email");
const isInstance = isKeyValueArray({
  root: "instances",
  field: "instanceGuid",
  value: "instanceGuid"
});
const isRole = isKeyValueRole("roles");
const isActive = isKeyActive("active");

export const usersFilters = {
  order: { direction: "asc", field: "firstname" },
  fields: {
    firstname: {
      value: "",
      filter: isFirst
    },
    lastname: {
      value: "",
      filter: isLast
    },
    email: {
      value: "",
      filter: isEmail
    },
    instance: {
      value: "",
      filter: isInstance
    },
    role: {
      value: "",
      filter: isRole
    },
    active: {
      value: undefined,
      filter: isActive
    }
  }
};

export function useFilters({ data, filters }) {
  const { fields, order } = filters;
  const [params, setParams] = useState(() => {
    let initParam = {};
    Object.keys(fields).forEach(function(filter) {
      initParam[filter] = fields[filter].value;
    });
    return initParam;
  });
  const [paramsOrder, setParamsOrder] = useState(order);
  const [sorted, setSorted] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const transformedData = useRef([]);
  const paramsData = useRef({});
  const triggerUpdateRef = useRef(false);

  useEffect(() => {
    setSorted(stableSort(data, getSorting(order)));
  }, [data, order]);

  useEffect(() => {
    let combined = [];
    const { instance, role } = params;
    if (params && sorted.length) {
      Object.keys(params).forEach(function(param) {
        if (params[param]) {
          let value;
          if (param === "role") {
            value = {
              instance: instance && instance.id,
              role: role["roleGuid"]
            };
          } else {
            value = params[param];
          }
          combined.push(fields[param].filter(value));
        }
      });
      setFiltered(sorted.filter(filterEvery(combined)));
      triggerUpdateRef.current = true;
    }
  }, [fields, params, sorted]);

  const updateParam = useCallback(event => {
    setParams(prevParams => ({
      ...prevParams,
      [event.name]: event.value
    }));
  }, []);

  const clearSelects = useCallback(() => {
    setParams(prevParams => ({
      ...prevParams,
      instance: undefined,
      role: undefined
    }));
  }, []);

  const updateOrder = useCallback(() => {
    console.log("updateorder");
  }, []);

  if (triggerUpdateRef.current) {
    transformedData.current = filtered;
    paramsData.current = params;
  }

  if (triggerUpdateRef.current) {
    triggerUpdateRef.current = false;
  }

  return {
    filteredData: {
      transformed: transformedData.current,
      params: paramsData.current,
      order: paramsOrder
    },
    filterActions: { updateParam, updateOrder, clearSelects }
  };
}

export function findNode({ nodeID, nodes }) {
  let foundData = null;
  var found = false;

  function recurse(nodes) {
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i].id === nodeID || nodes[i].areaID === nodeID) {
        found = true;
        foundData = nodes[i];
        break;
      } else if (nodes[i].area && nodes[i].area.rowGuid === nodeID) {
        found = true;
        foundData = nodes[i];
        break;
      } else {
        if (nodes[i].children) {
          recurse(nodes[i].children);
          if (found) {
            break;
          }
        }
      }
    }
  }
  recurse(nodes);

  return foundData;
}

export const findInstance = ({ nodeID, instances }) =>
  instances.find(x => x.rootRowGuid === nodeID);

export const findInstanceBFF = ({ nodeID, instances }) =>
  instances.find(x => x.instance.instanceGuid === nodeID);

// useEffect(() => {
//   if (data) {
//     setSorted(stableSort(data, getSorting(order)));
//     triggerUpdateRef.current = true;
//   }
// }, [data, order]);

// useEffect(() => {
//   if (sorted) {
//     setFiltered(sorted.filter(filterEvery(combinedFilters(usersFilters))));
//     triggerUpdateRef.current = true;
//   }
// }, [sorted, filters]);
//

// export function combinedFilters(param) {
//   let combined = [];
//   Object.values(param).forEach(function({ value, filter }) {
//     if (value) {
//       combined.push(filter(value));
//     }
//   });
//
//   return combined;
// }

//// SORT AND HOLD IN REF UNTIL ORDER IS CHANGED

/// if order changes take filtered data and update order and save as filtered

/// if filter changes take sorted and filter data

/// filter b then change the orderBy

/// filter takes sorted and filters - saves as filtered, change order takes filtered and orders - saves as sorted,
/// filter

// let filteredData = useMemo(() => {
//   let combinedFilters = [];
//   const {firstname, lastname, email, instance, role} = query
//   firstname && combinedFilters.push(filters.isFirst(firstname));
//   lastname && combinedFilters.push(filters.isLast(lastname));
//   email && combinedFilters.push(filters.isEmail(email));
//   instance.instanceGuid &&
//     combinedFilters.push(filters.isInstance(instance.instanceGuid));
//   role.roleGuid &&
//     combinedFilters.push(
//       filters.isRole(instance.instanceGuid, role.roleGuid)
//     );
//   if (combinedFilters.length) {
//     return users.filter(filterEvery(combinedFilters));
//   } else {
//     return users;
//   }
// }, [users, query]);
