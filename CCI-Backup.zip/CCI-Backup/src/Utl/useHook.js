import React, { useState, useRef, useCallback } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";

export function useHook() {
  const [state, setState] = useState(undefined);
  const transformedData = useRef(undefined);
  const triggerUpdate = useRef(false);

  const updateState = useCallback(() => {
    setState(prevState => !prevState);
  }, []);

  if (triggerUpdate.current) {
    transformedData.current = state;
    triggerUpdate.current = true;
  }

  if (triggerUpdate.current) {
    triggerUpdate.current = false;
  }

  return {
    transformedData,
    filterActions: {
      updateState
    }
  };
}

export function HookBox(props) {
  const cx = useStyles();

  return <Grid container></Grid>;
}

const useStyles = makeStyles(theme => ({
  root: {}
}));
