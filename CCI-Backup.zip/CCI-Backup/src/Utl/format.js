export const formatDate = value => {
  if (!value) {
    return null;
  }
  const date = new Date(value);
  return date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear();
};

export const formatDateTime = value => {
  if (!value) {
    return null;
  }
  const date = new Date(value);
  return date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear();
};

// +
// " " +
// date.getHours() +
// ":" +
// date.getMinutes()
