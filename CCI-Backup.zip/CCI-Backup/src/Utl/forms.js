import { useState, useEffect, useCallback } from "react";

export function useForm({ schema }) {
  const [data, setData] = useState();

  useEffect(() => {
    setData(schema);
  }, [schema]);

  const updateForm = useCallback(event => {
    const key = event.target.name;
    const value = event.target.value;
    setData(prev => ({
      ...prev,
      [key]: { ...prev[key], value, error: false }
    }));
  }, []);

  const updateSelects = useCallback((values, sides) => {
    values &&
      values.forEach(val => {
        setData(prev => ({
          ...prev,
          [val.id]: { ...prev[val.id], items: val.items, value: undefined }
        }));
      });
    sides &&
      sides.forEach(val => {
        setData(prev => ({
          ...prev,
          [val]: { ...prev[val], value: undefined }
        }));
      });
  }, []);

  const updateError = useCallback(
    async items => {
      const updatedData = {};

      items.forEach(item => {
        updatedData[item] = {
          ...data[item],
          error: true
        };
      });
      setData(prev => ({ ...prev, ...updatedData }));
    },
    [data]
  );

  return {
    formData: data,
    updateForm,
    updateSelects,
    updateError
  };
}

export function useInput({
  name,
  field,
  value,
  updated,
  validate,
  regex,
  erMsg
}) {
  const [val, setVal] = useState(value ? value : "");
  const [error, setError] = useState(null);

  function handleChange(ev) {
    setVal(ev.target.value);
    setError(null);
  }

  function handleKeyDown(ev) {
    updated && updated();
  }

  function handleValidate() {
    const valid = validate && validate(val, regex);
    setError(!valid);
    return valid;
  }

  return {
    props: {
      value: val,
      field,
      onChange: handleChange,
      onKeyDown: handleKeyDown,
      error,
      helperText: error && erMsg,
      fullWidth: true
    },
    validate: handleValidate
  };
}

export const parseEmail = email => {
  let parsed = email.split("@");
  return {
    address: parsed[0],
    domain: parsed[1]
  };
};
