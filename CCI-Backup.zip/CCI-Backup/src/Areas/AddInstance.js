import React, { useState, useEffect, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, TextField, Typography } from "@material-ui/core";
import { CreateDialog } from "./Alert";
import { Selector } from "Components";

const AddInstance = memo(({ open, onClose, onSend, response }) => {
  const cx = useStyles();
  const [settings, setSettings] = useState({});
  const [title, setTitle] = useState([]);

  useEffect(() => {
    const s1 = {
      InstanceName: "",
      InstallationTypeId: "",
      CountryId: ""
    };
    const s2 = {
      areaName: "",
      licensedEntity: true,
      structuralEntity: true
    };
    if (open === 1) {
      setTitle(["ADD INSTANCE", "InstanceName"]);
      setSettings(s1);
    } else {
      setSettings(s2);
      setTitle(["ADD AREA", "areaName"]);
    }
  }, [open]);

  const handleSettings = name => event => {
    let value;
    if (name === "InstallationTypeId") {
      value = event.target.value.id;
    } else {
      value = event.target.value;
    }
    setSettings({ ...settings, [name]: value });
  };

  function handleSend() {
    onSend && onSend(settings);
  }

  return (
    <CreateDialog
      open={Boolean(open)}
      onClose={onClose}
      onSend={handleSend}
      title={title[0]}
      state={response.state}
    >
      {!response.response ? (
        <Grid container spacing={2} className={cx.root}>
          <Grid item xs={12}>
            <TextField
              autoComplete="off"
              label="Name"
              value={settings[title[1]]}
              onChange={handleSettings(title[1])}
              fullWidth
            />
          </Grid>
          {open === 1 && (
            <>
              <Grid item xs={12}>
                <Selector
                  id="Installation Type"
                  items={installationTypes}
                  itemID="name"
                  value={settings.InstallationTypeId}
                  onSelect={handleSettings("InstallationTypeId")}
                />
              </Grid>
              <Grid item xs={12}>
                <Selector
                  id="Country"
                  items={countries}
                  value={settings.CountryId}
                  onSelect={handleSettings("CountryId")}
                />
              </Grid>
            </>
          )}
        </Grid>
      ) : (
        <Grid container spacing={4}>
          <Grid item xs={12}>
            <Typography variant="h2" align="center" className={cx.responseText}>
              {response.response}
            </Typography>
          </Grid>
        </Grid>
      )}
    </CreateDialog>
  );
});

const useStyles = makeStyles(theme => ({
  root: {
    padding: 16,
    paddingTop: 32
  },
  responseText: {
    paddingTop: 16
  }
}));
const installationTypes = [
  {
    id: "197d0a0e-2f13-4364-809f-401d94dee246",
    name: "Test"
  },
  {
    id: "2d21c103-5431-45c4-8e9e-d95d1354d23b",
    name: "Production"
  },
  {
    id: "B226919D-B95E-4BDA-A460-8495E77E534A",
    name: "Legacy"
  },
  {
    id: "9589A701-55AA-4A03-9269-8AB50FAEAB57",
    name: "Evaluation"
  },
  {
    id: "FAB3DF46-72DA-459C-A306-AE909C445CC8",
    name: "Demo"
  },
  {
    id: "C08F05FD-4C72-4A62-9EE8-AF88EA98DD90",
    name: "Training"
  },
  {
    id: "5B57E320-4789-4E25-B9D4-FF812A4861EE",
    name: "Site"
  }
];

const countries = ["South Africa", "USA"];

export default AddInstance;
