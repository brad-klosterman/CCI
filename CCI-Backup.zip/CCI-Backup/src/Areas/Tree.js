import React, { useState, useMemo, useEffect, useCallback } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import { useDash } from "state";
import { createDraft, finishDraft } from "immer";
import { useTR } from "./State";
import { AREAS_MAIN_API, API_DELETE_AREA, useAPI } from "Api";
import { findNode, findInstance } from "Utl";

import { TreeBar, Node, GhostNode } from ".";

function Tree({ ADD_AREA }) {
  const cx = useStyles();
  const {
    DACTIONS: { openNotification },
    DIALOG
  } = useDash();
  const { TRSTATE, TRD } = useTR();
  const { SELECTED, TREE } = TRSTATE;

  const { sendAPI, loadingAPI } = useAPI({});

  /// STATE
  const [state, setState] = useState(null);
  const [selectedCB, setSelectedCB] = useState(null);

  const [dragNode, setDragNode] = useState(null);
  const [dropNode, setDropNode] = useState(null);
  const [dragPoints, setDragPoints] = useState(null);

  // console.log("ORG", TRSTATE.ORGANISATION);
  // console.log("TREE", TRSTATE);
  console.log("SELECTED", SELECTED);
  // console.log("ORG", TRSTATE.ORGANISATION);

  /// UPDATE TREE IN LOCAL STATE
  const updateLocal = useCallback(
    async ({ source, destination }) => {
      const draft = createDraft(TRSTATE.TREE);
      let destinationNode;
      let parentNode = await findNode({
        nodeID: source.parentID,
        nodes: [draft]
      });
      if (destination) {
        destinationNode = await findNode({
          nodeID: destination.nodeID,
          nodes: [draft]
        });
        const sourceNode = await parentNode.children.filter(
          i => i["rowGuid"] === source.nodeID
        );

        sourceNode[0].area.parentGuid = destinationNode.rowGuid;
        destinationNode.children.unshift(...sourceNode);
        draft.source = sourceNode;
      }

      const filtered = parentNode.children.filter(
        i => i["rowGuid"] !== source.nodeID
      );
      parentNode.children = filtered;

      draft.des = destinationNode;
      draft.par = parentNode;

      return finishDraft(draft);
    },
    [TRSTATE.TREE]
  );

  /// DELETE IN DATABASE
  const DELETE_AREA = useCallback(
    async (type, location, nodeID, parentID) => {
      DIALOG.continueConfirm({
        variant: "continue",
        title: {
          1: "ARE YOU SURE YOU WANT TO DELETE THIS AREA?",
          2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
          3: "SUCCESS DELETEING AREA",
          4: "ERROR DELETING AREA"
        },
        actions: { ok: "SAVE", cancel: "NO", exit: "CONTINUE" },
        onExit: () => console.log("onexit")
      }).then(res => {
        if (res === "ACCEPT") {
          (async () => {
            let value, message;
            const { error } = await API_DELETE_AREA(location);
            if (!error) {
              value = "SUCCESS";
              const updatedNode = await updateLocal({
                source: { nodeID, parentID },
                destination: null
              });
              TRD({ type: "UPDATE_TREE", payload: updatedNode });
            }
            if (error) {
              value = "ERROR";
              message = error;
            }
            DIALOG.confirmationResponse({
              value,
              message
            });
          })();
        } else if (res === "REJECT") {
          console.log("rejected confirmation");
        }
      });
    },
    [DIALOG, TRD, updateLocal]
  );

  const onCloneArea = () => {
    console.log("CLONE AREA", SELECTED);
  };

  /// DND EVENTS
  useEffect(() => {
    function clearDND() {
      setDragNode(null);
      setDragPoints(null);
      setDropNode(null);
      setState(null);
    }

    const onExit = status => {
      if (status === "CONTINUE") {
        console.log("continue - reset the trigger saved state");
      } else {
        console.log("canceled - helpfix issues");
      }
    };

    if (state === "dropping") {
      // setState(null);
      DIALOG.continueConfirm({
        variant: "continue",
        title: {
          1: "ARE YOU SURE YOU WANT TO MOVE THIS AREA?",
          2: "HOLD ON WHILE WE SAVE YOUR SETTINGS...",
          3: "SUCCESS SAVING AREA",
          4: "ERROR SAVING AREA"
        },
        actions: { ok: "SAVE", cancel: "NO", exit: "CONTINUE" },
        onExit
      }).then(res => {
        if (res === "ACCEPT") {
          (async () => {
            const updated = await updateLocal({
              source: {
                nodeID: dragNode.nodeID,
                parentID: dragNode.parentID
              },
              destination: dropNode
            });
            TRD({ type: "UPDATE_TREE", payload: updated });
            clearDND();
            DIALOG.confirmationResponse({
              value: "SUCCESS"
            });

            // sendAPI({
            //   method: "PUT",
            //   url:
            //     AREAS_API +
            //     "move/" +
            //     TREE.id +
            //     "/" +
            //     dragNode.rootID +
            //     "/" +
            //     dragNode.nodeID +
            //     "/" +
            //     dropNode.nodeID,
            //   callback: async ({ response }) => {
            //     let value, error, message;
            //
            //     if (!response.error) {
            //       value = "SUCCESS";
            //       const updated = await updateLocal({
            //         source: {
            //           nodeID: dragNode.nodeID,
            //           parentID: dragNode.parentID
            //         },
            //         destination: dropNode
            //       });
            //       TRD({ type: "UPDATE_TREE", payload: updated });
            //     } else {
            //       value = "ERROR";
            //       message = error;
            //     }
            //
            //     DIALOG.confirmationResponse({
            //       value,
            //       error,
            //       message
            //     });
            //   }
            // });
          })();
        } else if (res === "REJECT") {
          console.log("rejected confirmation");
        }
      });
    }
  }, [dragNode, dropNode, state, updateLocal]);

  const onMouseMove = useCallback(event => {
    setDragPoints(prevDragPoints => ({
      ...prevDragPoints,
      xcursor: event.clientX,
      ycursor: event.clientY
    }));
  }, []);

  const onDragOver = useCallback(props => {
    setDropNode({ ...props });
  }, []);

  const onDragExit = useCallback(() => {
    setDropNode(null);
  }, []);

  const onDragEnd = useCallback(() => {
    setState("dropping");
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onDragEnd);
  }, [onMouseMove]);

  const onDrag = useCallback(
    ({
      nodeID,
      parentID,
      rootID,
      name,
      xstart,
      ystart,
      xcursor,
      ycursor,
      depth
    }) => {
      setState("dragging");
      setDragNode({ nodeID, parentID, rootID, name });
      setDragPoints({
        xstart,
        ystart,
        xcursor,
        ycursor
      });
      setDropNode({ depth });
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onDragEnd);
    },
    [onDragEnd, onMouseMove]
  );

  // const ACTIONS = {
  //   onSelect,
  //   onExpand,
  //   onDrag,
  //   dragNode,
  //   onDragOver,
  //   onDragExit,
  //   onDragEnd
  // };

  const RENDER_TREE = useMemo(() => {
    const COLOR = (color, LE, SE) => {
      if (color === "darkblue" || color === "lightblue") {
        return "lightblue";
      }
      if (LE) {
        return "darkblue";
      }
      if (SE) {
        return "green";
      }
      return "red";
    };

    const SELECT_NODE = selected => {
      if (!selected) {
        return null;
      }
      const { nodeID, rootID, instanceID, type } = selected;
      let node;

      setSelectedCB(prevSelectedCB => {
        prevSelectedCB && prevSelectedCB.onDeselect();
        return selected;
      });

      if (type === 1) {
        node = TRSTATE.ORGANISATION;
      } else if (type === 2) {
        node = findInstance({
          nodeID,
          instances: TRSTATE.TREE.children
        });
      } else if (type === 3) {
        node = {
          ...findNode({
            nodeID,
            nodes: [TRSTATE.TREE]
          }),
          rootID,
          instanceID
        };
      } else {
        setSelectedCB(selected);
        node = { TYPE: 0, NODE: undefined };
      }

      TRD({
        type: "SELECT_NODE",
        payload: {
          type,
          node
        }
      });

      if (TRSTATE.SEARCH_TREE.ID) {
        TRD({
          type: "SEARCH_TREE",
          payload: undefined
        });
      }
    };

    const ACTIONS = {
      SELECT_NODE,
      onDrag,
      dragNode,
      onDragOver,
      onDragExit,
      onDragEnd
    };

    const TreeRender = ({ DATA, ACTIONS, rootID, depth }) => {
      let PROPS = {
        depth,
        state,
        searchNode: TRSTATE.SEARCH_TREE
      };

      if (DATA.type === 1 || DATA.type === 2) {
        PROPS = {
          ...PROPS,
          key: DATA.id,
          name: DATA.name,
          nodeID: DATA.areaID,
          areaID: DATA.areaID,
          type: DATA.type
        };
      } else {
        PROPS = {
          ...PROPS,
          key: DATA.rowGuid,
          name: DATA.area.name,
          nodeID: DATA.rowGuid,
          areaID: DATA.rowGuid,
          parentID: DATA.area.parentGuid,
          type: 3,
          color: COLOR(
            DATA.color,
            Boolean(DATA.area.licensedEntity),
            Boolean(DATA.area.structuralEntity)
          ),
          instanceID: DATA.instanceID
        };
      }

      if (DATA.type === 2) {
        PROPS = {
          ...PROPS,
          rootID: DATA.areaID,
          color: "green",
          instanceID: DATA.instanceGuid
        };
      } else {
        PROPS = {
          ...PROPS,
          rootID
        };
      }

      /// TREE BAR
      if (DATA.type === 1) {
        return (
          <TreeBar
            name={DATA.name}
            nodeID={DATA.id}
            {...{ SELECT_NODE, DELETE_AREA, ADD_AREA }}
          >
            {DATA.children.map(node =>
              TreeRender({ DATA: node, ACTIONS, depth: depth + 1 })
            )}
          </TreeBar>
        );
      }

      if (DATA.children) {
        return (
          <Node {...PROPS} {...ACTIONS}>
            {DATA.children.map(node =>
              TreeRender({
                DATA: {
                  ...node,
                  instanceID: PROPS.instanceID,
                  color: PROPS.color
                },
                ACTIONS,
                rootID: PROPS.rootID,
                depth: depth + 1
              })
            )}
          </Node>
        );
      }
      return <Node {...PROPS} {...ACTIONS} rootID={PROPS.rootID} />;
    };

    return TreeRender({ DATA: TRSTATE.TREE, ACTIONS, depth: 0 });
  }, [
    TRSTATE.TREE,
    ADD_AREA,
    DELETE_AREA,
    TRSTATE.ORGANISATION,
    TRSTATE.SEARCH_TREE,
    state
  ]);

  /// RENDER

  if (!TRSTATE.TREE) {
    return null;
  }

  return (
    <>
      <Grid item xs={6}>
        <ul role="tree" className={cx.root}>
          {RENDER_TREE}
        </ul>
        {state !== "dropping" && (
          <GhostNode
            selected={SELECTED}
            depth={dropNode ? dropNode.depth : 1}
            {...dragNode}
            {...dragPoints}
            {...dropNode}
          />
        )}
      </Grid>
    </>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    padding: 0,
    margin: 0,
    listStyle: "none",
    "& li:first-child": {
      marginTop: 0
    }
  },
  backBTN: {
    width: 250,
    height: 32,
    // marginTop: 22,
    marginBottom: 16,
    fontWeight: 600,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    "&:hover": {
      color: theme.palette.primary.main
    }
  },
  backArrow: {
    fontSize: 14
  }
}));

export default Tree;

// <div onClick={ONBACK} className={cx.backBTN}>
//   <ArrowBack className={cx.backArrow} /> BACK TO ORGANISATIONS
// </div>

// function returnColor(color) {
//   if (color === "darkblue" || color === "lightblue") {
//     return "lightblue";
//   }
//   if (DATA.area.licensedEntity) {
//     return "darkblue";
//   }
//   if (DATA.area.structuralEntity) {
//     return "green";
//   }
//   return "red";
// }
