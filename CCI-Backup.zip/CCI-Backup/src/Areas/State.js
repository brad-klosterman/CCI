import React, {
  useReducer,
  useEffect,
  createContext,
  useContext,
  useState,
  useCallback
} from "react";
import { createDraft, finishDraft } from "immer";
import { Grid, TextField } from "@material-ui/core";
import { API, AREAS_MAIN_API } from "Api";
import { useDialog, DialogBox, Selector, OrgIcon } from "Components";
import { SearchTree, Organisations, Tree, TreePanel } from "Areas";
import {
  formatDate,
  findNode,
  findInstance,
  stableSort,
  getSorting
} from "Utl";
// import { getAPI } from "./Functions";

const reducer = (state, action) => {
  switch (action.type) {
    case "SET_ORGS":
      return {
        ...state,
        ORGANISATIONS: action.payload
      };
    case "ADD_ORG":
      return {
        ...state,
        ORGANISATIONS: [...state.ORGANISATIONS, action.payload]
      };
    case "UPDATE_TREE":
      return {
        ...state,
        TREE: action.payload
      };
    case "SELECT_ORG":
      return {
        ...state,
        ORGANISATION: action.payload,
        TREE: {
          id: action.payload.id,
          name: action.payload.name,
          type: 1,
          industry: action.payload.industries[0],
          createdDate: action.payload.createdDate,
          children: []
        }
      };
    case "SELECT_NODE":
      return {
        ...state,
        SELECTED: {
          TYPE: action.payload.type,
          NODE: action.payload.node
        }
      };
    case "EXPAND_INSTANCE":
      return {
        ...state,
        TREE: action.payload
      };
    case "INDUSTRIES":
      return {
        ...state,
        INDUSTRIES: action.payload
      };
    case "DRAG_NODE":
      return {
        ...state,
        DRAGGING: action.payload,
        STATE: action.payload ? "dragging" : null
      };
    case "DROP_NODE":
      return {
        ...state,
        DROPNODE: action.payload
      };
    case "SEARCH":
      return {
        ...state,
        SEARCH: {
          ...state.SEARCH,
          ...action.payload
        }
      };
    case "SORT":
      return {
        ...state,
        SORT: action.payload
      };
    case "SEARCH_TREE":
      let value;
      if (!action.payload) {
        value = {
          PATH: [],
          ID: null
        };
      } else {
        value = action.payload;
      }
      return {
        ...state,
        SEARCH_TREE: value
      };
    case "ONBACK":
      return {
        ...state,
        ORGANISATION: undefined,
        TREE: undefined
      };
    default:
      return state;
  }
};

const TRContext = createContext({});

function TRProvider({ children }) {
  const [TRSTATE, TRD] = useReducer(reducer, {
    ORGANISATIONS: [],
    ORGANISATION: undefined,
    TREE: undefined,
    SEARCH: {
      NAME: "",
      INDUSTRY: "",
      ARCHIVED: false
    },
    SEARCH_TREE: {
      PATH: [],
      ID: null
    },
    SORT: {
      direction: "asc",
      sortBy: "name"
    },
    SELECTED: {
      TYPE: undefined,
      NODE: undefined
    },
    DRAGGING: null,
    DROPNODE: null,
    STATE: null
  });
  const { TREE } = TRSTATE;

  const [organisations, setOrganisations] = useState([]);
  const [industries, setIndustries] = useState([]);
  const [panelContext] = useState([]);

  useEffect(() => {
    API({
      method: "GET",
      url: `${AREAS_MAIN_API}organisations`,
      callback: ({ response }) =>
        TRD({ type: "SET_ORGS", payload: response.result }),
      reject: ({ response }) => console.log("COULD NOT GET ORGANIZATIONS")
    });
    API({
      method: "GET",
      url: `${AREAS_MAIN_API}lookups/organizations/industries`,
      callback: ({ response }) => setIndustries(response.result),
      reject: ({ response }) => console.log("COULD NOT GET INDUSTRIES")
    });
  }, []);

  const DIALOG = useDialog(DCB);
  const DIALOG_CHILDREN = {
    1: (
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <TextField
            label="Name"
            value={DIALOG.settings.name || ""}
            name="name"
            onChange={DIALOG.onInput}
            variant="outlined"
            fullWidth
            error={DIALOG.valid.includes("name")}
          />
        </Grid>
        <Selector
          id="Industry"
          items={industries}
          onSelect={DIALOG.onInput}
          value={DIALOG.settings.industry}
          itemID="description"
          width={12}
          error={DIALOG.valid.includes("industry")}
        />
      </Grid>
    ),
    2: (
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <TextField
            label="Name"
            value={DIALOG.settings.name || ""}
            name="name"
            onChange={DIALOG.onInput}
            variant="outlined"
            fullWidth
            error={DIALOG.valid.includes("name")}
          />
        </Grid>
        <Selector
          id="Installation Type"
          items={installationTypes}
          onSelect={DIALOG.onInput}
          value={DIALOG.settings.installationtype}
          itemID="name"
          width={12}
          error={DIALOG.valid.includes("installationtype")}
        />
        <Selector
          id="Country"
          items={countries}
          onSelect={DIALOG.onInput}
          value={DIALOG.settings.country}
          width={12}
          error={DIALOG.valid.includes("country")}
        />
      </Grid>
    ),
    3: (
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <TextField
            label="Name"
            value={DIALOG.settings.name || ""}
            name="name"
            onChange={DIALOG.onInput}
            variant="outlined"
            fullWidth
            error={DIALOG.valid.includes("name")}
          />
        </Grid>
      </Grid>
    )
  };
  function DCB({ payload, type }) {
    if (type === 1) {
      TRD({
        type: "SELECT_ORG",
        payload: payload
      });
    }
  }

  const UPDATE_TREE = useCallback(
    (type, data, rowGuid) => {
      if (type === 1) {
        const newNode = {
          areaID: rowGuid.rootAreaId,
          children: [],
          id: rowGuid.instanceId,
          installationTypeGuid: data.InstallationTypeId,
          instanceGuid: rowGuid.instanceId,
          instanceSettings: {
            country: data.CountryId,
            emailDomainWhiteList: [],
            enableUserCreation: false,
            expirationDate: null,
            note: null,
            quotaLE: 0,
            quotaSE: 0,
            userLimit: 0,
            visibility: false
          },
          lastUpdated: null,
          name: data.InstanceName,
          recommendations: null,
          recommendedTraccs: [],
          rootRowGuid: rowGuid.rootAreaId,
          status: 0,
          type: 2
        };

        const newTree = async mappings => {
          const draft = createDraft(mappings);
          draft.children.push(newNode);

          return finishDraft(draft);
        };

        newTree(TRSTATE.TREE).then(payload => {
          TRD({ type: "UPDATE_TREE", payload: payload });

          const found = findInstance({
            nodeID: rowGuid.rootAreaId,
            instances: payload.children
          });

          TRD({
            type: "SELECT_NODE",
            payload: {
              type: 2,
              node: found
            }
          });
        });
      }
      if (type === 2 || type === 3) {
        const newNode = {
          id: rowGuid,
          rowGuid: rowGuid,
          area: {
            areaCategories: [],
            businessCategories: [],
            countryId: undefined,
            dateCreated: formatDate(),
            dateUpdated: null,
            deleted: false,
            id: rowGuid,
            isApplicationSpecific: false,
            licensedEntity: false,
            name: data.areaName,
            parentGuid: data.parentGuid,
            rootID: null,
            rowGuid: rowGuid,
            structuralEntity: false
          },
          children: []
        };

        const newTree = async mappings => {
          const draft = createDraft(mappings);
          let foundNode = await findNode({
            nodeID: data.parentGuid,
            nodes: [draft]
          });

          foundNode.children.push(newNode);

          return finishDraft(draft);
        };

        newTree(TRSTATE.TREE).then(payload => {
          TRD({ type: "UPDATE_TREE", payload: payload });

          // TRD({
          //   type: "SELECT_NODE",
          //   payload: {
          //     type: 3,
          //     node: newNode
          //   }
          // });
        });
      }
    },
    [TRSTATE.TREE]
  );

  const NEW_ORG = () => {
    return new Promise((resolve, reject) => {
      DIALOG.init({
        variant: 1,
        icon: {
          1: <OrgIcon />
        },
        title: {
          1: "CREATE A NEW ORGANISATION",
          2: "SAVING ORGANISATION...",
          3: "SUCCESS SAVING ORGANISATION",
          4: "ERROR SAVING ORGANISATION"
        },
        buttons: {
          confirm: "CREATE",
          cancel: "CANCEL",
          exit: "CONTINUE"
        },
        promise: {
          resolve,
          reject
        },
        settings: {
          name: "",
          industry: ""
        }
      });
    }).then(async ({ value, settings, onNext }) => {
      if (value === "RESOLVE") {
        API({
          method: "POST",
          url: `${AREAS_MAIN_API}organisations`,
          data: {
            name: settings.name,
            industrycodes: [settings.industry.id]
          },
          callback: ({ response }) => {
            const payload = {
              createdDate: formatDate(Date.now()),
              id: response.result,
              industries: [
                {
                  id: settings.industry.id,
                  description: settings.industry.description
                }
              ],
              instances: [],
              isArchive: false,
              lastUpdated: null,
              name: settings.name
            };
            TRD({
              type: "ADD_ORG",
              payload: payload
            });
            onNext({ step: 3, payload, type: 1 });
          },
          reject: () => {
            console.log("reject");
          }
        });
      }
    });
  };

  const ADD_AREA = useCallback(
    (type, nodeID, SELECTED) => {
      let name, variant, settings;

      if (type === 1) {
        name = "INSTANCE";
        variant = 2;
        settings = {
          name: "",
          installationtype: "",
          country: ""
        };
      } else {
        name = "AREA";
        variant = 3;
        settings = {
          name: ""
        };
      }

      return new Promise((resolve, reject) => {
        DIALOG.init({
          variant,
          icon: {
            1: <OrgIcon />
          },
          title: {
            1: "CREATE A NEW " + name,
            2: "SAVING " + name + "...",
            3: "SUCCESS SAVING " + name,
            4: "ERROR SAVING " + name
          },
          buttons: {
            confirm: "CREATE",
            cancel: "CANCEL",
            exit: "CONTINUE"
          },
          promise: {
            resolve,
            reject
          },
          settings
        });
      }).then(async ({ value, settings, onNext }) => {
        let url, data, nodeGuid;

        if (value === "RESOLVE") {
          if (type === 1) {
            url = "instance";
            data = {
              OrganisationId: TREE.id,
              InstanceName: settings.name,
              InstallationTypeId: settings.installationtype.id,
              CountryId: settings.country
            };
          } else {
            url = "root/child";
            if (type === 2) {
              nodeGuid = {
                rootAreaGuid: SELECTED.rootRowGuid,
                parentGuid: SELECTED.rootRowGuid
              };
            }
            if (type === 3) {
              nodeGuid = {
                rootAreaGuid: SELECTED.rootID,
                parentGuid: SELECTED.rowGuid
              };
            }
            data = {
              orgRowGuid: TREE.id,
              areaName: settings.name,
              licensedEntity: true,
              structuralEntity: true,
              ...nodeGuid
            };
          }

          API({
            method: "POST",
            url: `${AREAS_MAIN_API}areas/${url}`,
            data,
            callback: ({ response }) => {
              UPDATE_TREE(type, data, response.result);
              onNext({ step: 3 });
            },
            reject: () => {
              console.log("reject");
            }
          });
        }
      });
    },
    [TREE, UPDATE_TREE]
  );

  /// CREATE TREE ONCE AN ORGANISATION IS SELECTED
  useEffect(() => {
    const ORG = TRSTATE.ORGANISATION;

    if (ORG) {
      const newTree = async mappings => {
        return mappings.instances.reduce(
          async (acc, node) => {
            const accumulator = await acc;

            let instance;

            await API({
              method: "GET",
              url: `${AREAS_MAIN_API}areas/${ORG.id}/${node.rootRowGuid}`,
              callback: ({ response }) => {
                instance = response.result;
              },
              reject: () => {
                console.log("COULD NOT GET INSTANCE");
              }
            });

            console.log(instance);

            return {
              ...accumulator,
              children: [
                ...accumulator.children,
                {
                  name: node.name,
                  id: node.instanceGuid,
                  instanceGuid: node.instanceGuid,
                  areaID: node.rootRowGuid,
                  rootRowGuid: node.rootRowGuid,
                  type: 2,
                  instanceSettings: node.instanceSettings,
                  installationTypeGuid: node.installationTypeGuid,
                  recommendedTraccs: node.recommendedTraccs || [],
                  recommendations: null,
                  status: node.status,
                  lastUpdated: node.lastUpdated,
                  children: instance && instance.areaNode.children
                }
              ]
            };
          },
          {
            id: ORG.id,
            name: ORG.name,
            type: 1,
            industry: ORG.industries[0],
            createdDate: ORG.createdDate,
            children: []
          }
        );
      };

      newTree(ORG).then(data => TRD({ type: "UPDATE_TREE", payload: data }));
    }
  }, [TRSTATE.ORGANISATION]);

  /// FILTER AND SORT
  useEffect(() => {
    if (TRSTATE.ORGANISATIONS) {
      let filters = [];
      const isKeyValue = key => value => object => {
        return object[key].toLowerCase().indexOf(value.toLowerCase()) === 0;
      };
      const isKeyValueArray = key => value => object => {
        return object[key].some(e => e.id === value.id);
      };
      const isKeyTrue = key => value => object => {
        return object[key] === true;
      };
      const filterEvery = predicates => value => {
        return predicates.every(predicate => predicate(value));
      };
      const isName = isKeyValue("name");
      const isIndustry = isKeyValueArray("industries");
      const isArchive = isKeyTrue("isArchive");

      let filteredData = TRSTATE.ORGANISATIONS;
      let sortedData;

      if (TRSTATE.SEARCH) {
        TRSTATE.SEARCH.NAME && filters.push(isName(TRSTATE.SEARCH.NAME));
        TRSTATE.SEARCH.INDUSTRY &&
          filters.push(isIndustry(TRSTATE.SEARCH.INDUSTRY));
        TRSTATE.SEARCH.ARCHIVED &&
          filters.push(isArchive(TRSTATE.SEARCH.ARCHIVED));
        filteredData = TRSTATE.ORGANISATIONS.filter(filterEvery(filters));
      }

      if (TRSTATE.SORT) {
        sortedData = stableSort(
          filteredData,
          getSorting(TRSTATE.SORT.direction, TRSTATE.SORT.sortBy)
        );
      } else {
        sortedData = filteredData;
      }

      setOrganisations(sortedData);
    }
  }, [TRSTATE.ORGANISATIONS, TRSTATE.SEARCH, TRSTATE.SORT]);

  return (
    <TRContext.Provider
      value={{
        TRSTATE,
        TRD,
        organisations,
        industries,
        panelContext
      }}
    >
      <Grid item container spacing={4} style={{ paddingTop: 16 }}>
        <SearchTree />
        <Organisations {...{ NEW_ORG }} />
        {TRSTATE.TREE && (
          <>
            <Tree {...{ ADD_AREA }} />
            <TreePanel />
          </>
        )}
      </Grid>
      {DIALOG.open && (
        <DialogBox {...DIALOG.props}>
          {DIALOG_CHILDREN[DIALOG.variant]}
        </DialogBox>
      )}
    </TRContext.Provider>
  );
}

const useTR = () => {
  const {
    TRSTATE,
    TRD,
    TRACTIONS,
    organisations,
    organisation,
    industries,
    panelContext
  } = useContext(TRContext);
  return {
    TRD,
    TRSTATE,
    TRACTIONS,
    organisations,
    organisation,
    industries,
    panelContext
  };
};

export { TRContext, TRProvider, useTR };

const installationTypes = [
  {
    id: "197d0a0e-2f13-4364-809f-401d94dee246",
    name: "Test"
  },
  {
    id: "2d21c103-5431-45c4-8e9e-d95d1354d23b",
    name: "Production"
  },
  {
    id: "B226919D-B95E-4BDA-A460-8495E77E534A",
    name: "Legacy"
  },
  {
    id: "9589A701-55AA-4A03-9269-8AB50FAEAB57",
    name: "Evaluation"
  },
  {
    id: "FAB3DF46-72DA-459C-A306-AE909C445CC8",
    name: "Demo"
  },
  {
    id: "C08F05FD-4C72-4A62-9EE8-AF88EA98DD90",
    name: "Training"
  },
  {
    id: "5B57E320-4789-4E25-B9D4-FF812A4861EE",
    name: "Site"
  }
];

const countries = ["South Africa", "USA"];
