import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, TextField, FormControlLabel, Checkbox } from "@material-ui/core";
import { Selector } from "Components";
import { useTR } from "./State";

export default function SearchTree() {
  const cx = useStyles();
  const { TRSTATE, TRD, industries } = useTR();

  function onSearch(event) {
    TRD({
      type: "SEARCH",
      payload: {
        ...TRSTATE.SEARCH,
        NAME: event.target.value
      }
    });
  }

  function selectIndustry(event) {
    TRD({
      type: "SEARCH",
      payload: {
        ...TRSTATE.SEARCH,
        INDUSTRY: event.target.value
      }
    });
  }

  function checkArchive(event) {
    TRD({
      type: "SEARCH",
      payload: {
        ...TRSTATE.SEARCH,
        ARCHIVED: event.target.checked
      }
    });
  }

  if (TRSTATE.ORGANISATION) {
    return null;
  }

  return (
    <Grid item container spacing={4} className={cx.root}>
      <Grid item xs={3}>
        <TextField
          value={TRSTATE.SEARCH.NAME}
          label="Search Organisations"
          name="organisation"
          onChange={onSearch}
          placeholder="Seach Organisations"
          variant="outlined"
          fullWidth
        />
      </Grid>
      <Grid item xs={3}>
        <Selector
          id="Industry"
          items={industries}
          onSelect={selectIndustry}
          value={TRSTATE.SEARCH.INDUSTRY}
          itemID="description"
          width={12}
          outlined
          deselect
        />
      </Grid>
      <Grid item xs={3}>
        <FormControlLabel
          control={
            <Checkbox
              checked={TRSTATE.SEARCH.ARCHIVED}
              onChange={checkArchive}
              value="checkedB"
              color="primary"
            />
          }
          label="Show Archived"
          style={{ color: "#979797" }}
          classes={{ label: cx.label }}
        />
      </Grid>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    // margin: "-16px",
    paddingTop: "48px"
  },
  label: {
    color: "#979797"
  }
}));
