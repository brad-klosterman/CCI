import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Node from "./Node";

export default function GhostNode({
  nodeID,
  name,
  xcursor,
  ycursor,
  xstart,
  ystart,
  depth,
  expanded,
  children,
  selected
}) {
  const cx = useStyles();

  if (xstart) {
    let x = xcursor - xstart - window.scrollX;
    let y = ycursor - ystart - window.scrollY;
    let width = "100vw - 128px";

    if (selected) {
      width = "50vw - 144px";
    }

    let dpt;
    if (expanded && children) {
      dpt = depth;
    } else if (expanded && !children) {
      dpt = depth;
    } else {
      dpt = depth;
    }

    return (
      <div
        className={cx.root}
        style={{
          transform: `translate(${x}px, ${y}px)`,
          width: `calc(${width} - ${dpt * 48}px)`
        }}
      >
        <Node name={name} />
      </div>
    );
  } else {
    return null;
  }
}

const useStyles = makeStyles(theme => ({
  root: {
    position: "fixed",
    top: 0,
    left: 0,
    pointerEvents: "none",
    visibility: "visible"
  }
}));
//
// width: `calc(100vw - 128px - ${depth * 48}px)`
// }}
