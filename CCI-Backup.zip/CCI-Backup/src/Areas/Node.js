/* eslint-disable jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions  */
import React, { useEffect, useState, useRef, useCallback, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { Typography, Collapse } from "@material-ui/core";
import ExpandIcon from "@material-ui/icons/ExpandMore";
import CollapseIcon from "@material-ui/icons/ChevronRight";
import { fade } from "@material-ui/core/styles";

function Node({
  type,
  depth,
  name,
  nodeID,
  areaID,
  instanceID,
  parentID,
  rootID,
  children,
  color,
  state,
  SELECT_NODE,
  onDrag,
  onDragOver,
  onDragExit,
  dragNode,
  onAddNode,
  searchNode,
  className
}) {
  const classes = useStyles();
  console.log("UPDATE-NODE");

  const [selected, setSelected] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [expandable, setExpandable] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [overNode, setOverNode] = useState(false);
  const [overExpanded, setOverExpanded] = useState(false);
  const [onParent, setOnParent] = useState(false);
  const [colorID, setColorID] = useState("#DB4065");

  const nodeRef = useRef(null);
  const contentRef = useRef(null);
  // console.log("UPDATE_NODE", name);

  useEffect(() => {
    if (state !== "dragging" || "dropping") {
      setDragging(false);
      setOverNode(false);
    }
  }, [state]);

  useEffect(() => {
    if (dragNode && dragNode.parentID === areaID) {
      setOnParent(true);
    } else {
      setOnParent(false);
    }
  }, [areaID, dragNode]);

  useEffect(() => {
    if (color === "green") {
      setColorID("#23A59C");
    } else if (color === "darkblue") {
      setColorID("#0091FF");
    } else if (color === "lightblue") {
      setColorID("#A7D8FB");
    } else if (color === "red ") {
      setColorID("#DB4065");
    } else {
      setColorID("#DB4065");
    }
  }, [color]);

  useEffect(() => {
    if (children && children.length) {
      setExpandable(true);
    } else if (overExpanded) {
      setExpanded(true);
    } else {
      setExpandable(false);
      setExpanded(false);
    }
  }, [children, overExpanded]);

  useEffect(() => {
    if (searchNode && searchNode.ID) {
      if (expandable && searchNode.PATH.includes(nodeID)) {
        setExpanded(true);
      } else {
        setExpanded(false);
      }
      if (searchNode.ID === nodeID && !selected) {
        setSelected(true);
        SELECT_NODE({ nodeID, rootID, instanceID, type, onDeselect });
      }
    }
  }, [searchNode, nodeID, expandable, selected, rootID, instanceID, type]);

  const handleSelect = event => {
    event.preventDefault();
    event.stopPropagation();
    if (!selected) {
      SELECT_NODE({ nodeID, rootID, instanceID, type, onDeselect });
      setSelected(true);
    }
  };

  const onDeselect = () => {
    console.log("ondeselect");
    setSelected(false);
  };

  function handleExpand(event) {
    event.preventDefault();
    event.stopPropagation();
    if (expandable) {
      setExpanded(prevExpanded => !prevExpanded);
    }
  }

  const handleDrag = useCallback(
    event => {
      event.preventDefault();
      event.stopPropagation();
      setDragging(true);
      onDrag({
        xstart: event.clientX - nodeRef.current.offsetLeft,
        ystart: event.clientY - nodeRef.current.offsetTop,
        xcursor: event.clientX,
        ycursor: event.clientY,
        name,
        nodeID,
        depth,
        parentID,
        rootID
      });
    },
    [depth, name, nodeID, onDrag, parentID, rootID]
  );

  const handleDragOver = useCallback(
    event => {
      event.stopPropagation();
      if (state === "dragging") {
        if (!dragging && !onParent) {
          setOverNode(true);
          onDragOver({
            nodeID,
            depth,
            expanded: true,
            children: Boolean(children)
          });
        }
        setExpanded(true);
      }
    },
    [children, depth, dragging, nodeID, onDragOver, state, onParent]
  );

  const handleDragExit = useCallback(
    event => {
      event.stopPropagation();
      if (state === ("dragging" || "dropping")) {
        setOverNode(false);
        onDragExit();
        if (type === 3 && !overNode) setExpanded(false);
      }
    },
    [state, onDragExit, type, overNode]
  );

  const onOverExpanded = useCallback(
    event => {
      event.stopPropagation();
      if (state === "dragging") {
        setOverExpanded(true);
      }
    },
    [state]
  );

  const onExitExpanded = useCallback(
    event => {
      event.stopPropagation();
      if (state === "dragging") {
        console.log("exit");
        setOverExpanded(false);
        setExpanded(false);
      }
    },
    [state]
  );

  useEffect(() => {
    const elemNode = nodeRef.current;
    const elemContent = contentRef.current;

    // const onFocus = () => setSelected(true);

    if (elemNode && type === 3) {
      elemNode.setAttribute("draggable", true);
      elemNode.addEventListener("dragstart", handleDrag);
    }
    if (elemContent && type === 3) {
      elemContent.addEventListener("mouseenter", handleDragOver);
      elemContent.addEventListener("mouseleave", handleDragExit);
      elemNode.addEventListener("mouseenter", onOverExpanded);
      elemNode.addEventListener("mouseleave", onExitExpanded);
    }
    return () => {
      if (elemNode && type === 3) {
        elemNode.removeEventListener("dragstart", handleDrag);
      }
      if (elemContent) {
        elemContent.removeEventListener("mouseenter", handleDragOver);
        elemContent.removeEventListener("mouseleave", handleDragExit);
        elemNode.removeEventListener("mouseenter", onOverExpanded);
        elemNode.removeEventListener("mouseleave", onExitExpanded);
      }
    };
  }, [
    handleDrag,
    handleDragExit,
    handleDragOver,
    onExitExpanded,
    onOverExpanded,
    type
  ]);

  /// RENDER

  let icon;
  if (expandable) {
    if (!expanded) {
      icon = <CollapseIcon fontSize="small" />;
    } else {
      icon = <ExpandIcon fontSize="small" />;
    }
  } else if (expanded) {
    icon = <ExpandIcon fontSize="small" />;
  }

  const RENDER_DROP = type => {
    let exp;

    if (type === 1) {
      exp = !expanded;
    } else {
      exp = expanded;
    }

    if (overNode && exp && state === ("dragging" || "dropping")) {
      return (
        <div className={classes.cloneContent}>
          <Typography component="div" variant="h6" className={classes.label}>
            DROP NODE HERE
          </Typography>
        </div>
      );
    } else {
      return null;
    }
  };

  return (
    <li
      className={clsx(classes.root, className, {
        [classes.expanded]: expanded,
        [classes.dragging]: dragging
      })}
      role="treeitem"
      aria-expanded={expandable ? expanded : null}
      ref={nodeRef}
    >
      <div
        tabIndex="0"
        className={clsx(classes.content, className, {
          [classes.selected]: selected
        })}
        ref={contentRef}
        onClick={handleSelect}
      >
        <div
          className={classes.typeId}
          style={{ backgroundColor: dragging ? "transparent" : colorID }}
        />
        <Typography component="div" variant="h3" className={classes.label}>
          {name}
        </Typography>
        <div className={classes.iconContainer} onClick={handleExpand}>
          {icon}
        </div>
      </div>
      {RENDER_DROP(1)}

      {expanded && (
        <Collapse
          unmountOnExit
          className={classes.group}
          classes={{ wrapperInner: classes.groupWrapper }}
          in={expanded}
          component="ul"
          role="group"
        >
          {RENDER_DROP(2)}
          {children}
        </Collapse>
      )}
    </li>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    listStyle: "none",
    margin: 0,
    padding: 0,
    outline: 0,
    "&:focus > $content": {
      boxShadow: "0 4px 8px 0 rgba(0,0,0,0.2)"
    },
    marginBottom: 8,
    marginTop: 8
  },

  /* Pseudo-class applied to the root element when expanded. */
  expanded: {},
  dragging: {
    "& $content": {
      backgroundColor: "transparent",
      border: "2px dashed #118acb",
      boxShadow: "none"
      // boxShadow: "inset 0 0 0 2px #118acb"
    },
    "& $typeId": {
      backgroundColor: "transparent",
      width: "3px"
    },
    "& $iconContainer": {
      display: "none"
    }
  },
  /* Styles applied to the `role="group"` element. */
  group: {
    marginTop: 8,
    marginLeft: 24,
    paddingLeft: 24,
    borderLeft: `1px dashed ${fade(theme.palette.text.primary, 0.4)}`,
    "&:last-child": {
      marginBottom: 0
    }
  },
  groupWrapper: {
    "& li:last-child": {
      marginBottom: 0
    }
  },
  /* Styles applied to the tree node content. */
  content: {
    width: "100%",
    height: 40,
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    backgroundColor: "white",
    boxShadow: theme.boxShadow,
    borderRadius: 0,
    marginBottom: 0,
    padding: 0,
    "&:hover": {
      backgroundColor: theme.light[1]
    },
    "&:focus": {
      outline: "0!important"
    }
  },

  selected: {
    boxShadow: "0 2px 4px 0 rgba(0,0,0,0.14)",
    // backgroundColor: "rgba(9,128,188,0.05)"
    backgroundColor: theme.light[0],
    "&:hover": {
      backgroundColor: theme.light[0]
    }
  },
  cloneContent: {
    width: "100%",
    height: 42,
    marginTop: 8,
    paddingLeft: 21,
    display: "flex",
    alignItems: "center",
    borderRadius: 4,
    border: "2px dashed #118acb"
  },
  cloneExpanded: {
    marginLeft: 48
  },
  /* Styles applied to the tree node icon and collapse/expand icon. */
  iconContainer: {
    marginRight: 8,
    width: 24,
    display: "flex",
    justifyContent: "center"
  },
  /* Styles applied to the label element. */
  label: {
    width: "100%",
    fontSize: 12
  },
  typeId: {
    width: 5,
    height: "100%",
    backgroundColor: "#118acb",
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    marginRight: 16
  }
}));

export default memo(Node);
