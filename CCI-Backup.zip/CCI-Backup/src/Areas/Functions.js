import React, { useState, useEffect, useRef, useCallback } from "react";
import axios from "axios";

export function useApi(api) {
  const [hasError, setErrors] = useState(false);
  const [data, setData] = useState([]);

  useEffect(
    () => {
      (async function fetchData() {
        const res = await fetch(api);
        res
          .json()
          .then(res => setData(res.result))
          .catch(err => setErrors(err));
      })();
    },
    [api]
  );

  return {
    data: data,
    errors: hasError
  };
}

export function useTrace(props) {
  const prev = useRef(props);
  useEffect(() => {
    const changedProps = Object.entries(props).reduce((ps, [k, v]) => {
      if (prev.current[k] !== v) {
        ps[k] = [prev.current[k], v];
      }
      return ps;
    }, {});
    if (Object.keys(changedProps).length > 0) {
      console.log("Changed props:", changedProps);
    }
    prev.current = props;
  });
}

export async function getAPI({ API, ID }) {
  try {
    let response = await axios.get(API + ID);
    return response.data.result;
  } catch (error) {
    console.error(error);
  }
}

// export function useSearch({
//   nodeID
// }) {
//
//
//   return {
//     props: {
//       value: val,
//       field,
//       onChange: handleChange,
//       onKeyDown: handleKeyDown,
//       error,
//       helperText: error && erMsg,
//       fullWidth: true
//     },
//     validate: handleValidate
//   };
// }
