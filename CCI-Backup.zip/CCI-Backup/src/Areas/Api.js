export const AREAS_API =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/areas/";

export const ORGS =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/organisations";

export const GET_INDUSTRIES =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/lookups/organizations/industries";

export const LOOKUP_API =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/lookups/";

export const API =
  "https://dev-cciservices.traccsolution.com:19081/Cci.Tracc.AreasService/Cci.Tracc.AreasService.API/";
