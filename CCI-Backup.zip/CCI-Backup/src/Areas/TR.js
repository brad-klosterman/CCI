import React from "react";
import { TRProvider } from "./State";
import Tree from "./Tree";
import TreePanel from "./Panels/TreePanel";
import { Grid } from "@material-ui/core";

export default function TR() {
  return (
    <TRProvider>
      <Grid container spacing={4}>
        <TreePanel />
      </Grid>
    </TRProvider>
  );
}
