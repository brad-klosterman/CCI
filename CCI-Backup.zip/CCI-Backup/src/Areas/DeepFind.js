const deepFindAll = function*(f, o = {}) {
  if (Object(o) === o) {
    if (f(o) === true) yield o;
    for (const [_, v] of Object.entries(o)) yield* deepFindAll(f, v);
  }
};

const contramap = (f, g) => (x, y) => f(g(x), g(y));
const match = (x = "", y = "") => x.includes(y);
const lower = (x = "") => x.toLowerCase();
const caseInsenstiveMatch = contramap(match, lower);

const anyString = f => (o = {}) =>
  Object.values(o).some(v => String(v) === v && f(v));

export const deepFind = (query = "", data = {}) =>
  Array.from(
    deepFindAll(
      anyString(v => caseInsenstiveMatch(v, query)),
      data
    )
  );

export function findNode({ nodeID, nodes }) {
  let foundData = null;
  var found = false;

  function recurse(nodes) {
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i].id === nodeID || nodes[i].areaID === nodeID) {
        found = true;
        foundData = nodes[i];
        break;
      } else if (nodes[i].area && nodes[i].area.rowGuid === nodeID) {
        found = true;
        foundData = nodes[i];
        break;
      } else {
        if (nodes[i].children) {
          recurse(nodes[i].children);
          if (found) {
            break;
          }
        }
      }
    }
  }
  recurse(nodes);

  return foundData;
}

export function findAllNodes(q, nodes) {
  let foundData = [];
  let query = q.toLowerCase();

  function recurse({ nodes, path }) {
    for (let i = 0; i < nodes.length; i++) {
      let nPath = [...path];
      if (nodes[i].areaID) {
        nPath.push(nodes[i].areaID);
        if (nodes[i].name.toLowerCase().includes(query)) {
          const foundPath = nPath.slice(0, -1);
          foundData.push({ ID: nodes[i].areaID, PATH: foundPath });
        }
      } else if (nodes[i].rowGuid) {
        nPath.push(nodes[i].rowGuid);
        if (nodes[i].area && nodes[i].area.name.toLowerCase().includes(query)) {
          const foundPath = nPath.slice(0, -1);
          foundData.push({ ID: nodes[i].rowGuid, PATH: foundPath });
        }
      }
      if (nodes[i].children) {
        recurse({ nodes: nodes[i].children, path: nPath });
      }
    }
  }
  recurse({ nodes, path: [] });
  console.log(foundData);

  return foundData;
}

// function traverse(branch) {
//     var result;
//     for (var i = 0; i < branch.length; i++) {
//         if (branch[i].id === node.id) {
//             return branch;
//         }
//         if (branch[j].children.length > 0) {
//             result = traverse(branch[j].children);
//             if (result) {
//                 return result;
//             }
//         }
//     }
// }
