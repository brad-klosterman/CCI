import React, { useState, createRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { Grid, Typography, InputBase, IconButton } from "@material-ui/core";
import DeleteIcon from "@material-ui/icons/Delete";
import AddIcon from "@material-ui/icons/AddBox";
import CreateIcon from "@material-ui/icons/Create";

function InstanceDomains({ domains, addDomain, deleteDomain }) {
  const cx = useStyles();

  let textInput = createRef();
  const [inputValue, setInputValue] = useState("");
  const [inputFocused, setInputFocused] = useState(false);

  function onAction() {
    if (inputFocused) {
      addDomain(inputValue);
      setInputValue("");
    } else {
      textInput.current.focus();
    }
    setInputFocused(prevInputFocused => !prevInputFocused);
  }

  function onInput(event) {
    setInputValue(event.target.value);
  }

  const inputActions = !inputFocused ? (
    <>
      <Typography variant="h3" color="primary" style={{ paddingRight: 8 }}>
        Add Domain
      </Typography>
      <CreateIcon color="primary" fontSize="small" />
    </>
  ) : (
    <AddIcon color="primary" fontSize="small" />
  );

  const inputBar = (
    <div className={cx.inputBar}>
      <InputBase
        inputRef={textInput}
        classes={{
          root: cx.inputBase,
          input: clsx(cx.input, {
            [cx.inputFocused]: inputFocused
          })
        }}
        placeholder="Domain Name"
        inputProps={{ "aria-label": "domain name" }}
        value={inputValue}
        onChange={onInput}
      />

      <IconButton
        onClick={onAction}
        className={clsx(cx.inputIcon, {
          [cx.iconFocused]: inputFocused
        })}
        disableRipple
      >
        {inputActions}
      </IconButton>
    </div>
  );

  return (
    <Grid container spacing={4}>
      <Grid item xs={12} className={cx.header}>
        <Typography variant="h3" className={cx.tlt}>
          Email Domains
        </Typography>
        {inputBar}
      </Grid>
      <Grid item xs={12}>
        {domains &&
          domains.map((domain, idx) => (
            <div className={cx.row} key={domain + idx}>
              <Typography variant="body2" className={cx.title}>
                {domain}
              </Typography>
              <DeleteIcon
                className={cx.deleteIcon}
                fontSize="small"
                color="secondary"
                onClick={() => deleteDomain(idx)}
              />
            </div>
          ))}
      </Grid>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  header: {
    display: "flex",
    alignItems: "center"
  },
  tlt: {
    width: "100%"
  },
  row: {
    width: "100%",
    display: "flex",
    padding: "8px 0px",
    borderColor: theme.grey[0],
    borderBottom: `1px solid ${theme.grey[0]}`,
    "&:first-child": {
      borderTop: `1px solid ${theme.grey[0]}`
    }
  },
  deleteIcon: {
    cursor: "pointer",
    "&:hover": {
      color: "#DB4065"
    }
  },
  title: { width: "100%" },
  create: {
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: "transparent",
    "&:hover": {
      // backgroundColor: fade(theme.palette.common.white, 0.25)
    },
    marginLeft: 0,
    marginRight: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(1),
      width: "auto",
      minWidth: 144
    }
  },

  inputBar: {
    display: "flex",
    alignItems: "center",
    position: "relative"
  },
  inputBase: {
    width: "100%",
    minWidth: 144
  },
  input: {
    width: 0,
    border: "1px solid",
    borderColor: "transparent",
    transition: theme.transitions.create("width"),
    padding: "2px 8px",
    right: 0
  },
  inputFocused: {
    width: 200,
    borderColor: theme.grey[1]
  },
  inputIcon: {
    position: "absolute",
    right: 0,
    paddingRight: 0,
    transition: theme.transitions.create(),
    fontSize: 12
  },
  iconFocused: {
    right: 8
  }
}));

export default InstanceDomains;
