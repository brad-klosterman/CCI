import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Tab, Tabs, Button } from "@material-ui/core";
import { API, AREAS_MAIN_API, AREAS_API } from "Api";
import axios from "axios";
import { createDraft, finishDraft } from "immer";
import { SaveButton } from "Components";
import InstanceSettings from "./InstanceSettings";
import InstanceDomains from "./InstanceDomains";
import InstanceCategories from "./InstanceCategories";
import { useTR } from "../State";
import { findNode } from "../DeepFind";

function InstancePanel({
  categories,
  UPDATE_NODE,
  UPDATE_DOMAINS,
  updateSubscription,
  loadingAPI
}) {
  const cx = useStyles();
  const { TRSTATE, TRD } = useTR();
  let context = TRSTATE.SELECTED.NODE;
  /// STATE
  const [tab, setTab] = useState(0);
  const [settings, setSettings] = useState();
  const [domains, setDomains] = useState([]);
  const [category, setCategory] = useState();
  const [subscriptions, setSubscriptions] = useState();
  const [initTraccs, setInitTraccs] = useState([]);
  const [traccs, setTraccs] = useState([]);

  useEffect(() => {
    setSettings({
      instanceName: context.name,
      installationTypeId: context.installationTypeGuid,
      country: context.instanceSettings.country,
      note: context.instanceSettings.note || "",
      quotaLE: context.instanceSettings.quotaLE,
      quotaSE: context.instanceSettings.quotaSE,
      userLimit: context.instanceSettings.userLimit,
      expirationDate: context.instanceSettings.expirationDate,
      allowUserCreate: context.instanceSettings.enableUserCreation,
      isVisible: context.instanceSettings.visibility,
      status: ["Pending", "Active", "About to Expire", "Expired", "No Status"][
        context.status
      ]
    });
    setDomains(context.instanceSettings.emailDomainWhiteList);
  }, [context]);

  useEffect(() => {
    API({
      method: "GET",
      url: `${AREAS_MAIN_API}lookups/subscriptions/${TRSTATE.SELECTED.NODE.rootRowGuid}`,
      callback: ({ response }) => setSubscriptions(response.result),
      reject: ({ response }) => console.log("COULD NOT GET SUBSCRIPTIONS")
    });
  }, [TRSTATE.SELECTED]);

  const onEdit = payload => setSettings({ ...settings, ...payload });

  useEffect(() => {
    if (context.hasOwnProperty("cTraccs")) {
      setTraccs(context.cTraccs);
      setInitTraccs(context.cTraccs);
    } else if (category && category.id) {
      const catTraccs = context.recommendedTraccs.filter(
        i => i["categoryId"] === category.id
      );
      const initTraccs = subscriptions.reduce((acc, obj) => {
        catTraccs.forEach(ctracc => {
          if (obj["traccId"] === ctracc["traccId"]) {
            acc.push({ ...obj, recommendationId: ctracc["recommendationId"] });
          }
        });

        return [...acc];
      }, []);

      setTraccs(initTraccs);
      setInitTraccs(initTraccs);
    }
  }, [context, category, subscriptions]);

  const updateGS = async (treeMap, nodeID, payload) => {
    const draft = createDraft(treeMap);
    let foundNode = await findNode({
      nodeID: nodeID,
      nodes: [draft]
    });
    foundNode.cTraccs = payload;
    const updatedTree = await finishDraft(draft);
    TRD({ type: "UPDATE_TREE", payload: updatedTree });
  };

  function deleteDomain(idx) {
    const newDomains = [...domains];
    const removedDomain = newDomains.splice(idx, 1);
    setDomains(newDomains);
    UPDATE_DOMAINS("delete", ...removedDomain);
  }

  function addDomain(value) {
    setDomains([...domains, value]);
    UPDATE_DOMAINS("post", value);
  }

  function onCancel() {
    console.log("cancel");
  }

  const UPDATE_TRACCS = () => {
    function compare() {
      const added = traccs.reduce((acc, tr) => {
        const matched = initTraccs.some(i => tr["traccId"] === i["traccId"]);
        if (matched) {
          return acc;
        }
        return [
          ...acc,
          {
            traccId: tr.traccId,
            categoryId: category.id
          }
        ];
      }, []);

      const removed = initTraccs.reduce((acc, inTr) => {
        const matched = traccs.some(tr => inTr["traccId"] === tr["traccId"]);
        if (matched) {
          return acc;
        }
        return [...acc, inTr.recommendationId];
      }, []);

      return {
        added,
        removed
      };
    }
    function update({ method, data }) {
      // updateGS(TRSTATE.TREE, TRSTATE.SELECTED.NODE.rootRowGuid, updatedAdded);

      // traccs.reduce((acc, tr) => {
      //     if (!tr.hasOwnProperty("recommendationId")) {
      //       const recId = addedResult.data.result.find(
      //         i => i.traccId === tr.traccId
      //       );
      //       return [
      //         ...acc,
      //         {
      //           ...tr,
      //           recommendationId: recId.recommendationId
      //         }
      //       ];
      //     }
      //     return [...acc, tr];
      //   }, []);
      //   setTraccs(updatedAdded);
      //   setInitTraccs(updatedAdded);
      // }

      function updateState(method, value) {
        console.log({ method, value });
      }

      API({
        method,
        url: `${AREAS_MAIN_API}recommendations/${TRSTATE.TREE.id}/${TRSTATE.SELECTED.NODE.instanceGuid}`,
        data,
        callback: ({ response }) => updateState(method, response.result),
        reject: ({ response }) => console.log("COULD NOT GET SUBSCRIPTIONS")
      });
    }

    const { added, removed } = compare();

    if (added) {
      update({ method: "POST", data: added });
    }
    if (removed) {
      update({ method: "DELETE", data: removed });
    }
  };

  const SELECT_CATEGORY = event => {
    setCategory(event.target.value);
  };

  const SELECT_TRACCS = ({ newChecked }) => {
    setTraccs(newChecked);
  };

  const subscriptionDate = value => {
    (async () => {
      axios({
        method: "post",
        url: AREAS_API + "instance/subscription",
        data: {
          OrganizationId: TRSTATE.TREE.id,
          InstanceGuid: TRSTATE.SELECTED.NODE.instanceGuid,
          SubscriptionExpireDate: value
        }
      })
        .then(function(response) {
          setSettings({ ...settings, expirationDate: value, status: "Active" });
        })
        .catch(function(error) {});
    })();
  };

  const onSend = () => {
    UPDATE_NODE({
      type: 2,
      payload: {
        organizationId: TRSTATE.TREE.id,
        instanceGuid: TRSTATE.SELECTED.NODE.instanceGuid,
        rootAreaId: TRSTATE.SELECTED.NODE.rootRowGuid,
        ...settings
      }
    });
    if (tab === 2) {
      UPDATE_TRACCS();
    }
  };

  const RENDER_TAB = {
    0: <InstanceSettings {...{ settings, onEdit, subscriptionDate }} />,
    1: <InstanceDomains {...{ domains, addDomain, deleteDomain }} />,
    2: (
      <InstanceCategories
        {...{
          category,
          categories,
          subscriptions,
          traccs,
          SELECT_CATEGORY,
          SELECT_TRACCS
        }}
      />
    ),
    3: "<SecuritySettings/>"
  };

  return (
    <>
      <div className={cx.tabWrapper}>
        <Tabs
          value={tab}
          onChange={(e, val) => setTab(val)}
          className={cx.tabs}
        >
          {["SETTINGS", "DOMAINS", "CATEGORIES", "SECURITY"].map(tab => (
            <Tab
              key={tab}
              label={tab}
              autoFocus
              classes={{ root: cx.tab, selected: cx.selected }}
            />
          ))}
        </Tabs>
      </div>
      <div className={cx.contentWrapper}>
        <div className={cx.content}>{RENDER_TAB[tab]}</div>
      </div>
      <div className={cx.actions}>
        <SaveButton onClick={onSend} classes={cx.btn} {...{ loadingAPI }} />
        <Button
          onClick={onCancel}
          className={cx.btn}
          variant="outlined"
          color="primary"
          disabled={loadingAPI}
        >
          CANCEL
        </Button>
      </div>
    </>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    flexDirection: "column",
    flexWrap: "nowrap"
  },
  title: {
    paddingBottom: "24px"
  },
  tabWrapper: {
    width: "100%",
    paddingBottom: 24
  },
  contentWrapper: {
    width: "100%",
    flexGrow: 1,
    overflow: "scroll",
    border: "1px solid",
    borderRadius: 3,
    borderColor: theme.grey[0]
  },
  actions: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    paddingTop: 24
  },
  tabs: {
    marginBottom: 0,
    borderRadius: 0,
    // border: "1px solid rgba(93, 93, 94, 0.2)",
    minHeight: 44,
    "& button:last-child": {
      borderRight: 0
    }
    // borderTopLeftRadius: 4,
    // borderTopRightRadius: 4
  },
  tab: {
    fontSize: 12,
    // fontWeight: "bold",
    minWidth: "25%",
    borderRight: "1px solid rgba(93, 93, 94, 0.1)",
    minHeight: 44
    // borderRadius: 4
  },
  selected: {
    color: "white",
    backgroundColor: theme.palette.primary.main,
    borderColor: theme.palette.primary.main
  },

  content: {
    padding: "16px 32px"
  },
  btn: {
    margin: "0px 4px"
  }
}));

export default InstancePanel;

// function updateTraccs() {
//   (async () => {
//     try {
//       const comparedList = await compareTraccs();
//       const addedList = comparedList.added;
//       const removedList = comparedList.removed;
//       let updatedAdded = traccs;
//
//       if (addedList) {
//         const addedResult = await traccApi("post", comparedList.added);
//         updatedAdded = traccs.reduce((acc, tr) => {
//           if (!tr.hasOwnProperty("recommendationId")) {
//             const recId = addedResult.data.result.find(
//               i => i.traccId === tr.traccId
//             );
//             return [
//               ...acc,
//               {
//                 ...tr,
//                 recommendationId: recId.recommendationId
//               }
//             ];
//           }
//           return [...acc, tr];
//         }, []);
//         setTraccs(updatedAdded);
//         setInitTraccs(updatedAdded);
//       }
//
//       if (removedList) {
//         traccApi("delete", comparedList.removed);
//       }
//       updateGS(TRSTATE.TREE, TRSTATE.SELECTED.NODE.rootRowGuid, updatedAdded);
//     } catch (err) {
//       console.log(err);
//     }
//   })();
// }
