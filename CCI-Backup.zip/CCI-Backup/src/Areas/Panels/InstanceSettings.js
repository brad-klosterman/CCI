import React, { useState, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  TextField,
  Grid,
  FormControlLabel,
  FormGroup,
  Typography
} from "@material-ui/core";
import { CSwitch } from "Components/Switch";
import { Selector } from "Components";
import "date-fns";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from "@material-ui/pickers";

const InstanceSettings = memo(({ settings, onEdit, subscriptionDate }) => {
  const cx = useStyles();

  const [state, setState] = useState({
    fiscalMonth: undefined,
    assessmentPeriod: undefined,
    payload: []
  });

  if (!settings) {
    return null;
  }

  const handleSettings = name => event => {
    let value = event.target.value;

    if (name === "installationTypeId") {
      value = value.id;
    }
    onEdit({ [name]: value });
  };

  const handleSwitchSettings = name => event => {
    onEdit({ [name]: event.target.checked });
  };

  const handleDateSettings = name => event => {
    onEdit({ [name]: event });
    subscriptionDate(event);
  };

  const GOVERN = name => event => {
    let fiscalMonth = state.fiscalMonth;
    let month = state.fiscalMonth ? state.fiscalMonth.key : undefined;
    let period = state.assessmentPeriod;
    const payload = [];

    if (name === "fiscalMonth") {
      fiscalMonth = event.target.value;
      month = event.target.value.key;
    }

    if (name === "assessmentPeriod") {
      period = event.target.value;
    }

    if (month && period) {
      const rows = 12 / period;
      (async () => {
        for (let step = 0; step < rows; step++) {
          let endMonth = month + period - 1;

          if (endMonth > 12) {
            endMonth -= 12;
          }
          payload.push({
            StartMonth: year[month],
            EndMonth: year[endMonth]
          });

          if (month + period > 12) {
            month = month + period - 12;
          } else {
            month += period;
          }
        }
      })();
    }

    setState({
      fiscalMonth,
      assessmentPeriod: period,
      payload
    });
  };

  const RENDER_GOV = (
    <Grid item xs={6}>
      {state.payload.map(({ StartMonth, EndMonth }, idx) => {
        return (
          <div key={idx} className={cx.govRow}>
            <div className={cx.govCount}>{idx + 1}</div>
            {"1 " +
              StartMonth.name +
              " - " +
              EndMonth.days +
              " " +
              EndMonth.name}
          </div>
        );
      })}
    </Grid>
  );

  function iType(id) {
    // console.log(id);
    const type = installationTypes.find(i => i.id === id);

    return type ? type.name : id;

    // console.log(installationTypes.find(i => i.id === id))
    //   .name
  }

  return (
    <Grid item container spacing={4}>
      <Grid item xs={12}>
        <TextField
          id="instance-name"
          label="Instance Name"
          variant="outlined"
          value={settings.instanceName}
          onChange={handleSettings("instanceName")}
          fullWidth
        />
      </Grid>
      <Grid item xs={6}>
        <Selector
          id="Installation Type"
          items={installationTypes}
          itemID="name"
          value={iType(settings.installationTypeId)}
          onSelect={handleSettings("installationTypeId")}
          outlined
        />
      </Grid>
      <Grid item xs={6}>
        <Selector
          id="Country"
          items={countries}
          value={settings.country}
          onSelect={handleSettings("country")}
          outlined
        />
      </Grid>
      <Grid item xs={12}>
        <TextField
          label="Notes"
          multiline
          rows="2"
          value={settings.note}
          onChange={handleSettings("note")}
          variant="outlined"
          fullWidth
          className={cx.textField}
        />
      </Grid>
      <Grid item xs={6}>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardDatePicker
            fullWidth
            inputVariant="outlined"
            label="Expiration"
            value={settings.expirationDate || undefined}
            onChange={handleDateSettings("expirationDate")}
            KeyboardButtonProps={{
              "aria-label": "change date",
              classes: { root: cx.dateIcon }
            }}
          />
        </MuiPickersUtilsProvider>
      </Grid>

      <Grid item xs={6}>
        <TextField
          id="status"
          label="Status"
          value={settings.status}
          variant="outlined"
          fullWidth
        />
      </Grid>
      <Grid item xs={4}>
        <TextField
          id="quotaLE"
          label="LE Quota"
          value={settings.quotaLE}
          onChange={handleSettings("quotaLE")}
          type="number"
          InputProps={{
            classes: { input: cx.textFieldNum }
          }}
          variant="outlined"
          fullWidth
        />
      </Grid>
      <Grid item xs={4}>
        <TextField
          id="quotaSE"
          label="SE Quota"
          value={settings.quotaSE}
          onChange={handleSettings("quotaSE")}
          type="number"
          InputProps={{
            classes: { input: cx.textFieldNum }
          }}
          variant="outlined"
          fullWidth
        />
      </Grid>
      <Grid item xs={4}>
        <TextField
          id="userLimit"
          label="User Limit"
          value={settings.userLimit}
          onChange={handleSettings("userLimit")}
          type="number"
          InputProps={{
            classes: { input: cx.textFieldNum }
          }}
          variant="outlined"
          fullWidth
        />
      </Grid>

      <Grid item xs={6}>
        <FormGroup>
          <FormControlLabel
            classes={{ root: cx.switch, label: cx.switchLabel }}
            control={
              <CSwitch
                checked={settings.allowUserCreate}
                onChange={handleSwitchSettings("allowUserCreate")}
                value="allowUserCreate"
              />
            }
            labelplacment="start"
            label="Allow User Creation"
          />
          <FormControlLabel
            classes={{ root: cx.switch, label: cx.switchLabel }}
            control={
              <CSwitch
                checked={settings.isVisible}
                onChange={handleSwitchSettings("isVisible")}
                value="isVisible"
              />
            }
            labelplacment="start"
            label="Visible to Clients"
          />
        </FormGroup>
      </Grid>
      <Grid item xs={12}>
        <Typography variant="h6">Governance</Typography>
      </Grid>
      <Grid item xs={12}>
        <FormControlLabel
          classes={{ root: cx.switch, label: cx.switchLabel }}
          control={
            <CSwitch
              checked={settings.IsVisible}
              onChange={handleSwitchSettings("governamace")}
              value="governance"
            />
          }
          labelplacment="start"
          label="Enable Governance"
        />
      </Grid>
      <Grid item xs={6}>
        <Selector
          id="Fiscal Month"
          items={year}
          itemID="name"
          value={state.fiscalMonth ? state.fiscalMonth.name : ""}
          onSelect={GOVERN("fiscalMonth")}
          outlined
        />
      </Grid>
      <Grid item xs={6}>
        <Selector
          id="Assessment Period"
          items={[3, 6, 12]}
          value={state.assessmentPeriod || ""}
          onSelect={GOVERN("assessmentPeriod")}
          outlined
        />
      </Grid>
      {RENDER_GOV}
      <Grid item xs={12}>
        <Typography variant="h6">Feedback Settings</Typography>
      </Grid>
    </Grid>
  );
});

const useStyles = makeStyles(theme => ({
  switch: {
    marginLeft: 0
  },
  switchLabel: {
    paddingLeft: 12,
    fontSize: 12
  },
  textField: {
    margin: 0
  },
  textFieldNum: {
    paddingRight: 8
  },
  dateIcon: {
    paddingRight: 0
  },
  govRow: {
    display: "flex",
    alignItems: "center",
    marginBottom: 8,
    fontWeight: "bold",
    color: "rgba(0,0,0,0.25)"
  },
  govCount: {
    backgroundColor: "rgba(0,0,0,0.25)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "white",
    width: 24,
    height: 24,
    borderRadius: "50%",
    marginRight: 8
  }
}));

export default InstanceSettings;

const installationTypes = [
  {
    id: "C08F05FD-4C72-4A62-9EE8-AF88EA98DD90",
    name: "Training"
  },
  {
    id: "5B57E320-4789-4E25-B9D4-FF812A4861EE",
    name: "Site"
  },
  {
    id: "2d21c103-5431-45c4-8e9e-d95d1354d23b",
    name: "Production"
  },
  {
    id: "9589A701-55AA-4A03-9269-8AB50FAEAB57",
    name: "Evaluation"
  },
  {
    id: "B226919D-B95E-4BDA-A460-8495E77E534A",
    name: "Legacy"
  },
  {
    id: "197d0a0e-2f13-4364-809f-401d94dee246",
    name: "Test"
  },
  {
    id: "FAB3DF46-72DA-459C-A306-AE909C445CC8",
    name: "Demo"
  }
];

const countries = ["USA", "China", "South Africa"];

// const year = [
//   {
//     name: "January",
//     days: 31
//   },
//   {
//     name: "February",
//     days: 30
//   },
//   {
//     name: "March",
//     days: 31
//   },
//   {
//     name: "April",
//     days: 30
//   },
//   {
//     name: "May",
//     days: 31
//   },
//   {
//     name: "June",
//     days: 30
//   },
//   {
//     name: "July",
//     days: 31
//   },
//   {
//     name: "August",
//     days: 31
//   },
//   {
//     name: "September",
//     days: 30
//   },
//   {
//     name: "October",
//     days: 31
//   },
//   {
//     name: "November",
//     days: 30
//   },
//   {
//     name: "December",
//     days: 31
//   }
// ];

const year = {
  1: {
    key: 1,
    name: "January",
    days: 31
  },
  2: {
    key: 2,
    name: "February",
    days: 30
  },
  3: {
    key: 3,
    name: "March",
    days: 31
  },
  4: {
    key: 4,
    name: "April",
    days: 30
  },
  5: {
    key: 5,
    name: "May",
    days: 31
  },
  6: {
    key: 6,
    name: "June",
    days: 30
  },
  7: {
    key: 7,
    name: "July",
    days: 31
  },
  8: {
    key: 8,
    name: "August",
    days: 31
  },
  9: {
    key: 9,
    name: "September",
    days: 30
  },
  10: {
    key: 10,
    name: "October",
    days: 31
  },
  11: {
    key: 11,
    name: "November",
    days: 30
  },
  12: {
    key: 12,
    name: "December",
    days: 31
  }
};
