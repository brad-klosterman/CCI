import React from "react";
import { Grid, TextField } from "@material-ui/core";

function AreaNotes({ notes, onEdit }) {
  const handleSettings = name => event => {
    onEdit({ [name]: event.target.value });
  };

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <TextField
          label="Notes"
          multiline
          rows="6"
          value={notes}
          onChange={handleSettings("note")}
          variant="outlined"
          fullWidth
        />
      </Grid>
    </Grid>
  );
}

export default AreaNotes;
