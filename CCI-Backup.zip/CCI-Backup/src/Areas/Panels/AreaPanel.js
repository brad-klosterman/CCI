import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Tab, Tabs, Button } from "@material-ui/core";
import { SaveButton } from "Components";
import AreaDetails from "./AreaDetails";
import AreaNotes from "./AreaNotes";
import { useTR } from "../State";

function AreaPanel({
  UPDATE_NODE,
  GET_REC,
  recommendations,
  categoriesAPI,
  loadingAPI
}) {
  const cx = useStyles();
  /// STATE
  const { TRSTATE } = useTR();
  const [tab, setTab] = useState(0);
  const [settings, setSettings] = useState();
  const [categories, setCategories] = useState({});

  useEffect(() => {
    setSettings({
      areaName: TRSTATE.SELECTED.NODE.area.name,
      licensedEntity: TRSTATE.SELECTED.NODE.area.licensedEntity,
      structuralEntity: TRSTATE.SELECTED.NODE.area.structuralEntity,
      dateCreated: TRSTATE.SELECTED.NODE.area.dateCreated,
      countryId: TRSTATE.SELECTED.NODE.area.countryId,
      administrator: "",
      note: TRSTATE.SELECTED.NODE.area.note || ""
    });
    setCategories({});
  }, [TRSTATE.SELECTED]);

  useEffect(() => {
    if (!recommendations) {
      GET_REC(TRSTATE.SELECTED.NODE.instanceID);
    }
  }, [GET_REC, TRSTATE.SELECTED, recommendations]);

  function changeTab(event, newValue) {
    setTab(newValue);
  }

  function onEdit(payload) {
    setSettings({ ...settings, ...payload });
  }
  function onEditCat(payload) {
    setCategories({ ...categories, ...payload });
  }

  function onSendAPI() {
    let payload = { ...settings };

    delete payload.dateCreated;
    delete payload.administrator;

    UPDATE_NODE({
      type: 3,
      payload: {
        ...payload,
        orgRowGuid: TRSTATE.ORGANISATION.id,
        parentGuid: TRSTATE.SELECTED.NODE.area.rowGuid,
        rootAreaGuid: TRSTATE.SELECTED.NODE.rootID
      }
    });

    if (Object.keys(categories).length) {
      const catMap = Object.keys(categories).reduce(
        (acc, node) => {
          if (categories[node] === true) {
            return {
              ...acc,
              categories: [
                ...acc.categories,
                {
                  workingAreaId: TRSTATE.SELECTED.NODE.rowGuid,
                  categoryId: node
                }
              ]
            };
          }

          return acc;
        },
        {
          organizationId: TRSTATE.ORGANISATION.id,
          rootId: TRSTATE.SELECTED.NODE.rootID,
          categories: []
        }
      );
      categoriesAPI(catMap);
    }
  }

  function onCancel() {
    console.log("cancel");
  }
  return (
    <>
      <div className={cx.tabWrapper}>
        <Tabs value={tab} onChange={changeTab} className={cx.tabs}>
          <Tab
            label="AREA DETAILS"
            autoFocus
            classes={{ root: cx.tab, selected: cx.selected }}
          />
          <Tab
            label="AREA NOTES"
            classes={{ root: cx.tab, selected: cx.selected }}
          />
        </Tabs>
      </div>
      <div className={cx.contentWrapper}>
        <div className={cx.content}>
          {tab === 0 && (
            <AreaDetails
              settings={settings}
              categories={categories}
              recommendations={recommendations}
              onEdit={onEdit}
              onEditCat={onEditCat}
            />
          )}
          {tab === 1 && <AreaNotes onEdit={onEdit} notes={settings.note} />}
        </div>
      </div>
      <div className={cx.actions}>
        <SaveButton onClick={onSendAPI} classes={cx.btn} {...{ loadingAPI }} />

        <Button
          onClick={onCancel}
          className={cx.btn}
          variant="outlined"
          color="primary"
        >
          CANCEL
        </Button>
      </div>
    </>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    padding: "0px 16px!important"
  },
  tabWrapper: {
    width: "100%",
    paddingBottom: 24
  },
  contentWrapper: {
    width: "100%",
    flexGrow: 1,
    overflow: "scroll",
    border: "1px solid",
    borderRadius: 3,
    borderColor: theme.grey[0]
  },
  content: {
    padding: "24px 32px"
  },

  tabs: {
    marginBottom: 0,
    borderRadius: 0,
    // border: "1px solid rgba(93, 93, 94, 0.2)",
    minHeight: 44,
    "& button:last-child": {
      borderRight: 0
    }
    // borderTopLeftRadius: 4,
    // borderTopRightRadius: 4
  },
  tab: {
    fontSize: 12,
    // fontWeight: "bold",
    minWidth: "50%",
    borderRight: "1px solid rgba(93, 93, 94, 0.1)",
    minHeight: 44
    // borderRadius: 4
  },
  selected: {
    color: "white",
    backgroundColor: theme.palette.primary.main,
    borderColor: theme.palette.primary.main
  },
  actions: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    paddingTop: 24
  },
  btn: {
    margin: "0px 4px"
  }
}));

export default AreaPanel;
