import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Typography } from "@material-ui/core";
import { Selector } from "Components";
import { SelectList } from "Components/Selects/SelectList";

function InstanceCategories({
  categories,
  category,
  subscriptions,
  traccs,
  SELECT_CATEGORY,
  SELECT_TRACCS
}) {
  const cx = useStyles();

  if (!subscriptions) {
    return (
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <Typography variant="caption" className={cx.tlt}>
            ...Loading Subscriptions
          </Typography>
        </Grid>
      </Grid>
    );
  }

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <Selector
          id="Select A Category"
          items={categories}
          value={category}
          itemID="name"
          onSelect={SELECT_CATEGORY}
          outlined
        />
      </Grid>
      {category && subscriptions && (
        <>
          <Grid item xs={12}>
            <Typography variant="h3" className={cx.tlt}>
              Recommended Traccs
            </Typography>
            {traccs &&
              traccs.map((tracc, idx) => (
                <div className={cx.traccRow} key={tracc.traccId}>
                  {tracc.name}
                </div>
              ))}
          </Grid>
          <Grid item xs={12}>
            <SelectList
              id="Add TRACCS"
              items={subscriptions}
              checked={traccs}
              nameID="name"
              onSelect={SELECT_TRACCS}
              outlined
            />
          </Grid>
        </>
      )}
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({}));

export default InstanceCategories;
