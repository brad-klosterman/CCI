import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid } from "@material-ui/core";
import axios from "axios";
import { createDraft, finishDraft } from "immer";
import { useTR } from "../State";
import { useDash } from "state";
import { API, AREAS_MAIN_API, AREAS_ORGS, AREAS_API, useAPI } from "Api";

import { findNode } from "../DeepFind";

import OrgPanel from "./OrgPanel";
import InstancePanel from "./InstancePanel";
import AreaPanel from "./AreaPanel";

export default function TreePanel() {
  const cx = useStyles();
  const {
    DACTIONS: { openNotification }
  } = useDash();
  const { TRD, TRSTATE, industries } = useTR();
  const TREE = TRSTATE.TREE;
  const SELECTED = TRSTATE.SELECTED.NODE;
  const [categories, setCategories] = useState();
  const [recommendations, setRecommendations] = useState({});
  const [settings, setSettings] = useState();

  const { sendAPI, loadingAPI } = useAPI({
    SUCCESS: response =>
      openNotification({ variant: "success", message: "SUCCESS SAVING" }),
    ERROR: response =>
      openNotification({ variant: "error", message: "ERROR SAVING" })
  });

  useEffect(() => {
    if (TREE) {
      setSettings({
        name: TREE.name || "",
        industryCodes: TREE.industry || "",
        createdDate: TREE.createdDate
      });
    }
  }, [TREE]);

  useEffect(() => {
    API({
      method: "GET",
      url: `${AREAS_MAIN_API}lookups/categories/areas`,
      callback: ({ response }) => setCategories(response.result),
      reject: ({ response }) => console.log("COULD NOT GET CATEGORIES")
    });
  }, []);

  if (!settings) {
    return null;
  }

  const onSettings = name => event => {
    const value = event.target.value;
    setSettings(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const UPDATE_RESPONSE = ({ type, payload, response }) => {
    const UPDATE = {
      1: () =>
        TRD({
          type: "UPDATE_TREE",
          payload: {
            ...TREE,
            name: settings.name,
            industry: settings.industryCodes
          }
        }),
      2: () => updateTree(type, payload),
      3: () => updateTree(type, payload)
    };

    UPDATE[type]();
  };

  const UPDATE_NODE = ({ type, payload }) => {
    const URL = {
      1: AREAS_ORGS,
      2: AREAS_API + "instance",
      3: AREAS_API + "root/child"
    };
    const PAYLOAD = {
      1: {
        name: settings.name,
        industryCodes: [settings.industryCodes.id],
        rowGuid: SELECTED.id,
        isArchive: false
      },
      2: payload,
      3: payload
    };
    sendAPI({
      method: "PUT",
      url: URL[type],
      payload: PAYLOAD[type],
      callback: ({ response }) => UPDATE_RESPONSE({ type, payload, response })
    });
  };

  const UPDATE_DOMAINS = (method, payload) => {
    sendAPI({
      method,
      url: AREAS_API + "instance/email",
      payload: {
        organizationId: TRSTATE.TREE.id,
        instanceId: SELECTED.instanceGuid,
        rootAreaId: SELECTED.rootRowGuid,
        emailDomains: [payload]
      },
      callback: ({ response }) => console.log("resp", response)
    });
  };

  const GET_REC = async instanceID => {
    const MAP_REC = await categories.reduce(async (acc, node) => {
      const accumulator = await acc;

      let traccs;

      await API({
        method: "GET",
        url: `${AREAS_MAIN_API}recommendations/${TRSTATE.ORGANISATION.id}/${instanceID}/${node.id}`,
        callback: ({ response }) => (traccs = response.result),
        reject: ({ response }) => console.log("COULD NOT GET RECOMENDATIONS")
      });

      return [
        ...accumulator,
        {
          id: node.id,
          name: node.name,
          traccs
        }
      ];
    }, []);

    setRecommendations(prevRecommendations => {
      return {
        ...prevRecommendations,
        [TRSTATE.SELECTED.NODE.instanceID]: MAP_REC
      };
    });
  };

  function categoriesAPI(payload) {
    (async payload => {
      // useAPI({
      //   API: AREAS_MAIN_API
      // })

      axios({
        method: "post",
        url: API + "categories/area/link",
        data: payload
      })
        .then(function(response) {
          console.log(response);
        })
        .catch(function(error) {
          // setApiResponse(error.response.data.error);
          console.log(error.response);
        });
    })(payload);
  }

  const updateTree = async (type, data) => {
    let settings;
    let nodeID;
    if (type === 2) {
      settings = {
        country: data.country,
        emailDomainWhiteList: [],
        enableUserCreation: data.AllowUserCreate,
        expirationDate: data.expirationDate,
        note: data.note,
        quotaLE: data.quotaLE,
        quotaSE: data.quotaSE,
        userLimit: data.userLimit,
        visibility: data.IsVisible
      };
      nodeID = data.instanceGuid;
    }
    if (type === 3) {
      nodeID = data.parentGuid;
    }
    const newTree = async mappings => {
      const draft = createDraft(mappings);
      let foundNode = await findNode({
        nodeID,
        nodes: [draft]
      });

      if (type === 2) {
        foundNode.name = data.instanceName;
        foundNode.installationTypeGuid = data.InstallationTypeId;
        foundNode.instanceSettings = settings;
        foundNode.lastUpdated = new Date();
      }

      if (type === 3) {
        foundNode.area.name = data.areaName;
        foundNode.area.licensedEntity = data.licensedEntity;
        foundNode.area.structuralEntity = data.structuralEntity;
        foundNode.area.countryId = data.countryId;
        foundNode.area.notes = data.notes;
      }

      return finishDraft(draft);
    };

    newTree(TRSTATE.TREE).then(payload => {
      TRD({ type: "UPDATE_TREE", payload: payload });
    });
  };

  const PROPS = {
    1: {
      UPDATE_NODE,
      loadingAPI,
      settings,
      onSettings,
      industries
    },
    2: {
      UPDATE_NODE,
      UPDATE_DOMAINS,
      loadingAPI,
      categories
    },
    3: {
      UPDATE_NODE,
      loadingAPI,
      categories,
      GET_REC,
      recommendations: recommendations[TRSTATE.SELECTED.NODE.instanceID],
      categoriesAPI
    }
  };

  const PANEL = {
    1: <OrgPanel {...PROPS[1]} />,
    2: <InstancePanel {...PROPS[2]} />,
    3: <AreaPanel {...PROPS[3]} />
  };

  return (
    <Grid item xs={6} className={cx.root}>
      <div className={cx.panel}>{PANEL[TRSTATE.SELECTED.TYPE]}</div>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    position: "fixed",
    right: 0,
    paddingRight: "48px!important",
    paddingLeft: "48px!important",
    width: "100%",
    height: `calc(100vh - 64px)`
  },
  panel: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "white",
    maxHeight: "100%",
    overflow: "hidden",
    boxShadow: theme.boxShadow,
    borderRadius: 0,
    padding: 32
    // marginTop: 48
  }
}));
