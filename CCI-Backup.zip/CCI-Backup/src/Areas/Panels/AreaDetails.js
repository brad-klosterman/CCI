import React, { useState, useEffect, useContext, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  TextField,
  Grid,
  Typography,
  FormControlLabel,
  FormGroup
} from "@material-ui/core";
import { CSwitch } from "Components/Switch";
import { Selector } from "Components";

const AreaDetails = memo(
  ({ settings, categories, onEdit, onEditCat, recommendations }) => {
    const cx = useStyles();

    const [traccs, setTraccs] = useState([]);

    useEffect(() => {
      if (recommendations) {
        let foundTraccs = [];
        for (let [key, value] of Object.entries(categories)) {
          if (value === true) {
            const found = recommendations.find(x => x.id === key);
            foundTraccs.push(...found.traccs);
          }
        }
        setTraccs(foundTraccs);
      }
    }, [categories, recommendations]);

    const handleSettings = name => event => {
      onEdit({ [name]: event.target.value });
    };

    const handleSwitchSettings = name => event => {
      if (name === "licensedEntity") {
        onEdit({ [name]: event.target.checked, structuralEntity: false });
      } else {
        onEdit({ [name]: event.target.checked, licensedEntity: false });
      }
    };

    const handleSwitchCat = name => event => {
      onEditCat({ [name]: event.target.checked });
    };

    if (!settings) {
      return null;
    }

    return (
      <Grid container spacing={4}>
        <Grid item xs={12}>
          <TextField
            id="area-name"
            label="Area Name"
            variant="outlined"
            value={settings.areaName}
            onChange={handleSettings("areaName")}
            fullWidth
          />
        </Grid>
        <Grid item xs={6}>
          <Selector
            id="Administrator"
            items={countries}
            value={settings.administrator}
            onSelect={handleSettings("administrator")}
            outlined
          />
        </Grid>
        <Grid item xs={6}>
          <Selector
            id="Country"
            items={countries}
            value={settings.countryId}
            onSelect={handleSettings("countryId")}
            outlined
          />
        </Grid>
        <Grid item xs={12}>
          <FormGroup>
            <FormControlLabel
              classes={{ root: cx.switch, label: cx.switchLabel }}
              control={
                <CSwitch
                  checked={settings.licensedEntity}
                  onChange={handleSwitchSettings("licensedEntity")}
                  value="licensedEntity"
                />
              }
              labelplacment="start"
              label="Licensed Entity"
            />
            <FormControlLabel
              classes={{ root: cx.switch, label: cx.switchLabel }}
              control={
                <CSwitch
                  checked={settings.structuralEntity}
                  onChange={handleSwitchSettings("structuralEntity")}
                  value="structuralEntity"
                />
              }
              labelplacment="start"
              label="Structural Entity"
            />
          </FormGroup>
        </Grid>
        {recommendations && (
          <Grid item xs={traccs.length === 0 ? 12 : 6}>
            <Typography variant="h3" className={cx.mainTitle}>
              Categories
            </Typography>
            {recommendations.map((rec, idx) => (
              <div className={cx.row} key={rec + idx}>
                <Typography variant="body2" className={cx.title}>
                  {rec.name}
                </Typography>
                <CSwitch
                  checked={categories[rec.id] || false}
                  onChange={handleSwitchCat(rec.id)}
                  value="licensedEntity"
                />
              </div>
            ))}
          </Grid>
        )}
        {traccs.length !== 0 && (
          <>
            <Grid item xs={6}>
              <Typography variant="h3" className={cx.mainTitle}>
                Associated Traccs
              </Typography>
              {traccs.map(tracc => (
                <div className={cx.row} key={tracc.traccTitle}>
                  {tracc.traccTitle}
                </div>
              ))}
            </Grid>
            <Grid item xs={12}>
              <div className={cx.divider} />
            </Grid>
          </>
        )}

        <Grid item xs={12} className={cx.date}>
          <Typography variant="h6">Date Created: &nbsp;</Typography>
          <Typography variant="h6" className={cx.dateCreated}>
            {settings.dateCreated}
          </Typography>
        </Grid>
      </Grid>
    );
  }
);

const useStyles = makeStyles(theme => ({
  root: {
    paddingTop: 16
  },
  switch: {
    marginLeft: 0
  },
  switchLabel: {
    paddingLeft: 12,
    fontSize: 12
  },
  row: {
    width: "100%",
    display: "flex",
    padding: "8px 0px",
    borderColor: theme.grey[0],
    borderBottom: `1px solid ${theme.grey[0]}`,
    "&:first-child": {
      borderTop: `1px solid ${theme.grey[0]}`
    }
  },
  divider: {
    width: "100%",
    height: 1,
    backgroundColor: theme.grey[0]
  },
  mainTitle: { marginBottom: 16 },
  title: { width: "100%" },
  date: {
    display: "flex",
    alignItems: "flex-end",
    marginBottom: 3
  },
  dateCreated: {
    fontWeight: 300
  }
}));

const countries = ["USA", "China", "South Africa"];

export default AreaDetails;
