import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Typography, TextField, Button } from "@material-ui/core";
import { Selector, SaveButton } from "Components";

function OrgPanel({
  settings,
  onSettings,
  UPDATE_NODE,
  loadingAPI,
  industries
}) {
  const cx = useStyles();

  return (
    <Grid container spacing={4}>
      <Grid item xs={12} className={cx.title}>
        <Typography variant="h2">{settings.name}</Typography>
        <div className={cx.divider} />
      </Grid>
      <Grid item xs={12}>
        <TextField
          label="Name"
          name="name"
          value={settings.name}
          onChange={onSettings("name")}
          fullWidth
          variant="outlined"
        />
      </Grid>
      <Grid item xs={12}>
        <Selector
          id="Industry"
          items={industries}
          onSelect={onSettings("industryCodes")}
          value={settings.industryCodes}
          itemID="description"
          outlined
        />
      </Grid>
      <Grid item xs={12}>
        <Typography variant="subtitle1" className={cx.date}>
          DATE CREATED
        </Typography>
        {settings.createdDate}
      </Grid>
      <Grid item xs={12} className={cx.actions}>
        <SaveButton
          onClick={() => UPDATE_NODE({ type: 1 })}
          classes={cx.btn}
          {...{ loadingAPI }}
        />
        <Button variant="outlined" color="primary">
          Cancel
        </Button>
      </Grid>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  divider: {
    height: 4,
    width: "100%",
    backgroundColor: theme.dark[0],
    marginTop: 16,
    marginBottom: 16
  },
  date: {
    display: "inline-block",
    paddingRight: 16
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    marginTop: "16px"
  },
  btn: {
    marginRight: 16
  }
}));

export default OrgPanel;
