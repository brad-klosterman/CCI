import React, { useState, useEffect, useCallback } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { fade } from "@material-ui/core/styles";
import { Typography, Menu, MenuItem } from "@material-ui/core";
import ToggleInput from "Components/Selects/ToggleInput";
import MenuIcon from "@material-ui/icons/Menu";
import ArrowLeft from "@material-ui/icons/ArrowLeft";
import ArrowRight from "@material-ui/icons/ArrowRight";
import { findAllNodes } from "./DeepFind";
import { useTR } from "./State";

const INIT_STATE = {
  count: { total: undefined, selected: undefined }
};

export default function TreeBar({
  name,
  nodeID,
  children,
  SELECT_NODE,
  ADD_AREA,
  DELETE_AREA,
  onCloneArea
}) {
  const cx = useStyles();
  const { TRSTATE, TRD } = useTR();
  const [selected, setSelected] = useState(true);
  const [menuEl, setMenuEl] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  const [found, setFound] = useState(null);
  const [count, setCount] = useState(INIT_STATE.count);
  const SELECTED = TRSTATE.SELECTED.NODE;

  useEffect(() => {
    SELECT_NODE({ type: 1, nodeID, onDeselect });
  }, []);

  // useEffect(() => {
  //   if (!TRSTATE.SEARCH_TREE.ID) {
  //     console.log("no");
  //     setSearchInput("");
  //     setFound(undefined);
  //     setCount(INIT_STATE.count);
  //   }
  // }, [TRSTATE.SEARCH_TREE]);

  function onSelect(event) {
    event.preventDefault();
    event.stopPropagation();
    if (!selected) {
      SELECT_NODE({ nodeID, type: 1, onDeselect });
      setSelected(true);
    }
  }

  function onDeselect() {
    setSelected(false);
  }

  function openMenu(event) {
    event.stopPropagation();
    setMenuEl(event.currentTarget);
  }

  function closeMenu(event) {
    setMenuEl(null);
  }

  function addNode(event, value) {
    event.stopPropagation();
    let type;
    if (TRSTATE.SELECTED.TYPE === 3) {
      type = 3;
    } else {
      type = value;
    }
    ADD_AREA(type, nodeID, SELECTED);
    setMenuEl(null);
  }

  async function deleteInstance(event) {
    event.stopPropagation();
    const id =
      TRSTATE.ORGANISATION.id +
      "/" +
      SELECTED.rootRowGuid +
      "/" +
      SELECTED.rootRowGuid;
    DELETE_AREA(2, id);
    setMenuEl(null);
  }

  function deleteArea(event) {
    event.stopPropagation();
    SELECT_NODE({ nodeID, type: 1, onDeselect });
    setSelected(true);
    const api =
      TRSTATE.ORGANISATION.id + "/" + SELECTED.rootID + "/" + SELECTED.rowGuid;
    DELETE_AREA(3, api, SELECTED.rowGuid, SELECTED.area.parentGuid);
    setMenuEl(null);
  }

  function cloneArea(event) {
    event.stopPropagation();
    setMenuEl(null);
    onCloneArea();
  }

  async function onSearchInput(value) {
    setSearchInput(value);
    const treeSearch = await findAllNodes(value, [TRSTATE.TREE]);

    if (treeSearch.length) {
      setFound(treeSearch);
      setCount({ total: treeSearch.length, selected: 0 });
    } else {
      setCount({ total: 0, selected: 0 });
      setFound(null);
    }
  }

  const clearCount = () => {
    setCount(INIT_STATE.count);
  };

  async function onCount(event, direction) {
    event.stopPropagation();
    if (count.total === 0) {
      return null;
    }
    let move = 0;
    if (direction === -1) {
      if (count.selected === 1) {
        move = count.total;
      } else {
        move = count.selected - 1;
      }
    } else {
      if (count.selected === count.total) {
        move = 1;
      } else {
        move = count.selected + 1;
      }
    }

    setCount({ ...count, selected: move });
    TRD({
      type: "SEARCH_TREE",
      payload: found[move - 1]
    });
    console.log("SEAR", found[move - 1]);
  }

  const renderCount = count.total > 0 && (
    <div className={cx.countBox}>
      <ArrowLeft fontSize="small" onClick={event => onCount(event, -1)} />
      <Typography variant="subtitle1" className={cx.count}>
        {count.selected + "/" + count.total}
      </Typography>

      <ArrowRight fontSize="small" onClick={event => onCount(event, 1)} />
    </div>
  );

  const ONBACK = event => {
    event.stopPropagation();
    TRD({ type: "ONBACK", payload: null });
  };

  const nodeMenu = (
    <Menu
      id="simple-menu"
      anchorEl={menuEl}
      keepMounted
      open={Boolean(menuEl)}
      onClose={closeMenu}
    >
      <MenuItem onClick={event => addNode(event, 1)}>ADD NEW INSTANCE</MenuItem>
      {TRSTATE.SELECTED.TYPE === 2 && (
        <MenuItem onClick={deleteInstance}>DELETE INSTANCE</MenuItem>
      )}
      {TRSTATE.SELECTED.TYPE > 1 && (
        <MenuItem onClick={event => addNode(event, 2)}>ADD NEW AREA</MenuItem>
      )}
      {TRSTATE.SELECTED.TYPE === 3 && (
        <MenuItem onClick={deleteArea}>DELETE AREA</MenuItem>
      )}
      <MenuItem onClick={cloneArea}>CLONE AREA</MenuItem>
      <MenuItem onClick={ONBACK}>BACK TO ORGANISATIONS</MenuItem>
    </Menu>
  );

  return (
    <div className={cx.root}>
      <div
        className={clsx(cx.nodeBar, {
          [cx.selected]: selected
        })}
        onClick={event => onSelect(event)}
      >
        <div className={cx.typeId} />
        <Typography component="div" variant="h3" className={cx.label}>
          {name}
        </Typography>
        {renderCount}
        <ToggleInput
          name="Search Tree"
          value={searchInput}
          onInput={onSearchInput}
          onClear={clearCount}
        />
        <div className={cx.iconContainer} onClick={openMenu}>
          <MenuIcon fontSize="small" />
        </div>
        {nodeMenu}
      </div>
      <div className={cx.group}>{children}</div>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  group: {
    marginTop: 8,
    marginLeft: 24,
    paddingLeft: 24,
    borderLeft: `1px dashed ${fade(theme.palette.text.primary, 0.4)}`,
    "&:last-child": {
      marginBottom: 0
    }
  },
  nodeBar: {
    width: "100%",
    height: 60,
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    backgroundColor: "white",
    boxShadow: theme.boxShadow,
    borderRadius: 0,
    marginBottom: 0,
    paddingRight: 4
  },
  selected: {
    boxShadow: "0 2px 4px 0 rgba(0,0,0,0.14)",
    // backgroundColor: "rgba(9,128,188,0.05)"
    backgroundColor: theme.light[0],
    "&:hover": {
      backgroundColor: theme.light[0]
    }
  },
  label: {
    width: "100%",
    fontSize: 18
  },
  typeId: {
    width: 8,
    height: "100%",
    backgroundColor: "#118acb",
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    marginRight: 16
  },
  iconContainer: {
    marginRight: 8,
    width: 24,
    display: "flex",
    justifyContent: "center"
  },
  countBox: {
    display: "flex",
    alignItems: "center",
    marginRight: 16
  },
  count: {
    display: "flex",
    alignItems: "center"
  }
}));
