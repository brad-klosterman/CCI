import React, { useState, memo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Typography, Menu, MenuItem, Button } from "@material-ui/core";

import { useTR } from "./State";
import { SortArrows } from "Components";
import OpenIcon from "@material-ui/icons/ChevronRight";
import MenuIcon from "@material-ui/icons/Menu";

export default function Organisations({ NEW_ORG }) {
  const cx = useStyles();
  const { TRSTATE, TRD, organisations } = useTR();
  const [menuEl, setMenuEl] = useState(null);

  const onSelect = (event, org) => {
    event.stopPropagation();
    TRD({ type: "SELECT_ORG", payload: org });
  };

  const onMenu = event => {
    setMenuEl(event.currentTarget);
  };
  const closeMenu = event => {
    setMenuEl(null);
  };

  async function onNew() {
    setMenuEl(null);
    NEW_ORG();
  }

  function onSort({ sortBy, direction }) {
    TRD({ type: "SORT", payload: { sortBy, direction } });
  }

  if (TRSTATE.ORGANISATION) {
    return null;
  }

  return (
    <>
      <Grid item xs={12} className={cx.tableHead}>
        <div className={cx.tableRow}>
          <SortArrows
            name="name"
            direction={TRSTATE.SORT.direction}
            sortBy={TRSTATE.SORT.sortBy}
            onDirection={onSort}
            classes={cx.sortName}
          />
          <SortArrows
            name="industry"
            direction={TRSTATE.SORT.direction}
            sortBy={TRSTATE.SORT.sortBy}
            onDirection={onSort}
            classes={cx.sortIndustry}
          />
          <MenuIcon className={cx.menuIcon} onClick={onMenu} />
          <Menu
            anchorEl={menuEl}
            keepMounted
            open={Boolean(menuEl)}
            onClose={closeMenu}
          >
            <MenuItem onClick={onNew}>Add Organisation</MenuItem>
          </Menu>
        </div>
      </Grid>
      <Grid item xs={12} className={cx.tableRoot}>
        {organisations &&
          organisations.map((org, idx) => (
            <OrgTab cx={cx} org={org} key={org.id} onSelect={onSelect} />
          ))}
      </Grid>
    </>
  );
}

const OrgTab = memo(({ cx, org, onSelect }) => {
  return (
    <div className={cx.tabRoot} onClick={event => onSelect(event, org)}>
      <Typography component="div" variant="h3" className={cx.label}>
        {org.name}
      </Typography>
      <Typography component="div" variant="h3" className={cx.label2}>
        {org.industries[0] && org.industries[0].description}
      </Typography>
      <div className={cx.archiveLabel}>
        {org.isArchive && (
          <Button color="primary" variant="contained" size="small">
            ARCHIVED
          </Button>
        )}
      </div>

      <div className={cx.iconContainer}>
        <OpenIcon />
      </div>
    </div>
  );
});

const useStyles = makeStyles(theme => ({
  tableHead: {
    display: "flex",
    flexWrap: "wrap",
    paddingLeft: 16,
    paddingBottom: "0px!important"
  },
  tableRow: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    height: 64,
    backgroundColor: "white",
    boxShadow: theme.boxShadow,
    marginBottom: 8
  },
  sortItem: {
    padding: "8px 16px",
    width: "20%"
  },
  sortName: {
    width: "35%",
    paddingBottom: 0
  },
  sortIndustry: {
    flexGrow: 1,
    paddingBottom: 0
  },
  menuIcon: {
    marginRight: 28,
    cursor: "pointer"
  },
  tableRoot: {
    padding: "0px 16px!important"
  },
  tabRoot: {
    display: "flex",
    width: "100%",
    height: 64,
    padding: "0px 16px 0px 32px",
    marginBottom: 8,
    alignItems: "center",
    cursor: "pointer",
    backgroundColor: "white",
    boxShadow: theme.boxShadow,
    borderRadius: 0
  },
  selected: {
    boxShadow: "0 4px 8px 0 rgba(0,0,0,0.2)"
  },
  iconContainer: {
    marginRight: 8,
    width: 24,
    display: "flex",
    justifyContent: "center"
  },
  label: {
    width: "35%"
  },
  label2: {
    width: "30%",
    paddingLeft: 16
  },
  archiveLabel: {
    flexGrow: 1,
    paddingLeft: 8
  }
}));
