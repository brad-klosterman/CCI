// const iconClasses = cx({
//   [classes.icon]: classes.icon,
//   [classes.infoIcon]: color === "info",
//   [classes.successIcon]: color === "success",
//   [classes.warningIcon]: color === "warning",
//   [classes.dangerIcon]: color === "danger",
//   [classes.primaryIcon]: color === "primary",
//   [classes.roseIcon]: color === "rose"
// });
