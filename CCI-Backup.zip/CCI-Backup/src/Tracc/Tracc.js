import React from "react";
import { TCProvider } from "./TraccState";
import TraccTree from "./TraccTree";
import Suites from "./Suites";
import Play from "./Play";

export default function TR() {
  return (
    <TCProvider>
      <Play />
    </TCProvider>
  );
}
