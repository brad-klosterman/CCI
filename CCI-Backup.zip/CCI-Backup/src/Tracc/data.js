export const suites = [
  {
    id: "1",
    name: "Sourcing",
    category: "CCI Production",
    status: "Active"
  },
  {
    id: "2",
    name: "Planning",
    category: "CCI Production",
    status: "Active"
  },
  {
    id: "3",
    name: "Operations",
    category: "CCI Production",
    status: "Active"
  },
  {
    id: "4",
    name: "Service",
    category: "CCI Production",
    status: "Active"
  },
  {
    id: "5",
    name: "Innovation",
    category: "CCI Production",
    status: "Active"
  }
];
