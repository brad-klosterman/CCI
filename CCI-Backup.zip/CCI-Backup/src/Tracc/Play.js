import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Button } from "@material-ui/core";
import { useAState, useDash } from "state";

const Play = () => {
  const cx = useStyles();
  const { DIALOG } = useDash();

  function openAlert() {
    DIALOG.confirm({
      variant: "warning",
      title: {
        1: "ARE YOU SURE YOU WANT TO DELETE?",
        2: "HOLD ON WHILE WE SAVE YOUR SETTINGS",
        3: "SUCCESS SAVING INSTANCE"
      },
      message: {
        1: "Deleting this instance will result in this. Call Andres service to find repercussions.",
        2: undefined,
        3: undefined
      },
      actions: { ok: "CONFIRM", cancel: "CANCEL", exit: "CONTINUE" }
    }).then(res => {
      /// API call
      console.log("then", res);

      setTimeout(() => {
        return DIALOG.confirmationResponse("value");
      }, 4000);
    });
    // updateID({ action: "REMOVE_INSTANCE", location });
    // setExpanded(location);
  }

  return (
    <Grid className={cx.root} container spacing={4}>
      <Grid item xs={12}>
        <Button variant="outlined" onClick={openAlert}>
          OPEN ALERT
        </Button>
      </Grid>
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {}
}));

export default Play;
