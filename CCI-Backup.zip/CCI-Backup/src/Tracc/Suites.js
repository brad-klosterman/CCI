import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Grid, Typography, Menu, MenuItem } from "@material-ui/core";
import { SortArrows } from "Components";
import MenuIcon from "@material-ui/icons/Menu";
import { suites } from "./data";
import { useTC } from "./TraccState";

const Suites = ({ selectSuite }) => {
  const cx = useStyles();
  const { TCSTATE, TCDISPATCH } = useTC();
  const [menuEl, setMenuEl] = useState(null);

  const onMenu = event => {
    setMenuEl(event.currentTarget);
  };
  const closeMenu = event => {
    setMenuEl(null);
  };

  function onSort({ sortBy, direction }) {
    TCDISPATCH({ type: "SORT", payload: { sortBy, direction } });
  }

  function addSuite() {}

  return (
    <Grid className={cx.root} container spacing={4}>
      <Grid item xs={12} className={cx.sort}>
        <SortArrows
          name="name"
          direction={TCSTATE.SORT.direction}
          sortBy={TCSTATE.SORT.sortBy}
          onDirection={onSort}
          classes={cx.sortItem}
        />
        <SortArrows
          name="category"
          direction={TCSTATE.SORT.direction}
          sortBy={TCSTATE.SORT.sortBy}
          onDirection={onSort}
          classes={cx.sortItem}
        />
        <SortArrows
          name="status"
          direction={TCSTATE.SORT.direction}
          sortBy={TCSTATE.SORT.sortBy}
          onDirection={onSort}
          classes={cx.sortItem}
        />
        <MenuIcon fontSize="small" className={cx.menuIcon} onClick={onMenu} />
        <Menu
          id="simple-menu"
          anchorEl={menuEl}
          keepMounted
          open={Boolean(menuEl)}
          onClose={closeMenu}
        >
          <MenuItem onClick={addSuite}>Create Suite</MenuItem>
        </Menu>
        <div className={cx.divider} />
      </Grid>
      <Grid item xs={12}>
        {suites &&
          suites.map(({ id, name, category, status }) => (
            <div key={id} className={cx.item}>
              <Typography
                onClick={() => selectSuite(id)}
                className={cx.itemTitle}
                variant="h3"
              >
                {name}
              </Typography>
              <Typography
                onClick={() => selectSuite(id)}
                className={cx.itemTitle}
                variant="h6"
              >
                {category}
              </Typography>
              <Typography
                onClick={() => selectSuite(id)}
                className={cx.itemTitle}
                variant="h6"
              >
                {status}
              </Typography>
            </div>
          ))}
      </Grid>
    </Grid>
  );
};

const useStyles = makeStyles(theme => ({
  root: {},
  sort: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    paddingLeft: 16,
    marginTop: 16
  },
  sortItem: {
    padding: "8px 16px",
    width: "32%",
    flexGrow: 1
  },
  menuIcon: {
    marginRight: 12,
    cursor: "pointer"
  },
  divider: {
    width: "100%",
    height: "2px",
    backgroundColor: theme.dark[0]
  },
  item: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    backgroundColor: "white",
    boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.14)",
    padding: "20px 16px",
    marginBottom: 8,
    borderRadius: 0
  },
  itemTitle: {
    width: "32%",
    flexGrow: 1
  }
}));

export default Suites;
