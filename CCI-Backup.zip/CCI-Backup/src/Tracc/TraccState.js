import React, { useReducer, createContext, useContext } from "react";

const reducer = (state, action) => {
  switch (action.type) {
    case "SELECT_SUITE":
      return {
        ...state,
        SUITE: action.payload
      };
    case "SORT":
      return {
        ...state,
        SORT: action.payload
      };

    default:
      return state;
  }
};

const TCContext = createContext();

function TCProvider({ children }) {
  const [TCSTATE, TCDISPATCH] = useReducer(reducer, {
    SUITE: null,
    SORT: {
      direction: "asc",
      sortBy: "name"
    }
  });

  return (
    <TCContext.Provider value={{ TCSTATE, TCDISPATCH }}>
      {children}
    </TCContext.Provider>
  );
}

const useTC = () => {
  const { TCSTATE, TCDISPATCH } = useContext(TCContext);
  return {
    TCSTATE,
    TCDISPATCH
  };
};

export { TCContext, TCProvider, useTC };
