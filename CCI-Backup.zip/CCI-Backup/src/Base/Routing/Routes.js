/// INTERFACES
import TR from "Areas/TR";
import { USRProvider } from "People";
import Tracc from "Tracc/Tracc";
/// ICONS

import User from "@material-ui/icons/SupervisedUserCircle";
import Explore from "@material-ui/icons/Explore";
import AccountTreeIcon from "@material-ui/icons/AccountTree";

export const MAIN_ROUTES = [
  {
    path: "/people",
    name: "PEOPLE",
    component: USRProvider,
    icon: User
  },
  {
    path: "/areas",
    exact: true,
    name: "AREAS",
    component: TR,
    icon: AccountTreeIcon
  },
  {
    path: "/tracc",
    name: "TRACC",
    component: Tracc,
    icon: Explore
  }
];
