import React, { useContext, useCallback } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import { Avatar } from "@material-ui/core";
import { fade } from "@material-ui/core/styles/colorManipulator";
import Menu from "@material-ui/icons/Menu";

import { DashboardContext } from "state/context";
import { containerFluid, systemColors, NavBarHeight } from "style/globalStyle";

const Header = ({ open, onOpen }) => {
  const cx = useStyles();
  const { state, dispatch } = useContext(DashboardContext);
  // ACTIONS

  return (
    <AppBar className={cx.appBar} color="primary" position="fixed">
      <Toolbar className={cx.container}>
        {!open && <Menu onClick={onOpen} calssNam={cx.navMenu} />}
        <div className={cx.flex} />
      </Toolbar>
    </AppBar>
  );
};

const useStyles = makeStyles(theme => ({
  appBar: {
    backgroundColor: "transparent",
    boxShadow: "none",
    borderBottom: "0",
    marginBottom: "0",
    padding: "0px",
    width: "100%",
    zIndex: "1129",
    color: theme.grey[1],
    border: "0",
    transition: "all 150ms ease 0s",
    height: NavBarHeight,
    display: "block"
  },
  container: {
    ...containerFluid,
    minHeight: "64px",
    paddingLeft: "16px",
    paddingRight: "16px"
  },
  flex: {
    flex: 1
  },
  navMenu: {
    cursor: "pointer"
  },

  badge: {
    backgroundColor: systemColors[0],
    color: "white"
  },
  avatar: {
    backgroundColor: theme.grey[1],
    height: "38px",
    width: "38px",
    marginLeft: "8px",
    fontSize: "16px",
    fontWeight: "bold"
  }
}));

export default Header;
