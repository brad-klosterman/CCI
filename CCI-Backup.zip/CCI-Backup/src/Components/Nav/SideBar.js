import React, { useEffect, useRef } from "react";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import { NavLink } from "react-router-dom";
import { MAIN_ROUTES } from "Base/Routing/Routes";
import { Drawer, List, ListItem, ListItemText } from "@material-ui/core";

const drawerWidth = 240;

export default function SideBar({
  open,
  onSideHover,
  onSideExit,
  selectNav,
  history
}) {
  const cx = useStyles();
  const panelRef = useRef(null);

  useEffect(() => {
    const panelEvent = panelRef.current;
    if (panelEvent) {
      panelEvent.addEventListener("mouseenter", onSideHover);
      panelEvent.addEventListener("mouseleave", onSideExit);
    }

    return () => {
      if (panelEvent) {
        panelEvent.removeEventListener("mouseenter", onSideHover);
        panelEvent.removeEventListener("mouseleave", onSideExit);
      }
    };
  }, [onSideExit, onSideHover]);

  return (
    <div ref={panelRef}>
      <Drawer
        variant="permanent"
        className={clsx(cx.drawer, {
          [cx.drawerOpen]: open,
          [cx.drawerClose]: !open
        })}
        classes={{
          paper: clsx(cx.paper, {
            [cx.drawerOpen]: open,
            [cx.drawerClose]: !open
          })
        }}
        open={open}
      >
        <List className={cx.list}>
          {MAIN_ROUTES.map((route, idx) => {
            const Icon = route.icon;
            return (
              <ListItem button key={idx} className={cx.listItem}>
                <NavLink
                  to={route.path}
                  className={cx.navLink}
                  activeClassName={cx.active}
                >
                  <Icon className={cx.itemIcon} />
                  <ListItemText
                    primary={route.name}
                    classes={{ primary: cx.itemText }}
                  />
                </NavLink>
              </ListItem>
            );
          })}
        </List>
      </Drawer>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
    border: "none"
  },
  paper: {
    borderRight: "0px",
    boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.14)"
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    overflowX: "hidden",
    width: theme.spacing(8),
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(8)
    }
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    ...theme.mixins.toolbar
  },
  toggleIcon: {
    cursor: "pointer",
    color: theme.grey[2],
    width: 64
  },
  itemIcon: {
    width: 32,
    minWidth: "auto",
    marginRight: 24,
    justifyContent: "center"
  },
  list: {
    padding: 0
  },
  listItem: {
    padding: 0
    // borderBottom: "1px solid rgba(0, 0, 0, 0.08)"
  },
  navLink: {
    display: "flex",
    alignItems: "center",
    textDecoration: "none",
    paddingLeft: 16,
    paddingTop: 16,
    paddingBottom: 16,
    color: theme.grey[2],
    width: "100%"
  },
  itemText: {
    color: "inherit"
  },
  active: {
    color: "white",
    backgroundColor: theme.palette.primary.dark
  }
}));

// <div className={cx.drawerHeader}>
//   <IconButton onClick={onClose}>
//     <ChevronLeftIcon />
//   </IconButton>
// </div>
// <Divider />
// <List>
//   {MAIN_ROUTES.map((route, idx) => {
//     const Icon = route.icon;
//     return (
//       <ListItem
//         button
//         key={idx}
//         // onClick={() => selectNav(route.name)}
//       >
//         <NavLink
//           to={route.path}
//           className={cx.navLink}
//           // isActive={() => (route.name === LOCATION ? true : false)}
//           activeClassName={cx.active}
//         >
//           <ListItemIcon>
//             <Icon />
//           </ListItemIcon>
//
//           <ListItemText
//             primary={route.name}
//             // classes={{ primary: cx.itemText }}
//           />
//         </NavLink>
//       </ListItem>
//     );
//   })}
// </List>
