import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

import {
  Dialog,
  DialogTitle,
  DialogActions,
  DialogContent,
  Typography
} from "@material-ui/core";

export function CreateDialog(props) {
  const cx = useStyles();
  const { children, state, title, onClose, onSend, ...other } = props;

  function handleClose() {
    onClose();
  }

  let actions;

  if (state === 0) {
    actions = (
      <>
        <Button
          onClick={onSend}
          className={cx.btn}
          variant="contained"
          color="primary"
          autoFocus
        >
          CREATE
        </Button>
        <Button
          onClick={handleClose}
          className={cx.btn}
          variant="outlined"
          color="primary"
          autoFocus
        >
          CANCEL
        </Button>
      </>
    );
  } else {
    actions = (
      <Button
        onClick={handleClose}
        className={cx.btn}
        variant="outlined"
        color="primary"
        autoFocus
      >
        CONTINUE
      </Button>
    );
  }

  return (
    <Dialog
      {...other}
      fullWidth
      maxWidth="sm"
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <div className={cx.header}>
        <Typography variant="h2" color="secondary" align="center">
          {title}
        </Typography>
      </div>
      <DialogContent>{children}</DialogContent>
      <DialogActions classes={{ root: cx.actions }}>{actions}</DialogActions>
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  header: {
    color: "white",
    backgroundColor: theme.palette.primary.dark,
    fontSize: 16,
    padding: "48px 12px"
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    padding: 32
  },
  btn: {
    margin: "0pc 4px"
  }
}));
