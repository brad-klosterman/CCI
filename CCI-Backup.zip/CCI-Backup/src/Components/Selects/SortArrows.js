import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import Up from "@material-ui/icons/KeyboardArrowUp";
import Down from "@material-ui/icons/KeyboardArrowDown";

export function SortArrows({ name, classes, direction, sortBy, onDirection }) {
  const cx = useStyles();

  const selected = sortBy === name;

  return (
    <div
      className={clsx({
        [cx.root]: true,
        [classes]: classes
      })}
    >
      <div
        className={clsx({
          [cx.name]: true,
          [cx.selected]: selected
        })}
      >
        {name.toUpperCase()}
      </div>
      <div className={cx.arrows}>
        <Up
          className={selected && direction === "desc" ? cx.direction : null}
          classes={{ root: cx.icon }}
          onClick={() => onDirection({ sortBy: name, direction: "desc" })}
        />
        <Down
          className={selected && direction === "asc" ? cx.direction : null}
          classes={{ root: cx.icon }}
          onClick={() => onDirection({ sortBy: name, direction: "asc" })}
        />
      </div>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    alignItems: "center",
    paddingLeft: 32,
    paddingBottom: 8
  },
  name: {
    paddingRight: 8,
    cursor: "pointer",
    fontWeight: "bold",
    fontFamily: "Montserrat",
    opacity: "0.8",
    "&:hover": {
      opacity: "1"
    }
  },
  selected: {
    opacity: "1"
  },
  arrows: {
    display: "flex",
    flexDirection: "column"
  },
  icon: {
    cursor: "pointer",
    transform: "scale(1.9)",
    width: 10,
    height: 10,
    fontSize: 10,
    opacity: "0.4",
    "&:hover": {
      opacity: "1"
    }
  },
  direction: {
    opacity: "1"
  }
}));
