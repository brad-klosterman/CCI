import React, { useState, createRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { InputBase, IconButton } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import CloseIcon from "@material-ui/icons/Close";

function ToggleInput({ name, value, onInput, onClear }) {
  const cx = useStyles();
  let textInput = createRef();

  const [inputFocused, setInputFocused] = useState(false);

  function onChange(event) {
    event.stopPropagation();
    // onSend && onInput(event.target.value);
    onInput(event.target.value);
  }

  function onAction(event) {
    event.preventDefault();
    event.stopPropagation();
    if (inputFocused) {
      /// clear in parent compont
      onClear();
    } else {
      textInput.current.focus();
    }
    setInputFocused(prevInputFocused => !prevInputFocused);
  }

  const inputActions = !inputFocused ? (
    <SearchIcon fontSize="small" />
  ) : (
    <CloseIcon fontSize="small" />
  );

  return (
    <div className={cx.inputBar}>
      <InputBase
        inputRef={textInput}
        classes={{
          root: cx.inputBase,
          input: clsx(cx.input, {
            [cx.inputFocused]: inputFocused
          })
        }}
        placeholder={name}
        inputProps={{ "aria-label": { name } }}
        value={value}
        onChange={event => onChange(event)}
        onClick={event => event.stopPropagation()}
      />

      <IconButton
        onClick={event => onAction(event)}
        className={clsx(cx.inputIcon, {
          [cx.iconFocused]: inputFocused
        })}
        disableRipple
      >
        {inputActions}
      </IconButton>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  inputBar: {
    display: "flex",
    alignItems: "center",
    position: "relative",
    marginRight: 8
  },
  inputBase: {
    width: "100%",
    minWidth: 144
  },
  input: {
    width: 0,
    border: "1px solid",
    borderColor: "transparent",
    transition: theme.transitions.create("width"),
    padding: "2px 8px",
    right: 0
  },
  inputFocused: {
    width: 200,
    borderColor: theme.grey[1]
  },
  inputIcon: {
    position: "absolute",
    right: 0,
    paddingRight: 0,
    transition: theme.transitions.create(),
    fontSize: 12
  },
  iconFocused: {
    right: 8
  }
}));

export default ToggleInput;
