import React, { memo, useState, useRef, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Input,
  OutlinedInput,
  InputLabel,
  List,
  ListItem,
  ListItemIcon,
  FormControl,
  ListItemText,
  Select,
  Checkbox,
  Grid
} from "@material-ui/core";
import ExpandIcon from "@material-ui/icons/UnfoldMore";

const useStyles = makeStyles(theme => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
    maxWidth: 300
  },
  noLabel: {
    marginTop: theme.spacing(3)
  },
  form: {
    flexDirection: "row",
    display: "flex",
    alignItems: "center"
  },
  icon: {
    fontWeight: 900,
    width: 16,
    marginRight: 4,
    cursor: "pointer"
  }
}));

export const MultiSelect = memo(
  ({
    id,
    label,
    nameID,
    value,
    items,
    children,
    onSelect,
    width,
    disabled
  }) => {
    const classes = useStyles();
    const inputLabel = useRef(null);
    const [labelWidth, setLabelWidth] = useState(0);
    useEffect(() => {
      setLabelWidth(inputLabel.current.offsetWidth);
    }, []);
    const [checked, setChecked] = useState(value ? value : []);

    const handleToggle = item => () => {
      const currentIndex = checked.findIndex(i => i[nameID] === item[nameID]);
      const newChecked = [...checked];
      if (currentIndex === -1) {
        newChecked.push(item);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setChecked(newChecked);
      onSelect && onSelect(newChecked);
    };

    const selected = () => {
      let arr = [];
      checked.forEach(e => arr.push(e[nameID]));
      return arr.join(", ");
    };

    return (
      <Grid item xs={width} className={classes.form}>
        <FormControl fullWidth disabled={disabled} variant="outlined">
          <InputLabel htmlFor={id} ref={inputLabel}>
            {label}
          </InputLabel>
          <Select
            multiple
            value={checked}
            IconComponent={() => null}
            input={
              <OutlinedInput
                labelWidth={labelWidth}
                name={label}
                id={id}
                fullWidth
                startAdornment={<ExpandIcon className={classes.icon} />}
              />
            }
            renderValue={() => selected()}
          >
            <List>
              {items.map((item, idx) => {
                return (
                  <ListItem
                    key={idx}
                    value={item}
                    dense
                    button
                    onClick={handleToggle(item)}
                  >
                    <ListItemIcon>
                      <Checkbox
                        edge="start"
                        color="primary"
                        checked={
                          checked.findIndex(i => i[nameID] === item[nameID]) !==
                          -1
                        }
                        tabIndex={-1}
                        disableRipple
                      />
                    </ListItemIcon>
                    <ListItemText primary={item && item[nameID]} />
                  </ListItem>
                );
              })}
            </List>
          </Select>
        </FormControl>
        {children}
      </Grid>
    );
  }
);
