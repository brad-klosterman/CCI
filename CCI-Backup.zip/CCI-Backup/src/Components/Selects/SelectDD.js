import React, { useEffect, useState, useRef, memo } from "react";
import {
  Grid,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  OutlinedInput
} from "@material-ui/core";

export const Selector = ({
  id,
  value,
  itemID,
  items,
  children,
  selected,
  onSelect,
  deselect,
  disabled,
  width,
  outlined,
  validate,
  error,
  erMsg,
  classes
}) => {
  const inputLabel = useRef(null);
  const [labelWidth, setLabelWidth] = useState(0);
  useEffect(() => {
    setLabelWidth(inputLabel.current.offsetWidth);
  }, []);

  let renderProp = {};
  if (value && itemID && value[itemID]) {
    renderProp = {
      renderValue: value => value[itemID]
    };
  } else {
    renderProp = {
      renderValue: value => value
    };
  }

  return (
    <Grid item xs={width}>
      <FormControl
        fullWidth
        disabled={disabled}
        variant="outlined"
        error={error}
      >
        <InputLabel htmlFor={id} ref={inputLabel}>
          {id}
        </InputLabel>
        <Select
          value={value || ""}
          {...renderProp}
          onChange={onSelect}
          input={
            <OutlinedInput
              labelWidth={labelWidth}
              id={id}
              name={id.toLowerCase().replace(/\s/g, "")}
              fullWidth
            />
          }
        >
          {deselect && (
            <MenuItem key="none" value="" name="deselect">
              DESELECT
            </MenuItem>
          )}
          {items ? (
            Object.values(items).map((item, idx) => {
              let itemName;
              if (itemID && itemID in item) {
                itemName = item[itemID];
              } else {
                itemName = item;
              }

              return (
                <MenuItem
                  key={itemName + idx}
                  value={item}
                  // disabled={selected ? enabled(itemName) : false}
                >
                  {itemName}
                </MenuItem>
              );
            })
          ) : (
            <MenuItem
              key={value}
              value={value}
              // disabled={selected ? enabled(itemName) : false}
            >
              {value}
            </MenuItem>
          )}
        </Select>
        {erMsg && <FormHelperText>{erMsg}</FormHelperText>}
      </FormControl>
      {children}
    </Grid>
  );
};
