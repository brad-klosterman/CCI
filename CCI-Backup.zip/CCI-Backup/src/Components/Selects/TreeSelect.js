import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
  forwardRef
} from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  FormControl,
  InputLabel,
  Dialog,
  DialogContent,
  OutlinedInput,
  Collapse,
  Typography,
  MenuItem,
  Slide
} from "@material-ui/core";
import ExpandIcon from "@material-ui/icons/UnfoldMore";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import CollapseIcon from "@material-ui/icons/ChevronRight";
import NoneIcon from "@material-ui/icons/FiberManualRecord";

/// USE TREE SELECT

export function useTreeSelect() {
  const [open, setOpen] = useState(false);

  const openSelect = useCallback(id => {
    setOpen(id);
  }, []);
  const closeSelect = useCallback(() => {
    setOpen(undefined);
  }, []);

  return {
    treeOpen: open,
    treeActions: {
      openSelect,
      closeSelect
    }
  };
}

/// TREE SELECT

export function TreeSelect({
  id,
  rowGuid,
  idx,
  area,
  label,
  openSelect,
  children
}) {
  const cx = useStyles();

  const inputLabel = useRef(null);
  const [labelWidth, setLabelWidth] = useState(0);

  useEffect(() => {
    setLabelWidth(inputLabel.current.offsetWidth);
  }, []);

  return (
    <Grid item xs={6} className={cx.grid}>
      <FormControl fullWidth variant="outlined">
        <InputLabel htmlFor={area.rowGuid.toString()} ref={inputLabel}>
          {label}
        </InputLabel>
        <OutlinedInput
          id={area.rowGuid.toString()}
          value={area.name}
          placeholder={label}
          labelWidth={labelWidth}
          fullWidth
          classes={{ root: cx.outlinedInput, input: cx.input }}
          startAdornment={
            <ExpandIcon onClick={() => openSelect(id)} className={cx.icon} />
          }
          endAdornment={children}
          inputProps={{ onClick: () => openSelect(id) }}
        />
      </FormControl>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  root: {},
  paper: {
    padding: "16px 32px",
    width: 500
  },
  grid: {
    display: "flex",
    alignItems: "center"
  },
  outlinedInput: {},
  input: {
    cursor: "pointer"
  },
  icon: {
    width: 16,
    marginRight: 4,
    cursor: "pointer"
  }
}));

/// TREE ITEM

const TreeItem = forwardRef(function TreeItem(
  { location, id, rowGuid, name, children, selected, onSelect, closeSelect },
  ref
) {
  const cx = useItems();
  const expandable = Boolean(
    Array.isArray(children) ? children.length : children
  );
  const [expanded, setExpanded] = useState(false);

  let icon;
  if (!icon) {
    if (expandable) {
      if (expanded) {
        icon = <ExpandMoreIcon className={cx.icon} fontSize="small" />;
      } else {
        icon = <CollapseIcon className={cx.icon} fontSize="small" />;
      }
    } else {
      icon = <NoneIcon className={cx.noneIcon} fontSize="small" />;
    }
  }

  function onClick(event) {
    event.stopPropagation();
    onSelect({
      action: "UPDATE_AREA",
      location,
      payload: {
        id,
        name,
        rowGuid
      }
    });
    closeSelect();
  }

  function onExpand(event) {
    event.stopPropagation();
    setExpanded(prevExpanded => !prevExpanded);
  }

  return (
    <li className={cx.item} role="treeitem">
      <MenuItem component="div" selected={selected} onClick={onClick}>
        <div className={cx.iconContainer} onClick={onExpand}>
          {icon}
        </div>
        <Typography
          component="div"
          variant="h3"
          color="inherit"
          className={cx.label}
        >
          {name}
        </Typography>
      </MenuItem>
      {children && (
        <Collapse
          unmountOnExit
          className={cx.group}
          classes={{ wrapperInner: cx.groupWrapper }}
          in={expanded}
          component="ul"
          role="group"
        >
          {children}
        </Collapse>
      )}
    </li>
  );
});

const useModal = makeStyles(theme => ({
  content: { minWidth: 540, padding: 24 }
}));

/// TREE MODAL

export function TreeModal({
  open,
  data,
  location,
  selected,
  closeSelect,
  onSelect
}) {
  const cx = useModal();

  const TreeRender = ({ area: { id, rowGuid, name }, children }) => {
    const props = {
      location,
      id,
      rowGuid,
      name,
      onSelect,
      closeSelect,
      selected: rowGuid === selected
    };

    if (!Array.isArray(children) || !children.length) {
      return <TreeItem key={rowGuid} {...props} />;
    }
    return (
      <TreeItem key={rowGuid} {...props}>
        {children.map(node => TreeRender(node))}
      </TreeItem>
    );
  };
  return (
    <Dialog
      onClose={closeSelect}
      aria-labelledby="select-area"
      open={open}
      TransitionComponent={Transition}
    >
      <DialogContent className={cx.content}>
        {(data || []).map(i => TreeRender(i))}
      </DialogContent>
    </Dialog>
  );
}

const useItems = makeStyles(theme => ({
  item: {
    listStyle: "none",
    margin: 0,
    padding: 0,
    outline: 0
    // marginBottom: 8,
    // marginTop: 8
  },

  group: {
    // marginTop: 8,
    // marginLeft: 16,
    paddingLeft: 20
    // borderLeft: `1px dashed ${fade(theme.palette.text.primary, 0.4)}`,
    // "&:last-child": {
    //   marginBottom: 0
    // },
    // "&:first-child": {
    //   marginTop: 0
    // }
  },
  // groupWrapper: {
  //   "& li:last-child": {
  //     marginBottom: 0
  //   },
  //   "& li:first-child": {
  //     marginTop: 0
  //   }
  // },
  content: {
    width: "100%",
    // height: 40,
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    paddingTop: 8,
    paddingBottom: 8,
    "&:hover": {
      color: theme.palette.primary.main
    },
    "&:focus": {
      outline: "0!important"
    }
  },
  selected: {
    color: "red"
  },

  label: {
    width: "100%",
    fontSize: 14,
    lineHeight: 1
  },
  iconContainer: {
    marginRight: 4,
    width: 24,
    display: "flex",
    justifyContent: "center"
  },
  icon: {
    fontSize: 20
  },
  noneIcon: {
    fontSize: 8
  }
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});
