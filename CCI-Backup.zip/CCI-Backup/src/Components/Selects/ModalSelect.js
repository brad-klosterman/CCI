import React, { useState, useCallback, useEffect } from "react";

import { makeStyles } from "@material-ui/core/styles";
import { Dialog, DialogContent, MenuItem, Slide } from "@material-ui/core";

export function useModalSelect() {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState({});
  const [id, setId] = useState();
  const [location, setLocation] = useState([]);

  const openModal = useCallback(({ selector, id, location }) => {
    setOpen(true);
    setData(selector);
    setId(id);
    setLocation([location]);
  }, []);
  const closeModal = useCallback(() => {
    setOpen(false);
    setData({});
  }, []);

  return {
    open,
    openModal,
    closeModal,
    data,
    id,
    location
  };
}

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export function ModalSelect({
  open,
  closeModal,
  onSelect,
  data,
  id,
  location
}) {
  const cx = useStyles();

  let name;
  let guid;

  if (id === "organisation") {
    name = "organisationName";
    guid = "organisationGuid";
  } else if (id === "instance") {
    name = "instanceName";
    guid = "instanceGuid";
  }

  return (
    <Dialog
      onClose={closeModal}
      aria-labelledby="add-instance"
      open={open}
      TransitionComponent={Transition}
      keepMounted
    >
      <DialogContent className={cx.content}>
        {Object.values(data).map(i => (
          <MenuItem
            key={i[guid]}
            disabled={i.selected}
            onClick={() => {
              onSelect({
                id,
                location,
                payload: [i[guid], i[name]]
              });
              closeModal();
            }}
          >
            {i[name]}
          </MenuItem>
        ))}
      </DialogContent>
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  root: {},
  content: {
    padding: 32,
    minWidth: 400
  }
}));
