import React, { useState, useEffect, memo } from "react";
import { withStyles } from "@material-ui/core/styles";
import {
  Grid,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  Input,
  OutlinedInput
} from "@material-ui/core";

const Selector = memo(
  ({
    id,
    value,
    items,
    children,
    selected,
    onSelect,
    deselect,
    disabled,
    width,
    outlined,
    validate,
    error,
    erMsg,
    classes
  }) => {
    const [val, setVal] = useState(value ? value : "");

    function handleChange(ev) {
      setVal(ev.target.value);
      onSelect && onSelect(ev.target.value);
    }

    useEffect(
      () => {
        setVal(value ? value : "");
      },
      [value]
    );

    const enabled = item => {
      const key = e =>
        id === "Instance" ? e.instanceName : id === "Area" ? e.areaName : "";
      return selected.some(e => key(e) === item);
    };

    const renderValue = () => {
      return value
        ? typeof value === "string"
          ? value
          : "organisationName" in value
          ? value.organisationName
          : "instanceName" in value
          ? value.instanceName
          : "areaName" in value
          ? value.areaName
          : value
        : "";
    };

    return (
      <Grid item xs={width} className={classes.form}>
        <FormControl fullWidth disabled={disabled} error={error}>
          <InputLabel htmlFor={id} variant={outlined && "outlined"}>
            {id}
          </InputLabel>
          <Select
            value={val}
            renderValue={value ? () => renderValue() : null}
            onChange={handleChange}
            input={
              outlined ? (
                <OutlinedInput
                  labelwidth={0}
                  name={id.toLowerCase()}
                  id={id}
                  fullWidth
                />
              ) : (
                <Input
                  labelwidth={0}
                  name={id.toLowerCase()}
                  id={id}
                  fullWidth
                />
              )
            }
          >
            {" "}
            {deselect && (
              <MenuItem key="none" value="" name="deselect">
                DESELECT
              </MenuItem>
            )}
            {items.length &&
              items.map((item, idx) => {
                const itemName = item.organisationName
                  ? item.organisationName
                  : item.instance
                  ? item.instance.instanceName
                  : item.areaName
                  ? item.areaName
                  : item.roleName
                  ? item.roleName
                  : item.description
                  ? item.description
                  : item;

                return (
                  <MenuItem
                    key={itemName + idx}
                    value={item}
                    disabled={selected ? enabled(itemName) : false}
                  >
                    {itemName}
                  </MenuItem>
                );
              })}
          </Select>
          {erMsg && <FormHelperText>{erMsg}</FormHelperText>}
        </FormControl>
        {children}
      </Grid>
    );
  }
);

// disabled={
//   selected
//     ? enabled(
//         item.rowGuid
//           ? item.rowGuid
//           : item.instance.instanceGuid
//       )
//     : false
// }

const styles = {
  form: {
    flexDirection: "row",
    display: "flex"
  }
};

export default withStyles(styles)(Selector);
