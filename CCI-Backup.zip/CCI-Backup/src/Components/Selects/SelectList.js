import React, { memo, useState, useEffect, useCallback } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Menu,
  MenuItem,
  ListItemIcon,
  Button,
  ListItemText,
  Checkbox,
  Grid
} from "@material-ui/core";

export const SelectList = memo(
  ({ id, checked, items, nameID, children, onSelect, width, disabled }) => {
    const classes = useStyles();
    const [menuEl, setMenuEl] = useState(null);

    const onOpen = event => {
      setMenuEl(event.currentTarget);
    };

    const onClose = () => {
      setMenuEl(null);
    };

    const handleToggle = useCallback(
      item => {
        const currentIndex = checked.findIndex(i => i[nameID] === item[nameID]);
        const newChecked = [...checked];
        let added;
        let removed;
        if (currentIndex === -1) {
          newChecked.push(item);
          added = item;
        } else {
          newChecked.splice(currentIndex, 1);
          removed = checked[currentIndex];
        }

        onSelect && onSelect({ newChecked, added, removed });
      },
      [checked, nameID, onSelect]
    );

    return (
      <Grid item xs={width} className={classes.form}>
        <Button
          aria-controls="subscriptions-menu"
          aria-haspopup="true"
          onClick={onOpen}
          variant="contained"
          color="primary"
          size="small"
        >
          Add / Remove Traccs
        </Button>

        <Menu
          anchorEl={menuEl}
          keepMounted
          open={Boolean(menuEl)}
          onClose={onClose}
        >
          {items.map((item, idx) => {
            return (
              <MenuItem
                key={idx}
                value={item}
                dense
                button
                onClick={() => handleToggle(item)}
              >
                <ListItemIcon>
                  <Checkbox
                    edge="start"
                    color="primary"
                    checked={
                      checked.findIndex(
                        i => i["traccId"] === item["traccId"]
                      ) !== -1
                    }
                    tabIndex={-1}
                    disableRipple
                  />
                </ListItemIcon>
                <ListItemText primary={item && item[nameID]} />
              </MenuItem>
            );
          })}
        </Menu>
      </Grid>
    );
  }
);

const useStyles = makeStyles(theme => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
    maxWidth: 300
  },
  noLabel: {
    marginTop: theme.spacing(3)
  },
  form: {
    flexDirection: "row",
    display: "flex"
  }
}));
