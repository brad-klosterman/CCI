import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { Grid, Typography, Tooltip } from "@material-ui/core";
import Clear from "@material-ui/icons/DeleteForever";
import ExpandMoreIcon from "@material-ui/icons/ArrowDropDown";
import AddIcon from "@material-ui/icons/LibraryAdd";

import MuiExpansionPanel from "@material-ui/core/ExpansionPanel";
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
const ExpansionPanel = withStyles(theme => ({
  root: {
    border: "2px solid rgba(228,228,228,1)",
    borderRadius: "0px!important",
    boxShadow: "none",
    "&:not(:last-child)": {
      borderBottom: 0
    },
    "&:before": {
      display: "none"
    },
    "&$expanded": {
      margin: "auto"
    }
  },
  expanded: { margin: "0px!important" },
  title: {
    flexGrow: 1
  },
  expand: {
    marginTop: 0,
    fontSize: 32
  },
  addIcon: {
    marginTop: 1,
    marginRight: 8,
    fontSize: 18,
    "&:hover": {
      color: theme.systemColors[1]
    }
  },
  deleteIcon: {
    marginTop: -1,
    marginRight: 4,
    fontSize: 20,
    "&:hover": {
      color: theme.palette.error.main
    }
  },
  details: {
    padding: `${theme.spacing(2)}px ${theme.spacing(4)}px`
  }
}))(props => {
  const {
    classes,
    panel,
    key,
    title,
    expanded,
    onAdd,
    onDelete,
    changePanel,
    children,
    tooltip
  } = props;
  return (
    <MuiExpansionPanel
      expanded={expanded}
      classes={{ root: classes.root, expanded: classes.expanded }}
      key={key}
    >
      <ExpansionPanelSummary
        expandIcon={
          <ExpandMoreIcon
            fontSize="small"
            color="inherit"
            className={classes.expand}
          />
        }
        IconButtonProps={{
          onClick: () => changePanel(panel)
        }}
      >
        <Typography color="inherit" className={classes.title} variant="h5">
          {title}
        </Typography>
        <Tooltip title={tooltip && tooltip.add}>
          <AddIcon
            fontSize="small"
            color="inherit"
            onClick={onAdd}
            className={classes.addIcon}
          />
        </Tooltip>
        <Tooltip title={tooltip && tooltip.delete}>
          <Clear
            fontSize="small"
            color="inherit"
            onClick={onDelete}
            className={classes.deleteIcon}
          />
        </Tooltip>
      </ExpansionPanelSummary>

      <Grid container spacing={4} className={classes.details}>
        {children}
      </Grid>
    </MuiExpansionPanel>
  );
});

const ExpansionPanelSummary = withStyles(theme => ({
  root: {
    backgroundColor: "rgba(65,68,75,0.05)",
    borderBottom: 0,
    minHeight: 44,
    "&$expanded": {
      minHeight: 44
    }
  },
  content: {
    alignItems: "center",
    color: theme.grey[2],
    margin: 0,
    "&$expanded": {
      margin: 0
    }
  },
  expandIcon: {
    padding: 0,
    marginRight: 0
  },
  expanded: {}
}))(MuiExpansionPanelSummary);

export default ExpansionPanel;
