import React from "react";
import { Button } from "@material-ui/core";
import Progress from "Components/Progress";

export const SaveButton = ({ classes, onClick, loadingAPI, label }) => {
  return (
    <Button
      onClick={onClick}
      className={classes}
      variant="contained"
      color="primary"
    >
      {loadingAPI ? (
        <>
          <Progress />
          SAVING
        </>
      ) : (
        label || "SAVE"
      )}
    </Button>
  );
};
