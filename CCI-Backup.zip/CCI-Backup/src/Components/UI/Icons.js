import React, { CSSProperties } from "react";

import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import SaveIcon from "@material-ui/icons/SaveSharp";
import AddCircle from "@material-ui/icons/AddCircleOutline";
import Org from "@material-ui/icons/Business";

export const SuccessIcon: React.FunctionComponent = () => {
  const cx = useStyles();

  return (
    <>
      <div className={clsx(cx.icon, cx.iconSuccess)}>
        <div className={clsx(cx.iconSuccessBefore)} />
        <span className={clsx(cx.line, cx.lineTip, cx.lineTipAnimate)} />
        <span className={clsx(cx.line, cx.lineLong, cx.lineLongAnimate)} />
        <div className={cx.iconSuccessPlaceholder} />
        <div className={cx.iconSuccessFix} />
        <div className={clsx(cx.after, cx.afterAnimate)} />
      </div>
    </>
  );
};

const useStyles = makeStyles(theme => ({
  "@keyframes animateSuccessTip": {
    "0%": {
      width: 0,
      left: 1,
      top: 19
    },
    "54%": {
      width: 0,
      left: 1,
      top: 19
    },
    "70%": {
      width: 50,
      left: -8,
      top: 37
    },
    "84%": {
      width: 17,
      left: 21,
      top: 48
    },
    "100%": {
      width: 25,
      left: 14,
      top: 45
    }
  },
  "@keyframes animateSuccessLong": {
    "0%": {
      width: 0,
      right: 46,
      top: 54
    },
    "65%": {
      width: 0,
      right: 46,
      top: 54
    },
    "84%": {
      width: 55,
      right: 0,
      top: 35
    },
    "100%": {
      width: 47,
      right: 8,
      top: 38
    }
  },
  "@keyframes rotatePlaceholder": {
    "0%": {
      transform: "rotate(-45deg)"
    },
    "5%": {
      transform: "rotate(-45deg)"
    },
    "12%": {
      transform: "rotate(-405deg)"
    },
    "100%": {
      transform: "rotate(-405deg)"
    }
  },

  icon: {
    width: 80,
    height: 80,
    borderWidth: 4,
    borderStyle: "solid",
    borderColor: "gray",
    borderRadius: "50%",
    margin: "16px auto",
    position: "relative",
    boxSizing: "content-box"
  },
  iconSuccess: {
    borderColor: theme.systemColors[1]
  },

  iconSuccessBefore: {
    borderRadius: "120px 0 0 120px",
    position: "absolute",
    width: 60,
    height: 100,
    background: "white",
    transform: "rotate(-45deg)",
    top: -7,
    left: -33,
    transformOrigin: "60px 60px"
  },
  after: {
    borderRadius: "0 120px 120px 0",
    position: "absolute",
    width: 60,
    height: 120,
    background: "white",
    transform: "rotate(-45deg)",
    top: -11,
    left: 30,
    transformOrigin: "0px 60px"
  },
  afterAnimate: {
    animation: "$rotatePlaceholder 4.25s ease-in"
  },
  iconSuccessPlaceholder: {
    width: 80,
    height: 80,
    border: "4px solid rgba(10, 167, 130, 0.26)",
    borderRadius: "50%",
    boxSizing: "content-box",
    position: "absolute",
    left: -4,
    top: -4,
    zIndex: 2
  },

  iconSuccessFix: {
    width: 5,
    height: 90,
    backgroundColor: "#fff",
    position: "absolute",
    left: 28,
    top: 8,
    zIndex: 1,
    transform: "rotate(-45deg)"
  },
  line: {
    height: 5,
    backgroundColor: theme.systemColors[1],
    display: "block",
    borderRadius: 2,
    position: "absolute",
    zIndex: 2
  },
  lineTip: {
    width: 25,
    left: 14,
    top: 46,
    transform: "rotate(45deg)"
  },
  lineTipAnimate: {
    animation: "$animateSuccessTip 0.75s"
  },

  lineLong: {
    width: 47,
    right: 8,
    top: 38,
    transform: "rotate(-45deg)"
  },

  lineLongAnimate: {
    animation: "$animateSuccessLong 0.75s"
  }
}));

//// WARNING ICONS
export const WarningIcon = () => (
  <div style={Object.assign({}, icon, iconWarning)}>
    <span style={iconWarningBody}></span>
    <span style={iconWarningDot}></span>
  </div>
);

export const SavingIcon = () => (
  <div style={Object.assign({}, icon, iconSaving)}>
    <SaveIcon style={iconSavingBody} />
  </div>
);

export const AddIcon = () => (
  <div style={Object.assign({}, icon, iconSaving)}>
    <AddCircle style={iconSavingBody} />
  </div>
);

export const OrgIcon = () => (
  <div style={Object.assign({}, icon, iconSaving)}>
    <Org style={iconSavingBody} />
  </div>
);

export const icon: CSSProperties = {
  width: 80,
  height: 80,
  borderWidth: 4,
  borderStyle: "solid",
  borderColor: "gray",
  borderRadius: "50%",
  margin: "16px auto",
  position: "relative",
  boxSizing: "content-box"
};

const iconSaving: CSSProperties = {
  borderColor: "#118ACB"
};

const iconSavingBody: CSSProperties = {
  position: "absolute",
  width: "70%",
  height: "70%",
  left: "15%",
  top: "14%",

  color: "#118ACB"
};

const iconWarning: CSSProperties = {
  borderColor: "#DB4065",
  animation: "pulseWarning 0.75s infinite alternate"
};

const iconWarningBody: CSSProperties = {
  position: "absolute",
  width: 5,
  height: 47,
  left: "50%",
  top: 10,
  borderRadius: 2,
  marginLeft: -2,
  backgroundColor: "#DB4065",
  animation: "pulseWarningIns 0.75s infinite alternate"
};

const iconWarningDot: CSSProperties = {
  position: "absolute",
  width: 7,
  height: 7,
  borderRadius: "50%",
  marginLeft: -3,
  left: "50%",
  bottom: 10,
  backgroundColor: "#DB4065",
  animation: "pulseWarningIns 0.75s infinite alternate"
};
