import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import { Button } from "@material-ui/core";

export const SuccessIcon: React.FunctionComponent = () => {
  const cx = useStyles();
  const [animate, setAnimate] = useState(false);

  function animateTrigger() {
    setAnimate(true);
  }

  function onAnimationEnd() {
    setAnimate(false);
  }

  function onAnimationStart() {
    console.log("start");
  }

  return (
    <>
      <Button variant="outlined" onClick={animateTrigger}>
        ANIMATE
      </Button>
      <div className={cx.alert}>
        <div className={clsx(cx.icon, cx.iconSuccess)}>
          <div className={clsx(cx.iconSuccessBefore)} />
          <span
            className={clsx(cx.line, cx.lineTip, {
              [cx.lineTipAnimate]: animate
            })}
          />
          <span
            className={clsx(cx.line, cx.lineLong, {
              [cx.lineLongAnimate]: animate
            })}
          />
          <div className={cx.iconSuccessPlaceholder} />
          <div className={cx.iconSuccessFix} />
          <div
            className={clsx(cx.after, {
              [cx.afterAnimate]: animate
            })}
            onAnimationEnd={onAnimationEnd}
          />
        </div>
      </div>
    </>
  );
};

const useStyles = makeStyles(theme => ({
  "@keyframes animateSuccessTip": {
    "0%": {
      width: 0,
      left: 1,
      top: 19
    },
    "54%": {
      width: 0,
      left: 1,
      top: 19
    },
    "70%": {
      width: 50,
      left: -8,
      top: 37
    },
    "84%": {
      width: 17,
      left: 21,
      top: 48
    },
    "100%": {
      width: 25,
      left: 14,
      top: 45
    }
  },
  "@keyframes animateSuccessLong": {
    "0%": {
      width: 0,
      right: 46,
      top: 54
    },
    "65%": {
      width: 0,
      right: 46,
      top: 54
    },
    "84%": {
      width: 55,
      right: 0,
      top: 35
    },
    "100%": {
      width: 47,
      right: 8,
      top: 38
    }
  },
  "@keyframes rotatePlaceholder": {
    "0%": {
      transform: "rotate(-45deg)"
    },
    "5%": {
      transform: "rotate(-45deg)"
    },
    "12%": {
      transform: "rotate(-405deg)"
    },
    "100%": {
      transform: "rotate(-405deg)"
    }
  },

  goBox: {
    width: 100,
    height: 100
  },
  go: {
    backgroundColor: "orange",
    animation: "$rotatePlaceholder 4.25s ease-in"
  },

  alert: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    backgroundColor: "#FFF"
  },

  icon: {
    width: 80,
    height: 80,
    borderWidth: 4,
    borderStyle: "solid",
    borderColor: "gray",
    borderRadius: "50%",
    margin: "20px auto",
    position: "relative",
    boxSizing: "content-box"
  },
  iconSuccess: {
    borderColor: "#4cae4c"
  },

  iconSuccessBefore: {
    borderRadius: "120px 0 0 120px",
    position: "absolute",
    width: 60,
    height: 100,
    background: "white",
    transform: "rotate(-45deg)",
    top: -7,
    left: -33,
    transformOrigin: "60px 60px"
  },
  after: {
    borderRadius: "0 120px 120px 0",
    position: "absolute",
    width: 60,
    height: 120,
    background: "white",
    transform: "rotate(-45deg)",
    top: -11,
    left: 30,
    transformOrigin: "0px 60px"
  },
  afterAnimate: {
    animation: "$rotatePlaceholder 4.25s ease-in"
  },
  iconSuccessPlaceholder: {
    width: 80,
    height: 80,
    border: "4px solid rgba(92, 184, 92, 0.2)",
    borderRadius: "50%",
    boxSizing: "content-box",
    position: "absolute",
    left: -4,
    top: -4,
    zIndex: 2
  },

  iconSuccessFix: {
    width: 5,
    height: 90,
    backgroundColor: "#fff",
    position: "absolute",
    left: 28,
    top: 8,
    zIndex: 1,
    transform: "rotate(-45deg)"
  },
  line: {
    height: 5,
    backgroundColor: "#5cb85c",
    display: "block",
    borderRadius: 2,
    position: "absolute",
    zIndex: 2
  },
  lineTip: {
    width: 25,
    left: 14,
    top: 46,
    transform: "rotate(45deg)"
  },
  lineTipAnimate: {
    animation: "$animateSuccessTip 0.75s"
  },

  lineLong: {
    width: 47,
    right: 8,
    top: 38,
    transform: "rotate(-45deg)"
  },

  lineLongAnimate: {
    animation: "$animateSuccessLong 0.75s"
  }
}));

// <div
//   className={clsx(cx.goBox, {
//     [cx.go]: animate
//   })}
//   onAnimationEnd={onAnimationEnd}
//   onAnimationStart={onAnimationStart}
// />

// return (
//   <div style={Object.assign({}, styles.icon, styles.iconSuccess)}>
//     <div
//       style={Object.assign(
//         {},
//         styles.iconSuccessBeforeAfter,
//         styles.iconSuccessBefore
//       )}
//     />
//     <span
//       style={Object.assign(
//         {},
//         styles.iconSuccessLine,
//         styles.iconSuccessLineTip
//       )}
//     />
//     <span
//       style={Object.assign(
//         {},
//         styles.iconSuccessLine,
//         styles.iconSuccessLineLong
//       )}
//     />
//     <div style={styles.iconSuccessPlaceholder} />
//     <div style={styles.iconSuccessFix} />
//     <div
//       style={Object.assign(
//         {},
//         styles.iconSuccessBeforeAfter,
//         styles.iconSuccessAfter
//       )}
//     />
//   </div>
// );
// }

// import React, { useState } from "react";
// import { makeStyles } from "@material-ui/core/styles";
// import clsx from "clsx";
//
// export const SuccessIcon = () => {
//   const cx = useStyles();
//
//   return <div>y</div>;
// };
//
// const useStyles = makeStyles(theme => ({}));
