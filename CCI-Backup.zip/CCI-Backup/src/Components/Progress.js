import React from "react";
import { lighten, makeStyles, withStyles } from "@material-ui/core/styles";
import CircularProgress from "@material-ui/core/CircularProgress";

export default function Progress(props) {
  const classes = useStylesFacebook();

  return (
    <div className={classes.root}>
      <CircularProgress
        variant="determinate"
        value={100}
        className={classes.top}
        size={16}
        thickness={4}
        {...props}
      />
      <CircularProgress
        variant="indeterminate"
        disableShrink
        className={classes.bottom}
        size={16}
        thickness={4}
        {...props}
      />
    </div>
  );
}

// Inspired by the Facebook spinners.
const useStylesFacebook = makeStyles({
  root: {
    display: "flex",
    alignItems: "center",
    position: "relative",
    paddingRight: 8,
    paddingLeft: 8
  },
  top: {
    color: "#eef3fd"
  },
  bottom: {
    color: "#6798e5",
    animationDuration: "550ms",
    position: "absolute",
    left: 8
  }
});
