import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
  Typography
} from "@material-ui/core";

import { SuccessIcon, WarningIcon, SavingIcon, OrgIcon } from "Components";

/// state 1 createing
/// state 2 Saving
/// state 3 response success
/// state 4 resp;onse error

export function CreateDialog(props, context) {
  const {
    open,
    state,
    title,
    message,
    actions,
    icons,
    children,
    onSend,
    onCancel,
    onExit,
    error
  } = props;
  const cx = useStyles();

  let buttons;
  let icon;

  if (state === 1) {
    icon = <div className={cx.icon}>{icons}</div>;
    buttons = (
      <>
        <Button
          onClick={() => onCancel()}
          variant="outlined"
          className={cx.cancelBTN}
          color="primary"
        >
          {actions && actions.cancel}
        </Button>
        <Button
          onClick={() => onSend()}
          color="primary"
          variant="contained"
          autoFocus
          className={cx.continueBTN}
        >
          {actions && actions.ok}
        </Button>
      </>
    );
  } else if (state === 2) {
  }

  return (
    <Dialog
      fullWidth
      open={open}
      onClose={() => onExit()}
      onExited={onExit}
      disableBackdropClick
      classes={{ paper: cx.dialogPaper }}
    >
      <DialogTitle
        classes={{ root: clsx(cx.header, cx["border" + state]) }}
        disableTypography
      >
        {icon}
        <Typography
          className={clsx(cx.title, cx["title" + state])}
          variant="h2"
          align="center"
        >
          {title[state]}
        </Typography>
      </DialogTitle>
      <DialogContent classes={{ root: cx.content }}>
        {children && children}
        <DialogContentText
          classes={{ root: clsx(cx.message, cx["message" + state]) }}
        >
          {message && message[state]}
          {error && error}
        </DialogContentText>
      </DialogContent>
      {state !== 2 && (
        <DialogActions classes={{ root: cx.actions }}>{buttons}</DialogActions>
      )}
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  "@keyframes pulse": {
    "0%": {
      opacity: "100%"
    },
    "50%": {
      opacity: "30%"
    },

    "100%": {
      opacity: "100%"
    }
  },

  dialogPaper: {
    overflowY: "visible",
    paddingBottom: 72
  },
  header: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    padding: "0px 48px"
  },

  icon: {
    marginTop: 48,
    animation: "$pulse 2s infinite"
  },
  title: {
    marginTop: 0,
    fontWeight: 400,
    fontSize: 24
  },
  title1: {
    color: theme.palette.primary.main
  },
  title2: {
    color: theme.palette.primary.main
  },
  title3: {
    color: theme.systemColors[1]
  },
  title4: {
    color: theme.systemColors[0]
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    padding: "40px 48px 0px 48px"
  },
  content: {
    paddingLeft: 48,
    paddingRight: 48
  },
  message: {
    marginBottom: 0,
    fontWeight: 600,
    textAlign: "center"
  },
  message3: {
    color: theme.systemColors[1]
  },

  btn: {
    margin: "0px 4px"
  },
  cancelBTN: {},
  continueBTN: {},
  successBTN: {
    ...theme.successBTN
  },
  warning: {
    // color: theme.systemColors[0],
    // borderBottom: "1px solid",
    // borderColor: theme.systemColors[0]
  }
}));
