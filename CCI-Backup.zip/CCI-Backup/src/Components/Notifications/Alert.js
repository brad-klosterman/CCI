import React, { useState, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

import {
  Dialog,
  DialogActions,
  DialogContent,
  Typography
} from "@material-ui/core";

export function useAlert(resolveAlert) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState({ type: "", title: "", message: "" });
  const [btnState, setBtnState] = useState(2);
  const [resolver, setResolver] = useState(undefined);

  const awaitingPromiseRef = useRef({
    time: 300000,
    resolve: () => null,
    reject: () => null
  });

  let time = 300000;

  const t = () => setTimeout(awaitingPromiseRef.current.resolve, time);

  const alertPromise = new Promise((resolve, reject) => {
    awaitingPromiseRef.current.resolve = () => resolve();
    t();
  });

  const openAlert = async text => {
    setOpen(true);
    if (text) {
      setText({ type: text.type, title: text.title, message: text.message });
    }
    return alertPromise;
  };

  function closeAlert() {
    setOpen(false);
  }
  function sendAlert() {
    awaitingPromiseRef.current.time = 1;
    setOpen(false);
    clearTimeout(t);
  }

  return {
    openAlert,
    resolver,
    alertProps: {
      open,
      closeAlert,
      sendAlert,
      text,
      btnState
    }
  };
}

export function AlertBox(props) {
  const cx = useStyles();

  let actions;

  if (props.btnState === 0) {
    actions = (
      <>
        <Button
          onClick={props.closeAlert}
          className={cx.btn}
          variant="contained"
          color="primary"
          autoFocus
        >
          CREATE
        </Button>
        <Button
          onClick={props.closeAlert}
          className={cx.btn}
          variant="outlined"
          color="primary"
          autoFocus
        >
          CANCEL
        </Button>
      </>
    );
  } else {
    actions = (
      <Button
        onClick={props.sendAlert}
        className={cx.btn}
        variant="outlined"
        color="primary"
        autoFocus
      >
        CONTINUE
      </Button>
    );
  }
  return (
    <Dialog
      open={props.open}
      fullWidth
      maxWidth="sm"
      onClose={props.closeAlert}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <div className={cx.header}>
        <Typography variant="h2" color="secondary" align="center">
          {props.text.title}
        </Typography>
      </div>
      <DialogContent>{props.text.message}</DialogContent>
      <DialogActions classes={{ root: cx.actions }}>{actions}</DialogActions>
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  header: {
    color: "white",
    backgroundColor: theme.palette.primary.dark,
    fontSize: 16,
    padding: "48px 12px"
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    padding: 32
  },
  btn: {
    margin: "0px 4px"
  }
}));
