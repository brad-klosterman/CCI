import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
  Typography
} from "@material-ui/core";

import { SuccessIcon, WarningIcon, SavingIcon } from "Components";

export function ConfirmDialog(props, context) {
  const {
    open,
    state,
    variant,
    title,
    message,
    actions,
    onConfirm,
    onCancel,
    onExit,
    error
  } = props;
  const cx = useStyles();

  let buttons;
  let icon;

  if (state === 1) {
    icon = (
      <div className={cx.icon}>
        <WarningIcon />
      </div>
    );
    buttons = (
      <>
        <Button
          onClick={() => onCancel()}
          variant="outlined"
          className={cx.cancelBTN}
        >
          {actions && actions.cancel}
        </Button>
        <Button
          onClick={() => onConfirm(variant)}
          color="primary"
          variant="contained"
          autoFocus
          className={cx.continueBTN}
        >
          {actions && actions.ok}
        </Button>
      </>
    );
  } else if (state === 2) {
    icon = (
      <div className={cx.icon}>
        <SavingIcon />
      </div>
    );
  } else if (state === 3) {
    icon = (
      <div className={cx.icon}>
        <SuccessIcon />
      </div>
    );
    buttons = (
      <Button
        onClick={() => onExit("CONTINUE")}
        variant="contained"
        className={cx.successBTN}
      >
        {actions && actions.exit}
      </Button>
    );
  } else if (state === 4) {
    icon = (
      <div className={cx.icon}>
        <WarningIcon />
      </div>
    );
    buttons = (
      <Button
        onClick={() => onExit("CANCEL")}
        variant="outlined"
        className={cx.cancelBTN}
      >
        {actions && actions.exit}
      </Button>
    );
  } else {
    return null;
  }

  return (
    <Dialog
      fullWidth
      open={open}
      onClose={() => onExit()}
      onExited={onExit}
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-message"
      disableBackdropClick
      classes={{ paper: cx.dialogPaper }}
    >
      <DialogTitle
        id="confirm-dialog-title"
        classes={{ root: clsx(cx.header, cx["border" + state]) }}
        disableTypography
      >
        {icon}
        <Typography
          className={clsx(cx.title, cx["title" + state])}
          variant="h2"
          align="center"
        >
          {title[state]}
        </Typography>
      </DialogTitle>

      <DialogContent classes={{ root: cx.content }}>
        <DialogContentText
          classes={{ root: clsx(cx.message, cx["message" + state]) }}
          id="confirm-dialog-message"
        >
          {message && message[state]}
          {error}
        </DialogContentText>
      </DialogContent>

      {state !== 2 && (
        <DialogActions classes={{ root: cx.actions }}>{buttons}</DialogActions>
      )}
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  "@keyframes pulse": {
    "0%": {
      opacity: "100%"
    },
    "50%": {
      opacity: "30%"
    },

    "100%": {
      opacity: "100%"
    }
  },

  dialogPaper: {
    overflowY: "visible",
    paddingBottom: 72
  },
  header: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    padding: "0px 48px"
  },

  icon: {
    marginTop: 48,

    animation: "$pulse 2s infinite"
  },
  title: {
    marginTop: 0,
    fontWeight: 400,
    fontSize: 24
  },
  title1: {
    color: theme.systemColors[0]
  },
  title2: {
    color: theme.palette.primary.main
  },
  title3: {
    color: theme.systemColors[1]
  },
  title4: {
    color: theme.systemColors[0]
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    padding: "40px 48px 0px 48px"
  },
  content: {
    paddingTop: 16,
    paddingBottom: 0,
    paddingLeft: 48,
    paddingRight: 48
  },
  message: {
    marginBottom: 0,
    fontWeight: 600,
    textAlign: "center"
  },
  message3: {
    color: theme.systemColors[1]
  },

  btn: {
    margin: "0px 4px"
  },
  cancelBTN: {
    ...theme.warningBTN
  },
  continueBTN: {
    ...theme.continueBTN
  },
  successBTN: {
    ...theme.successBTN
  },
  warning: {
    // color: theme.systemColors[0],
    // borderBottom: "1px solid",
    // borderColor: theme.systemColors[0]
  },
  border1: {
    // borderTop: "solid 8px",
    // borderColor: theme.systemColors[0]
  },
  border2: {
    // borderTop: "solid 8px",
    // borderColor: theme.palette.primary.main
  },
  border3: {
    // borderTop: "solid 8px",
    // borderColor: theme.systemColors[1]
  }
}));
