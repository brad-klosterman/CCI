import React, { useState, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography,
  Button
} from "@material-ui/core";

import { SuccessIcon, WarningIcon, SavingIcon } from "Components";

const INIT_STATE = {
  variant: undefined,
  step: 1,
  icon: undefined,
  title: "",
  message: "",
  error: "",
  valid: [],
  buttons: {}
};

export function useDialog(callback) {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState();
  const [valid, setValid] = useState([]);
  const [state, setState] = useState(INIT_STATE);
  const [settings, setSettings] = useState({});

  async function init({ variant, icon, title, buttons, promise, settings }) {
    setOpen(true);
    setData({ icon, title });
    setState(prev => ({
      ...prev,
      variant,
      promise,
      icon: icon[1],
      title: title[1],
      buttons
    }));
    setSettings(settings);
  }

  function onInput(event) {
    setSettings({ ...settings, [event.target.name]: event.target.value });
    if (valid.length > 0) {
      setValid([]);
    }
  }

  const validate = async itm => {
    let errors = [];
    let vld = true;
    Object.keys(itm).forEach(key => {
      if (itm[key] === "") {
        errors.push(key);
        vld = false;
      }
    });
    return {
      errors,
      valid: vld
    };
  };

  const onSend = async () => {
    const { valid, errors } = await validate(settings);
    console.log("onsend", errors, valid);
    if (!valid) {
      setValid(errors);
    } else {
      setState(prev => ({
        ...prev,
        step: 2,
        icon: <SavingIcon />,
        title: data.title[2]
      }));
      state.promise.resolve({
        value: "RESOLVE",
        settings,
        onNext
      });
    }
  };

  const onNext = ({ step, error, payload, type }) => {
    let icon;
    if (step === 3) {
      icon = <SuccessIcon />;
    } else {
      icon = <WarningIcon />;
    }
    setState(prev => ({
      ...prev,
      step,
      icon,
      title: data.title[step],
      error
    }));
    setData({ payload, type });
  };

  const onCancel = () => {
    state.promise.resolve({ value: "REJECT" });
    setOpen(false);
    setState(INIT_STATE);
    setData();
  };

  const onExit = () => {
    callback && callback(data);
    setOpen(false);
    setState(INIT_STATE);
    setData();
  };

  return {
    variant: state.variant,
    init,
    settings,
    valid,
    onInput,
    onNext,
    open,
    props: {
      open,
      state,
      onSend,
      onCancel,
      onExit
    }
  };
}

export function DialogBox({ open, state, children, onSend, onCancel, onExit }) {
  const cx = useStyles();

  const { step, icon, title, message, error, buttons } = state;

  let actions;
  if (step === 1) {
    actions = (
      <>
        <Button
          onClick={() => onCancel()}
          variant="outlined"
          className={cx.cancelBTN}
          color="primary"
        >
          {buttons.cancel}
        </Button>
        <Button
          onClick={() => onSend()}
          color="primary"
          variant="contained"
          autoFocus
          className={cx.continueBTN}
        >
          {buttons.confirm}
        </Button>
      </>
    );
  } else if (step === 2) {
    actions = null;
  } else if (step === 3) {
    actions = (
      <Button
        onClick={() => onExit()}
        variant="outlined"
        className={cx.cancelBTN}
        color="primary"
      >
        {buttons.exit}
      </Button>
    );
  }

  return (
    <Dialog
      fullWidth
      open={open}
      disableBackdropClick
      classes={{ paper: cx.dialogPaper }}
    >
      <DialogTitle
        classes={{ root: clsx(cx.header, cx["border" + step]) }}
        disableTypography
      >
        {icon}
        <Typography
          className={clsx(cx.title, cx["title" + step])}
          variant="h2"
          align="center"
        >
          {title}
        </Typography>
      </DialogTitle>
      <DialogContent classes={{ root: cx.content }}>
        {step === 1 && children}
        <DialogContentText
          classes={{ root: clsx(cx.message, cx["message" + step]) }}
        >
          {message}
          {error && error}
        </DialogContentText>
      </DialogContent>
      {step !== 2 && (
        <DialogActions classes={{ root: cx.actions }}>{actions}</DialogActions>
      )}
    </Dialog>
  );
}

const useStyles = makeStyles(theme => ({
  "@keyframes pulse": {
    "0%": {
      opacity: "100%"
    },
    "50%": {
      opacity: "30%"
    },

    "100%": {
      opacity: "100%"
    }
  },

  dialogPaper: {
    overflowY: "visible",
    paddingBottom: 72
  },
  header: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    padding: "48px 48px 0px 48px"
  },

  icon: {
    marginTop: 48,
    animation: "$pulse 2s infinite"
  },
  title: {
    marginTop: 0,
    fontWeight: 400,
    fontSize: 24
  },
  title1: {
    color: theme.palette.primary.main
  },
  title2: {
    color: theme.palette.primary.main
  },
  title3: {
    color: theme.systemColors[1]
  },
  title4: {
    color: theme.systemColors[0]
  },
  actions: {
    display: "flex",
    justifyContent: "center",
    padding: "40px 48px 0px 48px"
  },
  content: {
    paddingLeft: 48,
    paddingRight: 48
  },
  message: {
    marginBottom: 0,
    fontWeight: 600,
    textAlign: "center"
  },
  message3: {
    color: theme.systemColors[1]
  },

  btn: {
    margin: "0px 4px"
  },
  cancelBTN: {},
  continueBTN: {},
  successBTN: {
    ...theme.successBTN
  },
  warning: {
    // color: theme.systemColors[0],
    // borderBottom: "1px solid",
    // borderColor: theme.systemColors[0]
  }
}));

// export function useAlert(resolveAlert) {
//   const [open, setOpen] = useState(false);
//   const [text, setText] = useState({ type: "", title: "", message: "" });
//   const [btnState, setBtnState] = useState(2);
//   const [resolver, setResolver] = useState(undefined);
//
//   const awaitingPromiseRef = useRef({
//     time: 300000,
//     resolve: () => null,
//     reject: () => null
//   });
//
//   let time = 300000;
//
//   const t = () => setTimeout(awaitingPromiseRef.current.resolve, time);
//
//   const alertPromise = new Promise((resolve, reject) => {
//     awaitingPromiseRef.current.resolve = () => resolve();
//     t();
//   });
//
//   const openAlert = async text => {
//     setOpen(true);
//     if (text) {
//       setText({ type: text.type, title: text.title, message: text.message });
//     }
//     return alertPromise;
//   };
//
//   function closeAlert() {
//     setOpen(false);
//   }
//   function sendAlert() {
//     awaitingPromiseRef.current.time = 1;
//     setOpen(false);
//     clearTimeout(t);
//   }
//
//   return {
//     openAlert,
//     resolver,
//     alertProps: {
//       open,
//       closeAlert,
//       sendAlert,
//       text,
//       btnState
//     }
//   };
// }

// return (
//   <Dialog
//     open={props.open}
//     fullWidth
//     maxWidth="sm"
//     onClose={props.closeAlert}
//     aria-labelledby="alert-dialog-title"
//     aria-describedby="alert-dialog-description"
//   >
//     <div className={cx.header}>
//       <Typography variant="h2" color="secondary" align="center">
//         {props.text.title}
//       </Typography>
//     </div>
//     <DialogContent>{props.text.message}</DialogContent>
//     <DialogActions classes={{ root: cx.actions }}>{actions}</DialogActions>
//   </Dialog>
// );
