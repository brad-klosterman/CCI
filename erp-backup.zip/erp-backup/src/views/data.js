

export const DATA = [
  {
    question: "This is Question 1",
    types: [1,2]
  },
  {
    question: "This is Question 2",
    types: [1,3]
  },
  {
    question: "This is Question 3",
    types: [1]
  },
  {
    question: "This is Question 4",
    types: [2]
  },
  {
    question: "This is Question 5",
    types: [3]
  }
];

export const POINTS = {
  1: {
    name: 'PAIN POINT 1'
  },
  2: {
    name: 'PAIN POINT 2'
  },
  3: {
    name: 'PAIN POINT 3'
  }
}
