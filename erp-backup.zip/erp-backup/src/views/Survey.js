import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Typography, Divider, Button, Grid } from "@material-ui/core";
import { ProgressBar } from "../components";

import { SVGG, ECry, ESad, ESmile, EHappy, EQuestion, Tick } from "../img";
import BackIcon from "@material-ui/icons/NavigateBefore";

export function Survey({ current, progress, onAnswer, goBack }) {
  const cx = useStyles();

  const MODEL = {
    title:
      "Please answer all the questions to receive a report with recommendations via email.",
    buttons: [
      {
        id: 1,
        value: 25,
        label: "Always",
        classes: cx.a1,
        icon: <SVGG cmp={ECry} viewBox="0 0 368 368" classes={cx.icon} />
      },
      {
        id: 2,
        value: 50,
        label: "Frequently",
        classes: cx.a2,
        icon: <SVGG cmp={ESad} viewBox="0 0 368 368" classes={cx.icon} />
      },
      {
        id: 3,
        value: 75,
        label: "Occasionally",
        classes: cx.a3,
        icon: (
          <SVGG
            cmp={ESmile}
            viewBox="0 0 368 368"
            classes={cx.icon}
            color="primary"
          />
        )
      },
      {
        id: 4,
        value: 100,
        label: "Never",
        classes: cx.a4,
        icon: <SVGG cmp={EHappy} viewBox="0 0 368 368" classes={cx.icon} />
      }
    ]
  };

  return (
    <Grid container item spacing={4} justify="center">
      <Grid container item xs={8} justify="center" alignItems="center">
        <SVGG cmp={Tick} viewBox="0 0 512 512" classes={cx.tick} />
        <Typography variant="body1" align="center">
          {MODEL.title}
        </Typography>
      </Grid>
      <Grid item xs={12} className={cx.center}>
        <SVGG
          cmp={EQuestion}
          viewBox="0 0 512 512"
          classes={cx.qicon}
          color="primary"
        />
      </Grid>
      <Grid item xs={12}>
        <Typography variant="body1" align="center" className={cx.question}>
          <b>Q{current.idx}:</b> {current.question}
        </Typography>
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>

      {MODEL.buttons.map(model => (
        <SurveyButton key={model.id} {...{ model, onAnswer, current }} />
      ))}
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <Grid item xs={12}>
        <Typography variant="h6" align="center">
          {Math.round(progress.value)}%
        </Typography>
      </Grid>
      <Grid item xs={12} className={cx.progress}>
        <ProgressBar variant="determinate" value={progress.value} />
      </Grid>
      {progress.value !== 0 && (
        <Grid item xs={3}>
          <Button
            color="primary"
            startIcon={<BackIcon />}
            onClick={goBack}
            fullWidth
            size="small"
          >
            PREVIOUS QUESTION
          </Button>
        </Grid>
      )}
    </Grid>
  );
}

function SurveyButton({ model, onAnswer, current }) {
  return (
    <Grid
      item
      xs={3}
      className={model.classes}
      onClick={() => onAnswer({ idx: current.idx, value: model.value })}
    >
      {model.icon}
      <Button variant="contained" color="primary" fullWidth>
        {model.label}
      </Button>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  question: {
    padding: 4,
    backgroundColor: "rgba(216,216,216,0.5)"
  },
  qicon: {
    width: "100%",
    height: "auto",
    maxWidth: "96px",
    textAlign: "center"
  },
  icon: {
    width: "100%",
    maxWidth: 82,
    height: "auto",
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(4)
  },
  tick: {
    width: "100%",
    maxWidth: 32,
    height: "auto",
    color: theme.color.success,
    paddingRight: 8
  },
  a1: {
    textAlign: "center",
    color: theme.color.alert
  },
  a2: {
    textAlign: "center",
    color: theme.color.warning
  },
  a3: { textAlign: "center" },
  a4: {
    textAlign: "center",
    color: theme.color.success
  },
  center: {
    textAlign: "center"
  },
  progress: {
    paddingBottom: "32px!important"
  }
}));

// <Grid container item xs={12} spacing={4}>
//   <Grid container item xs={12} spacing={4}>
//     <Grid item xs={1}>
//       icon
//     </Grid>
//     <Grid item xs={5}>
//       Typography
//     </Grid>
//
//     <Grid item xs={6}>
//       <form className={cx.form} noValidate autoComplete="off">
//         <TextField label="First Name" />
//         <TextField label="Last Name" />
//         <TextField label="Email" />
//       </form>
//     </Grid>
//   </Grid>
//   <Grid item xs={12}>
//     <Divider />
//   </Grid>
//   <Grid item xs={12}>
//     <Button variant="contained">GO</Button>
//   </Grid>
// </Grid>
