import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Typography,
  TextField,
  Button,
  Grid,
  Divider,
  FormControlLabel,
  Checkbox,
  SvgIcon
} from "@material-ui/core";

import { COG, Tick } from "../img";

const MODEL = {
  title: "Welcome to our ERP Value Assessor!",
  subtitle: "",
  formtitle: "YES!",
  formsub: "Please fast track me to the solutions!",
  form: [
    {
      id: "firstname",
      label: "First Name"
    },
    {
      id: "lastname",
      label: "Last Name"
    },
    {
      id: "email",
      label: "Email"
    }
  ]
};

export function Login({ user, handleForm, onStart, errors }) {
  const cx = useStyles();
  return (
    <Grid container item spacing={4} justify="center">
      <Grid item xs={12}>
        <Typography variant="h5" component="h1" align="center">
          {MODEL.title}
        </Typography>
      </Grid>
      <Grid item xs={12} className={cx.iconContainer}>
        <SvgIcon
          component={COG}
          color="primary"
          viewBox="0 0 480 480"
          classes={{ root: cx.icon1 }}
        />
      </Grid>
      <Grid item xs={8}>
        <Typography variant="subtitle1" align="center">
          <b>Just 10 minutes </b> of your time could help streamline your
          business by identifying pain points that hold you back!
        </Typography>
      </Grid>

      <Grid item xs={12}>
        <Divider />
      </Grid>

      <Grid container item spacing={0} xs={12}>
        <Grid item xs={6} className={cx.formtext}>
          <div>
            <SvgIcon
              component={Tick}
              viewBox="0 0 512 512"
              classes={{ root: cx.icon2 }}
            />
            <Typography variant="h4" align="left">
              {MODEL.formtitle}
            </Typography>
          </div>
          <Typography variant="subtitle1" align="left">
            {MODEL.formsub}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <form className={cx.form} noValidate autoComplete="off">
            {MODEL.form.map(({ id, label }) => (
              <TextField
                key={id}
                label={label}
                variant="outlined"
                size="small"
                fullWidth
                name={id}
                value={user[id]}
                onChange={handleForm}
                error={errors.hasOwnProperty(id)}
              />
            ))}
          </form>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <Grid container item xs={12}>
        <Grid item xs={9}>
          <FormControlLabel
            control={<Checkbox color="primary" />}
            label="Terms and Conditions"
          />
        </Grid>
        <Grid item xs={3}>
          <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={onStart}
          >
            GO!
          </Button>
        </Grid>
      </Grid>
    </Grid>
  );
}

const useStyles = makeStyles(theme => ({
  form: {
    display: "flex",
    flexDirection: "column",
    "& > div:nth-child(2)": {
      margin: "16px 0px"
    }
  },
  formtext: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    paddingRight: 16,
    "& > div:nth-child(1)": {
      display: "flex",
      alignItems: "center",
      marginBottom: 8
    },
    "& h4": {
      paddingLeft: 8
    }
  },

  iconContainer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },

  icon1: {
    height: "auto",
    width: "100%",
    maxWidth: 96
  },
  icon2: {
    width: "100%",
    maxWidth: 56,
    height: "auto",
    color: theme.color.success
  }
}));

// <Grid container item xs={12} spacing={4}>
//   <Grid container item xs={12} spacing={4}>
//     <Grid item xs={1}>
//       icon
//     </Grid>
//     <Grid item xs={5}>
//       Typography
//     </Grid>
//
//     <Grid item xs={6}>
//       <form className={cx.form} noValidate autoComplete="off">
//         <TextField label="First Name" />
//         <TextField label="Last Name" />
//         <TextField label="Email" />
//       </form>
//     </Grid>
//   </Grid>
//   <Grid item xs={12}>
//     <Divider />
//   </Grid>
//   <Grid item xs={12}>
//     <Button variant="contained">GO</Button>
//   </Grid>
// </Grid>
