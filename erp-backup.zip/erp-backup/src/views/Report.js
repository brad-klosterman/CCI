import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Typography, Grid, Divider } from "@material-ui/core";
import { CProgress } from "../components";
import { FINAL } from "../data";

import { SVGG, EGrowth, Send } from "../img";

export function Report({ report, overall }) {
  const cx = useStyles();
  const [grade, setGrade] = useState(0);

  useEffect(() => {
    function setScore() {
      setTimeout(() => {
        setGrade(overall);
      }, 500);
    }
    setScore();
  }, [overall]);

  const MODEL = {
    title:
      "Please answer all the questions to receive a report with recommendations via email."
  };

  let message;

  if (overall >= 90) {
    message = FINAL[1];
  } else if (overall >= 80 && overall < 90) {
    message = FINAL[2];
  } else if (overall >= 70 && overall < 80) {
    message = FINAL[3];
  } else if (overall >= 60 && overall < 70) {
    message = FINAL[4];
  } else {
    message = FINAL[5];
  }

  return (
    <Grid container item alignItems="center" justify="center" spacing={4}>
      <Grid item container alignItems="center" justify="center" xs={12}>
        <div className={cx.pWrap}>
          <CProgress value={grade}>
            <Box
              model={{ title: "OVERALL GRADE" }}
              grade={overall}
              classes={["reportBoxTop", "boxTitle2"]}
            />
          </CProgress>
        </div>
      </Grid>

      <Grid item xs={8}>
        <Typography variant="subtitle2" align="center">
          {message}
        </Typography>
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <Grid
        container
        alignItems="center"
        justify="center"
        item
        xs={12}
        className={cx.report}
      >
        {Object.keys(report).map(key => (
          <Box
            key={key}
            model={report[key]}
            grade={report[key].score}
            classes={["reportBox", "boxTitle"]}
          />
        ))}
      </Grid>
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <Grid item container className={cx.footer} xs={12}>
        <SVGG cmp={Send} viewBox="0 0 512 512" classes={cx.icon3} />
        <Typography variant="subtitle2" align="center">
          Please check your email for a more detailed report on each theme!
        </Typography>
      </Grid>
    </Grid>
  );
}

function Box({ model, grade, classes }) {
  const cx = useStyles();

  let letter;
  let pass = "true";

  if (grade >= 90) {
    letter = "A";
  } else if (grade >= 80 && grade < 90) {
    letter = "B";
  } else if (grade >= 70 && grade < 80) {
    letter = "C";
  } else if (grade >= 60 && grade < 70) {
    letter = "D";
  } else {
    letter = "F";
    pass = "false";
  }

  return (
    <div className={cx[classes[0]]}>
      <Typography variant="inherit" align="center" className={cx[classes[1]]}>
        {model.title}
      </Typography>
      <div className={cx["letter" + pass]}>{letter}</div>
      {model.icon && (
        <SVGG
          cmp={model.icon}
          viewBox="0 0 64 64"
          color="primary"
          classes={cx.icon2}
        />
      )}
      <div className={cx.perc}>{Math.round(grade)}%</div>
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  report: {
    display: "flex",
    alignItems: "stretch"
  },
  reportBox: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    maxWidth: 160,
    padding: "16px 8px",
    margin: 8,
    backgroundColor: "rgba(216,216,216,0.5)",
    fontSize: 12,
    fontWeight: 700
  },
  reportBoxTop: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "200px",
    height: 200,
    fontSize: 12,
    fontWeight: 700,
    paddingTop: 12
  },
  boxTitle: { flexGrow: 1 },
  boxTitle2: { fontWeight: 900 },
  lettertrue: {
    fontSize: 40,
    fontWeight: 900,
    marginTop: 8,
    color: theme.palette.primary.main
  },
  letterfalse: {
    fontSize: 40,
    fontWeight: 900,
    marginTop: 8,
    color: theme.color.alert
  },
  icon: {
    width: "100%",
    maxWidth: 72,
    height: "auto",
    marginTop: 8
  },
  icon2: {
    width: "100%",
    maxWidth: 36,
    height: "auto",
    marginTop: 8
  },
  icon3: {
    width: "100%",
    maxWidth: 32,
    height: "auto",
    marginRight: 8
  },
  center: {
    textAlign: "center"
  },
  perc: {
    marginTop: 8
  },
  pWrap: {
    position: "relative",
    width: 200,
    height: 200
  },
  overallResult: {
    width: 200,
    height: 200,
    borderRadius: "50%"
    // backgroundColor: "rgba(216,216,216,0.5)"
  },
  overall: {
    width: 200,
    height: 200,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    "& > div:nth-child(1)": {
      fontSize: 12,
      fontWeight: 700
    },
    "& > div:nth-child(2)": {
      fontSize: 12,
      fontWeight: 700
    }
  },
  progress: {
    position: "absolute",
    // top: -6,
    // left: -6,
    zIndex: 1
  },
  footer: {
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 0
  }
}));

// <Grid item xs={12} className={cx.center}>
//   <SVGG
//     cmp={EGrowth}
//     viewBox="0 0 98 98"
//     color="primary"
//     classes={cx.icon}
//   />
//   <Typography variant="subtitle2" align="center">
//     RESULTS!
//   </Typography>
// </Grid>
