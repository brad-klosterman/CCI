import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import withRoot from "./globals/withRoot";
import { Grid } from "@material-ui/core";
import { Login, Survey, Report } from "./views";
import { DATA, THEMES } from "./data";
import { Dashboard, Inventory, Order, Order2, Water } from "./img";

const THEME_MODEL = {
  1: Dashboard,
  2: Inventory,
  3: Order,
  4: Order2,
  5: Water
};

const API =
  "https://cci-ing-dev.eastus.cloudapp.azure.com/erp-assessor/api/assessment";

function App() {
  const cx = useStyles();

  /// STATE
  const [view, setView] = useState(1);
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    email: ""
  });
  const [questions, setQuestions] = useState();
  const [current, setCurrent] = useState();
  const [progress, setProgress] = useState();
  const [errors, setErrors] = useState({});

  const [report, setReport] = useState({});
  const [overall, setOverall] = useState(0);

  useEffect(() => {
    let num;
    setQuestions(
      DATA.reduce((accumulator, { question, types }, idx) => {
        num = idx + 1;
        accumulator[idx + 1] = {
          types,
          question,
          answer: undefined
        };
        return accumulator;
      }, {})
    );
    setProgress({
      total: num,
      value: 0
    });
  }, []);

  function handleForm(event) {
    const name = event.target.name;
    const value = event.target.value;
    if (errors.hasOwnProperty(name)) {
      delete errors[name];
    }
    setUser({ ...user, [name]: value });
  }

  async function validate(form) {
    let err = {};
    let valid = true;
    Object.keys(form).forEach(key => {
      if (key === "email") {
        const validEmail = ValidateEmail(form[key]);
        if (!validEmail) {
          err[key] = true;
          valid = false;
        }
      }

      if (form[key] === "") {
        err[key] = true;
        valid = false;
      }
    });
    return {
      err,
      valid
    };
  }

  function ValidateEmail(email) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email.match(mailformat)) {
      return true;
    } else {
      return false;
    }
  }

  async function onStart() {
    const { valid, err } = await validate(user);
    if (!valid) {
      setErrors(err);
    } else {
      setCurrent({
        idx: 1,
        question: questions[1].question
      });
      setView(2);
    }
  }

  function goBack() {
    if (current.idx !== 1) {
      setProgress(prev => ({
        ...prev,
        value: ((current.idx - 2) / prev.total) * 100
      }));
      setCurrent(prev => ({
        idx: prev.idx - 1,
        question: questions[prev.idx - 1].question
      }));
    }
  }

  function onAnswer({ idx, value }) {
    const newState = {
      ...questions,
      [idx]: {
        ...questions[idx],
        answer: value
      }
    };
    setQuestions(newState);

    setProgress(prev => ({
      ...prev,
      value: (idx / prev.total) * 100
    }));

    if (idx !== progress.total) {
      setCurrent(prev => ({
        idx: prev.idx + 1,
        question: questions[prev.idx + 1].question
      }));
    } else {
      RUN_REPORT({ answers: newState });
    }
  }

  async function RUN_REPORT({ answers }) {
    const API_PAYLOAD = {
      answers: {},
      themes: {},
      overall: {},
      user: {}
    };
    let OVERALL = 0;
    const REPORT_STATE = Object.assign(
      ...Object.keys(THEMES).map(key => ({
        [key]: {
          title: THEMES[key].title,
          icon: THEME_MODEL[key],
          count: 0,
          total: 0,
          score: 0
        }
      }))
    );

    Object.keys(answers).forEach(key => {
      const { types, answer } = answers[key];
      API_PAYLOAD.answers[key] = answer;
      types.forEach(type => {
        var R_THEME = REPORT_STATE[type];
        var count = R_THEME.count + 1;
        var total = R_THEME.total + Number(answer);
        var score = total / count;

        REPORT_STATE[type] = {
          ...R_THEME,
          count,
          total,
          score
        };
      });
    });

    Object.keys(REPORT_STATE).forEach(key => {
      const { score } = REPORT_STATE[key];
      API_PAYLOAD.themes[key] = score;
      OVERALL += score;
    });

    OVERALL = OVERALL / 5;

    API_PAYLOAD.overall = OVERALL;
    API_PAYLOAD.user = user;

    setReport(REPORT_STATE);
    setOverall(OVERALL);
    setView(3);
    API_REQUEST(API_PAYLOAD);
  }

  const API_REQUEST = PAYLOAD => {
    fetch(API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(PAYLOAD)
    })
      .then(response => {})
      .catch(error => {
        console.error("Error:", error);
      });
  };

  return (
    <Grid container spacing={0} className={cx.root}>
      {view === 1 && <Login {...{ user, handleForm, onStart, errors }} />}
      {view === 2 && <Survey {...{ current, progress, onAnswer, goBack }} />}
      {view === 3 && <Report {...{ report, overall }} />}
    </Grid>
  );
}

const AppModule = withRoot(App);
export default AppModule;

const useStyles = makeStyles(theme => ({
  root: {
    marginTop: 32,
    marginBottom: 32,
    backgroundColor: "#FFF",
    maxWidth: "1200px",
    padding: "64px",
    paddingBottom: 32,
    boxShadow: "0 1px 4px 0 rgba(0,0,0,0.14)"
  }
}));
