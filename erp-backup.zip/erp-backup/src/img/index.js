import React from "react";
import { SvgIcon } from "@material-ui/core";

export { EmojiCry } from "./emoji-cry.svg";

export { ReactComponent as COG } from "./cog.svg";
export { ReactComponent as Tick } from "./tick.svg";

export { ReactComponent as ECry } from "./emoji-cry.svg";
export { ReactComponent as ESad } from "./emoji-sad.svg";
export { ReactComponent as ESmile } from "./emoji-smile.svg";
export { ReactComponent as EHappy } from "./emoji-happy.svg";

export { ReactComponent as EQuestion } from "./question.svg";

export { ReactComponent as EGrowth } from "./result.svg";

export { ReactComponent as Dashboard } from "./dashboard.svg";
export { ReactComponent as Inventory } from "./inventory.svg";
export { ReactComponent as Order } from "./order.svg";
export { ReactComponent as Order2 } from "./order-2.svg";
export { ReactComponent as Water } from "./water.svg";
export { ReactComponent as Send } from "./send.svg";

export function SVGG({ cmp, viewBox, color, classes }) {
  return (
    <SvgIcon
      component={cmp}
      color={color || "inherit"}
      viewBox={viewBox}
      classes={{ root: classes }}
    />
  );
}
