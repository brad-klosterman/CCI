export const DATA = [
  {
    question: "It takes too long to create new material masters",
    types: [1, 5]
  },
  {
    question:
      "Production orders are delayed because of incorrect BOMs and/or routings",
    types: [1]
  },
  {
    question: "We do not trust our system-generated product costs",
    types: [1, 3, 4]
  },
  {
    question:
      "BOMs and/or routings must be manually adjusted before starting production",
    types: [1]
  },
  {
    question:
      "It takes too much effort to generate a complete list of active materials and their descriptions",
    types: [1]
  },
  {
    question: "BOM and/or routing errors are found in production",
    types: [1, 5]
  },
  {
    question:
      "There us no clear understanding about who is responsible for what data elements",
    types: [1]
  },
  {
    question: "Material naming conventions are inconsistent and confusing",
    types: [1]
  },
  {
    question:
      "Sales orders are captured before the material master data is set up",
    types: [1, 3]
  },
  {
    question: "New material masters are moved into production without testing",
    types: [1]
  },
  {
    question: "Large manufacturing order variances occur",
    types: [1, 2, 3, 4]
  },
  {
    question: "New material master data set-up is expedited",
    types: [1]
  },
  {
    question: "Materials are moved to unintended plants or locations",
    types: [1, 2, 4, 5]
  },
  {
    question:
      "Mass updates to material masters, BOMs and/or routings take too long",
    types: [1, 5]
  },
  {
    question:
      "There is lack of coordination between the New Product Development teams and the master data team",
    types: [1]
  },
  {
    question: "Data maintenance time is wasted working on obsolete materials",
    types: [1]
  },
  {
    question:
      "Identifying which products are the most and least profitable is a significant effort",
    types: [1, 3]
  },
  {
    question:
      "BOMs and/or routings are only reviewed when someone reports an issue",
    types: [1]
  },
  {
    question:
      "It takes too long to locate and pick all the materials required for an order",
    types: [2]
  },
  {
    question:
      "We wait until we physically confirm we have enough materials on hand to start a production order",
    types: [2]
  },
  {
    question: "To locate materials we have to physically search for it",
    types: [2]
  },
  {
    question: "We cut production orders short because we run out of components",
    types: [2, 4]
  },
  {
    question:
      "We ship sales orders short because we don't have as much usable finished goods as the system says",
    types: [2]
  },
  {
    question: "We write-on inventory to keep the system from going negative",
    types: [2, 4]
  },
  {
    question: "We expedite purchased components from suppliers",
    types: [2, 3]
  },
  {
    question: "We expedite sales orders to customers",
    types: [2, 3]
  },
  {
    question: "Back-orders are increasing",
    types: [2, 3]
  },
  {
    question: "Inventory is growing faster than sales",
    types: [2, 5]
  },
  {
    question: "The warehouse space is overcrowded and inefficient",
    types: [2, 5]
  },
  {
    question: "We run out of warehouse space",
    types: [2]
  },
  {
    question: "Stockouts occur",
    types: [2, 3]
  },
  {
    question:
      "A large portion of our inventory is slow moving, expired and/or obsolete",
    types: [2]
  },
  {
    question: "Incorrect parts are shipped to customers",
    types: [2]
  },
  {
    question: "Inventory turnover is too low",
    types: [2]
  },
  {
    question: "Inventory age is rising",
    types: [2]
  },
  {
    question: "We have difficulty determining our true inventory costs",
    types: [2]
  },
  {
    question:
      "We cannot trust our system-generated Available-To-Promise (ATP) dates",
    types: [1, 2, 3]
  },
  {
    question: "Our customers complain about our delivery performance",
    types: [3]
  },
  {
    question: "Same day changes are made to the production schedule",
    types: [3]
  },
  {
    question:
      "Significant time is wasted on unplanned production line changeovers ",
    types: [3]
  },
  {
    question: "The shop floor receives confusing schedule instructions",
    types: [3]
  },
  {
    question: "Actual production rate performance is below standard",
    types: [1, 3]
  },
  {
    question: "Overtime is too high",
    types: [3]
  },
  {
    question:
      "Management spends too much time trying to organize overtime at the last minute",
    types: [3]
  },
  {
    question: "Production rates are reduced due to lack of manpower",
    types: [3]
  },
  {
    question:
      "If things are running well, manufacturing makes more than scheduled",
    types: [3]
  },
  {
    question:
      "Production is either cut short, or extended longer to avoid production line changeovers at shift change",
    types: [3]
  },
  {
    question:
      "It takes too long for customers to get an update on their order ",
    types: [3, 4]
  },
  {
    question: "Our supplier delivery performance is poor",
    types: [3, 5]
  },
  {
    question:
      "Our suppliers complain that we change their schedule with too short of notice",
    types: [3]
  },
  {
    question:
      "We have to curtail or stop production due to supplier delivery failures",
    types: [3]
  },
  {
    question:
      "Production order status reported in the system runs a day or more behind",
    types: [3, 4]
  },
  {
    question:
      "Manual inventory adjustments are required at the end of the month to close the books",
    types: [2, 4]
  },
  {
    question:
      "Goods receipts and/or goods issues are recorded against the wrong production order",
    types: [3, 4]
  },
  {
    question:
      "It is difficult to determine exactly when a production run will be completed",
    types: [3, 4]
  },
  {
    question: "Posting errors are discovered days after the physical movements",
    types: [2, 4]
  },
  {
    question:
      "Too much time is spent trying to determine production order status on the shop floor",
    types: [3, 4]
  },
  {
    question:
      "Excess components are delivered to the shop floor and must be returned to storage",
    types: [1, 2, 4]
  },
  {
    question:
      "We backflush components, without adjustments, knowing the consumptions may be incorrect",
    types: [1, 2, 4]
  },
  {
    question:
      "We cannot completely account for all our component or raw materials",
    types: [2, 3, 4]
  },
  {
    question:
      "We cannot completely account for all our waste and/or byproducts",
    types: [2, 3, 4]
  },
  {
    question: "Our supply chain network is overly complex",
    types: [5]
  },
  {
    question:
      "Customer Service Representatives are confused about what location to place sales orders on",
    types: [5]
  },
  {
    question:
      "Price is the most important consideration in evaluating suppliers",
    types: [5]
  },
  {
    question:
      "Sales orders trigger new production orders even though finished goods inventory exists at another plant",
    types: [3, 5]
  },
  {
    question: "Communication with our major suppliers is poor",
    types: [3, 5]
  },
  {
    question:
      "It takes more than one day to accept and confirm a delivery date for a sales order",
    types: [3, 5]
  },
  {
    question: "Our suppliers have no view into our long-term demand forecast",
    types: [3]
  },
  {
    question: "Customers complain about our lead time",
    types: [3, 5]
  },
  {
    question:
      "Sales order get cancelled and re-entered causing customer delays",
    types: [3, 5]
  },
  {
    question:
      "We have too much inventory at the wrong locations, and not enough where it is needed",
    types: [5]
  },
  {
    question:
      "We have to adjust process conditions when we switch suppliers of the same material",
    types: [1, 3, 5]
  },
  {
    question:
      "Customers can see a difference in our product depending on what machine is used to make it",
    types: [5]
  },
  {
    question:
      "Customers can see a difference in our product depending on what supplier the raw materials come from",
    types: [1, 3, 5]
  },
  {
    question:
      "We spend too much time managing different supplier document formats",
    types: [3, 5]
  },
  {
    question:
      "We have multiple materials that appear to be the same or almost the same",
    types: [1]
  }
];

export const THEMES = {
  1: {
    title: "MASTER DATA MANAGEMENT"
  },
  2: {
    title: "INVENTORY MANAGEMENT"
  },
  3: {
    title: "ORDER MANAGEMENT"
  },
  4: {
    title: "MATERIAL MANAGEMENT"
  },
  5: {
    title: "SUPPLY CHAIN NETWORK"
  }
};

export const FINAL = {
  1: "Congratulations!  You are in elite company and obviously treating your business processes with the respect they deserve!  Keep up the good work!",
  2: "You are doing better than most with your business processes, but there is still room for improvement.  We recommend you consider exploring additional activities to improve your business processes.",
  3: "Like many others you appear to be struggling with your business processes.  We recommend you pursue additional activities to improve your business processes.",
  4: "It appears that you are struggling significantly with your business processes.  We strongly recommend you pursue additional activities to improve your business processes.",
  5: "It appears that your business processes are quite broken and causing you significant pain.  We strongly recommend you pursue additional activities to improve your business processes."
};

// const yes = {
//   answers: { "1": 75, "2": 100, "3": 75, "4": 100, "5": 75 },
//   themes: { "1": 83, "2": 87.5, "3": 87.5, "4": 75, "5": 75 },
//   overall: 81,
//   user: { firstname: "B", lastname: "Klosterman", email: "BK@mail.com" }
// };
