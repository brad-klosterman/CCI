import React from "react";
import { lighten, makeStyles, withStyles } from "@material-ui/core/styles";

import LinearProgress from "@material-ui/core/LinearProgress";
import CircularProgress from "@material-ui/core/CircularProgress";

export const ProgressBar = withStyles({
  root: {
    height: 12,
    borderRadius: 20
    // border: "1px solid #118ACB"
  },
  bar: {
    borderRadius: 20
  }
})(LinearProgress);

export const CircularProgressBar = withStyles({
  root: { position: "relative" },
  bottom: {
    color: "#6798e5",
    animationDuration: "550ms",
    position: "absolute",
    left: 0
  }
})(CircularProgress);

const useStylesFacebook = makeStyles({
  root: {
    position: "relative"
  },
  top: {
    color: "rgb(164, 210, 235, 0.2)",
    position: "absolute"
  },
  bottom: {
    color: "#118ACB",
    animationDuration: "550ms",
    position: "absolute",
    left: 0
  },
  bg: {
    backgroundColor: "rgba(216,216,216,0.5)",
    position: "absolute",
    borderRadius: "50%",
    width: 200,
    height: 200,
    zIndex: -10
  }
});

export function CProgress({ value, children }) {
  const classes = useStylesFacebook();

  return (
    <div className={classes.root}>
      <CircularProgress
        variant="determinate"
        value={100}
        className={classes.top}
        size={200}
        thickness={4}
      />
      <CircularProgress
        variant="static"
        className={classes.bottom}
        size={200}
        thickness={4}
        value={value}
      />

      {children}
      <div className={classes.bg}></div>
    </div>
  );
}
