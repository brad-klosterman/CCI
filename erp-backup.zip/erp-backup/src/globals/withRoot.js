import React from "react";
import { createMuiTheme } from "@material-ui/core/styles";
import { ThemeProvider } from "@material-ui/styles";
import CssBaseline from "@material-ui/core/CssBaseline";

const theme = createMuiTheme({
  palette: {
    primary: {
      light: "#30A8E8",
      main: "#118ACB",
      dark: "#0980BC"
    },
    error: { main: "#DB4065" },
    text: {
      primary: "#393B40"
    }
  },
  color: {
    alert: "#DB4065",
    warning: "#F7B500",
    success: "#23A59C"
  },
  typography: {
    useNextVariants: true,
    fontFamily: ["Montserrat", "OpenSans"].join(","),
    // fontSize: 16,
    // htmlFontSize: 16,
    color: "#393B40"
  },

  overrides: {
    MuiButton: {
      root: {
        padding: "8px 16px",
        borderRadius: 3
      },
      contained: {
        boxShadow: "0 1px 4px 0 rgba(0,0,0,0.14)",
        "&:hover": {
          boxShadow: "0 1px 4px 0 rgba(0,0,0,0.24)"
        }
      },
      label: {
        fontWeight: "bold"
      }
    }
  }
});

function withRoot(Component) {
  function WithRoot(props) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Component {...props} />
      </ThemeProvider>
    );
  }

  return WithRoot;
}

export default withRoot;
